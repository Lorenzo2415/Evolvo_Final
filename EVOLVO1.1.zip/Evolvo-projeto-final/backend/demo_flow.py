"""Prepara histórico demonstrativo local após `python seed.py`."""
from app import create_app
from app.models.entities import QuestionOption


def auth_headers(client):
    response = client.post("/api/auth/login", json={"email": "demo@evolvo.local", "password": "Demo123!"})
    token = response.get_json()["accessToken"]
    return {"Authorization": f"Bearer {token}"}


def complete(client, headers, create_path, finish_path, count, error_every=4):
    assessment = client.post(create_path, headers=headers, json={"questionCount": count}).get_json()
    answers = []
    for index, question in enumerate(assessment["questions"], 1):
        options = QuestionOption.query.filter_by(question_id=question["id"]).order_by(QuestionOption.position).all()
        correct = next(item for item in options if item.is_correct)
        selected = next(item for item in options if not item.is_correct) if index % error_every == 0 else correct
        answers.append({"questionId": question["id"], "optionId": selected.id})
    result = client.post(finish_path.format(id=assessment["id"]), headers=headers, json={"answers": answers})
    if result.status_code != 200:
        raise RuntimeError(result.get_json())
    return result.get_json()


def run():
    app = create_app()
    with app.app_context():
        client = app.test_client()
        headers = auth_headers(client)
        diagnostic = complete(client, headers, "/api/diagnostics", "/api/diagnostics/{id}/finish", 10, 4)
        plan = client.post("/api/study-plans/generate", headers=headers).get_json()
        exercise = complete(client, headers, "/api/exercise-lists", "/api/exercise-lists/{id}/finish", 5, 3)
        simulation = complete(client, headers, "/api/simulations", "/api/simulations/{id}/finish", 10, 5)
        print(f"Fluxo pronto: diagnóstico {diagnostic['score']}%, lista {exercise['score']}%, simulado {simulation['score']}%, plano v{plan['version']}.")


if __name__ == "__main__":
    run()

