"""Dados demonstrativos autorais. Nenhuma questão é apresentada como oficial."""
import hashlib
from datetime import date, timedelta
from app import create_app
from app.data.question_variants import generated_question_variants
from app.extensions import db
from app.models.entities import EssayPrompt, Exam, ExamProfile, Question, QuestionOption, Subject, Teacher, TeacherReview, Topic, User, UserConsent, UserGoal
from app.services.question_taxonomy import ENEM_TAXONOMY


QUESTION_BANK = [
    ("Matemática", "Porcentagem", "easy", "Uma biblioteca tinha 800 livros e ampliou o acervo em 15%. Quantos livros passou a ter?", ["880", "900", "920", "940", "960"], 2, "15% de 800 é 120. Somando ao acervo inicial, obtém-se 920."),
    ("Matemática", "Porcentagem", "medium", "Um produto de R$ 250 recebeu desconto de 12% e depois acréscimo de 12% sobre o novo preço. Qual é o valor final?", ["R$ 246,40", "R$ 250,00", "R$ 253,60", "R$ 220,00", "R$ 280,00"], 0, "O desconto leva o preço a R$ 220. O acréscimo de 12% sobre 220 vale R$ 26,40, totalizando R$ 246,40."),
    ("Matemática", "Probabilidade", "easy", "Em uma caixa há 3 bolas azuis e 2 verdes. Retirando uma bola ao acaso, qual é a probabilidade de ela ser verde?", ["1/5", "2/5", "3/5", "2/3", "3/2"], 1, "Há 2 resultados favoráveis entre 5 bolas, portanto a probabilidade é 2/5."),
    ("Matemática", "Probabilidade", "medium", "Dois dados comuns são lançados. Qual é a probabilidade de a soma ser 7?", ["1/12", "1/8", "1/6", "1/4", "1/3"], 2, "Existem 6 pares com soma 7 entre 36 resultados equiprováveis. Assim, 6/36 = 1/6."),
    ("Matemática", "Funções", "medium", "Um aplicativo cobra taxa fixa de R$ 8 mais R$ 2 por quilômetro. Qual expressão representa o custo C para x quilômetros?", ["C=8x+2", "C=2x+8", "C=10x", "C=8x-2", "C=2x"], 1, "A parte variável é 2x e a taxa fixa é 8, logo C=2x+8."),
    ("Linguagens", "Interpretação", "easy", "Em uma campanha lê-se: 'Economize água hoje para não faltar amanhã'. O principal efeito do uso de 'hoje' e 'amanhã' é", ["comparar preços", "indicar uma relação entre ação presente e consequência futura", "descrever uma rotina", "marcar uma oposição geográfica", "apresentar dados científicos"], 1, "Os advérbios relacionam a economia no presente à disponibilidade futura de água."),
    ("Linguagens", "Interpretação", "medium", "No enunciado 'A cidade acordou tossindo fumaça', a atribuição de ação humana à cidade produz", ["uma definição técnica", "um eufemismo", "uma personificação que reforça o impacto da poluição", "uma comparação explícita", "uma enumeração"], 2, "A cidade recebe a ação humana de acordar e tossir, recurso de personificação que destaca a poluição."),
    ("Linguagens", "Variação linguística", "easy", "A escolha entre 'nós vamos' e 'a gente vai' evidencia principalmente", ["erro obrigatório", "variação de registro e uso", "mudança de idioma", "ausência de sujeito", "linguagem científica"], 1, "As formas coexistem em diferentes situações comunicativas e registros do português."),
    ("Linguagens", "Gêneros textuais", "medium", "Um texto com título, data, relato objetivo de um fato recente e identificação do veículo pertence mais provavelmente ao gênero", ["receita", "notícia", "poema", "verbete", "anúncio classificado"], 1, "Atualidade, objetividade e vinculação a um veículo caracterizam a notícia."),
    ("Linguagens", "Coesão", "hard", "Em 'Marina revisou o texto. Depois, enviou-o ao editor', o pronome 'o' retoma", ["Marina", "texto", "editor", "depois", "revisão"], 1, "O pronome oblíquo 'o' substitui o substantivo masculino singular 'texto'."),
    ("Ciências da Natureza", "Ecologia", "easy", "A retirada de predadores do topo de uma cadeia alimentar tende inicialmente a", ["reduzir suas presas", "aumentar a população de suas presas", "eliminar produtores", "impedir a fotossíntese", "reduzir a luz solar"], 1, "Com menor predação, a população de presas tende a crescer no curto prazo."),
    ("Ciências da Natureza", "Ecologia", "medium", "O excesso de nutrientes lançado em um lago pode aumentar algas e reduzir oxigênio dissolvido. Esse processo é chamado", ["sublimação", "eutrofização", "destilação", "erosão eólica", "mutação"], 1, "O enriquecimento por nutrientes que provoca proliferação de algas e queda de oxigênio é a eutrofização."),
    ("Ciências da Natureza", "Energia", "easy", "Uma lâmpada de 10 W ligada por 5 horas consome", ["2 Wh", "15 Wh", "50 Wh", "500 Wh", "50 kWh"], 2, "Energia é potência multiplicada pelo tempo: 10 W × 5 h = 50 Wh."),
    ("Ciências da Natureza", "Energia", "medium", "Ao frear uma bicicleta, a energia cinética é transformada principalmente em", ["energia nuclear", "energia térmica", "energia química", "energia luminosa", "massa"], 1, "O atrito nos freios converte movimento em calor, isto é, energia térmica."),
    ("Ciências da Natureza", "Genética", "medium", "Em uma espécie, A é dominante sobre a. No cruzamento Aa × aa, a proporção esperada de descendentes aa é", ["0%", "25%", "50%", "75%", "100%"], 2, "O primeiro genitor produz gametas A ou a e o segundo apenas a. Metade dos descendentes tende a ser aa."),
    ("Ciências Humanas", "Cidadania", "easy", "A participação em conselhos municipais e audiências públicas é exemplo de", ["censura estatal", "participação política direta em espaços institucionais", "isolamento social", "poder hereditário", "privatização da justiça"], 1, "Esses mecanismos permitem participação direta da população em decisões e fiscalização públicas."),
    ("Ciências Humanas", "Urbanização", "medium", "A expansão urbana sem infraestrutura adequada costuma intensificar", ["o acesso universal a serviços", "a segregação socioespacial", "a redução automática do trânsito", "o desaparecimento das periferias", "a igualdade fundiária"], 1, "O crescimento desigual do espaço urbano concentra serviços e oportunidades, aprofundando a segregação."),
    ("Ciências Humanas", "Industrialização", "medium", "A divisão do trabalho nas fábricas do século XIX contribuiu para", ["eliminar a produção em série", "aumentar a especialização das tarefas", "encerrar o uso de máquinas", "substituir cidades por feudos", "reduzir o mercado consumidor"], 1, "A organização fabril fragmentou o processo produtivo em tarefas especializadas."),
    ("Ciências Humanas", "Cartografia", "easy", "Em um mapa na escala 1:100.000, 1 cm representa, no terreno,", ["100 m", "500 m", "1 km", "10 km", "100 km"], 2, "100.000 cm equivalem a 1.000 m, ou 1 km."),
    ("Ciências Humanas", "Democracia", "hard", "A separação entre Executivo, Legislativo e Judiciário busca principalmente", ["concentrar decisões", "eliminar eleições", "limitar o poder por meio de controles recíprocos", "subordinar leis ao governo", "impedir participação civil"], 2, "A separação dos poderes cria freios e contrapesos para limitar concentrações e abusos."),
]
QUESTION_BANK.extend(generated_question_variants())


TOPIC_TAXONOMY = {
    "Porcentagem": ("Matemática", "Matemática"),
    "Probabilidade": ("Matemática", "Matemática"),
    "Funções": ("Matemática", "Matemática"),
    "Interpretação": ("Língua Portuguesa", "Linguagens"),
    "Variação linguística": ("Língua Portuguesa", "Linguagens"),
    "Gêneros textuais": ("Língua Portuguesa", "Linguagens"),
    "Coesão": ("Língua Portuguesa", "Linguagens"),
    "Ecologia": ("Biologia", "Ciências da Natureza"),
    "Genética": ("Biologia", "Ciências da Natureza"),
    "Energia": ("Física", "Ciências da Natureza"),
    "Movimento": ("Física", "Ciências da Natureza"),
    "Urbanização": ("Geografia", "Ciências Humanas"),
    "Cartografia": ("Geografia", "Ciências Humanas"),
    "Industrialização": ("História", "Ciências Humanas"),
    "Cidadania": ("Sociologia", "Ciências Humanas"),
    "Democracia": ("Sociologia", "Ciências Humanas"),
}


def seed():
    db.drop_all()
    db.create_all()
    enem = Exam(slug="enem", name="ENEM", exam_type="ENEM", institution="INEP", board="INEP", support_status="full")
    fuvest = Exam(slug="fuvest", name="FUVEST", exam_type="vestibular", institution="USP", board="FUVEST", support_status="limited")
    db.session.add_all([enem, fuvest])
    db.session.flush()
    db.session.add_all([
        ExamProfile(exam_id=enem.id, edition="perfil contínuo", syllabus={}, structure={"areas": 4, "days": 2}, question_count=180, alternative_count=5, duration_minutes=630, difficulty_levels=["easy", "medium", "hard"], characteristics=["contextualização", "interpretação", "situações-problema"], references=["Matriz de Referência do ENEM"]),
        ExamProfile(exam_id=fuvest.id, edition="catálogo", syllabus={}, structure={}, question_count=90, alternative_count=5, duration_minutes=300, difficulty_levels=["medium", "hard"], characteristics=[], references=[]),
    ])
    db.session.add_all([
        EssayPrompt(exam_id=enem.id, title="Cidadania digital", theme="Desafios para combater a desinformação digital no Brasil", instructions="Escreva um texto dissertativo-argumentativo em modalidade formal da língua portuguesa e apresente uma proposta de intervenção que respeite os direitos humanos.", support_texts=[{"title":"Contexto","text":"A circulação acelerada de conteúdos amplia o acesso à informação, mas também favorece mensagens falsas fora de contexto."},{"title":"Ponto de reflexão","text":"Educação midiática, transparência das plataformas e responsabilização devem preservar simultaneamente segurança e liberdade de expressão."}]),
        EssayPrompt(exam_id=enem.id, title="Inclusão educacional", theme="Caminhos para reduzir a desigualdade de acesso à educação de qualidade no Brasil", instructions="Produza uma dissertação argumentativa com tese, argumentos articulados e proposta de intervenção detalhada e compatível com os direitos humanos.", support_texts=[{"title":"Contexto","text":"Infraestrutura, permanência escolar, formação docente e desigualdades territoriais afetam de maneiras diferentes a trajetória dos estudantes."},{"title":"Ponto de reflexão","text":"Garantir matrícula é essencial, mas aprendizagem e permanência também dependem de políticas públicas coordenadas."}]),
        EssayPrompt(exam_id=enem.id, title="Saúde mental", theme="A importância da promoção da saúde mental entre jovens brasileiros", instructions="Defenda um ponto de vista, mobilize repertório pertinente e conclua com uma proposta de intervenção socialmente responsável.", support_texts=[{"title":"Contexto","text":"Pressões escolares, relações digitais e desigualdades sociais podem afetar o bem-estar emocional dos jovens."},{"title":"Ponto de reflexão","text":"Prevenção, acolhimento e acesso a atendimento especializado exigem articulação entre família, escola, saúde e comunidade."}]),
        EssayPrompt(exam_id=enem.id, title="Sustentabilidade urbana", theme="Obstáculos à construção de cidades brasileiras mais sustentáveis e inclusivas", instructions="Escreva um texto dissertativo-argumentativo com proposta de intervenção que respeite os direitos humanos.", support_texts=[{"title":"Contexto","text":"Mobilidade, moradia, saneamento, áreas verdes e adaptação climática integram o planejamento urbano sustentável."},{"title":"Ponto de reflexão","text":"Os impactos ambientais e a falta de infraestrutura atingem de forma mais intensa grupos socialmente vulneráveis."}]),
    ])
    subjects = {}
    topics = {}
    for subject_name, (area_name, topic_names) in ENEM_TAXONOMY.items():
        subject = Subject(exam_id=enem.id, name=subject_name, area=area_name, weight=1.0)
        db.session.add(subject); db.session.flush(); subjects[subject_name] = subject
        for topic_name in topic_names:
            topic = Topic(subject_id=subject.id, name=topic_name, importance=1.0)
            db.session.add(topic); db.session.flush(); topics[(subject_name, topic_name)] = topic
    for _, topic_name, *_ in QUESTION_BANK:
        subject_name, area_name = TOPIC_TAXONOMY[topic_name]
        if subject_name not in subjects:
            subject = Subject(exam_id=enem.id, name=subject_name, area=area_name, weight=1.0)
            db.session.add(subject); db.session.flush(); subjects[subject_name] = subject
        key = (subject_name, topic_name)
        if key not in topics:
            topic = Topic(subject_id=subjects[subject_name].id, name=topic_name, importance=1.2 if topic_name in {"Interpretação", "Porcentagem", "Ecologia"} else 1.0)
            db.session.add(topic); db.session.flush(); topics[key] = topic
    for _, topic_name, difficulty, statement, options, correct, explanation in QUESTION_BANK:
        subject_name, _ = TOPIC_TAXONOMY[topic_name]
        digest = hashlib.sha256(" ".join(statement.lower().split()).encode()).hexdigest()
        question = Question(exam_id=enem.id, subject_id=subjects[subject_name].id, topic_id=topics[(subject_name, topic_name)].id, statement=statement, difficulty=difficulty, explanation=explanation, author_type="authorial", author_name="Equipe Evolvo", source_label="Banco autoral Evolvo", license_note="Conteúdo autoral para demonstração acadêmica", content_hash=digest, status="approved")
        db.session.add(question); db.session.flush()
        for position, text in enumerate(options, 1):
            db.session.add(QuestionOption(question_id=question.id, position=position, text=text, is_correct=(position - 1 == correct)))
    admin = User(name="Administrador Evolvo", email="admin@evolvo.local", role="admin"); admin.set_password("Admin123!")
    demo = User(name="Estudante Demo", email="demo@evolvo.local"); demo.set_password("Demo123!")
    db.session.add_all([admin, demo]); db.session.flush()
    for user in (admin, demo):
        db.session.add_all([
            UserConsent(user_id=user.id, consent_type=kind, version="2.1", accepted=True)
            for kind in ("terms", "privacy_notice", "academic_processing", "age_responsibility")
        ])
    db.session.add(UserGoal(user_id=demo.id, exam_id=enem.id, exam_date=date.today() + timedelta(days=120), daily_minutes=60, study_days=[0,1,2,3,4,5], preferences={"focus": "balanced"}, active=True))
    teachers = [
        Teacher(name="Ana Martins", biography="Professora de Matemática com foco em resolução de problemas e preparação para o ENEM.", hourly_price=75, modality="both", city="São Paulo — SP", contact="Contato disponibilizado após solicitação", is_test_data=True, subjects=[subjects["Matemática"]]),
        Teacher(name="Bruno Almeida", biography="Professor de Física e Biologia. Trabalha conceitos por experimentos e situações do cotidiano.", hourly_price=65, modality="online", city=None, contact="Contato disponibilizado após solicitação", is_test_data=True, subjects=[subjects["Física"], subjects["Biologia"]]),
        Teacher(name="Carla Nogueira", biography="Professora de Língua Portuguesa, redação e interpretação de textos para vestibulares.", hourly_price=90, modality="presential", city="Campinas — SP", contact="Contato disponibilizado após solicitação", is_test_data=True, subjects=[subjects["Língua Portuguesa"]]),
        Teacher(name="Diego Santos", biography="Professor de História, Geografia e Sociologia com abordagem interdisciplinar.", hourly_price=55, modality="both", city="Rio de Janeiro — RJ", contact="Contato disponibilizado após solicitação", is_test_data=True, subjects=[subjects["História"], subjects["Geografia"], subjects["Sociologia"]]),
    ]
    db.session.add_all(teachers); db.session.flush()
    db.session.add_all([
        TeacherReview(teacher_id=teachers[0].id, user_id=demo.id, rating=5, comment="Explicação clara e objetiva."),
        TeacherReview(teacher_id=teachers[1].id, user_id=demo.id, rating=4, comment="Boa organização da aula."),
    ])
    db.session.commit()
    print(f"Seed concluído: {len(QUESTION_BANK)} questões autorais, usuário demo@evolvo.local / Demo123!")


if __name__ == "__main__":
    with create_app().app_context():
        seed()

