"""add essay training

Revision ID: a63d7e9f1b42
Revises: f52c8d3e0a21
"""
from alembic import op
import sqlalchemy as sa


revision = "a63d7e9f1b42"
down_revision = "f52c8d3e0a21"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "essay_prompts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("exam_id", sa.Integer(), sa.ForeignKey("exams.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(length=180), nullable=False),
        sa.Column("theme", sa.Text(), nullable=False),
        sa.Column("instructions", sa.Text(), nullable=False),
        sa.Column("support_texts", sa.JSON(), nullable=False),
        sa.Column("source_label", sa.String(length=200), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_essay_prompts_exam_id", "essay_prompts", ["exam_id"])
    op.create_index("ix_essay_prompts_status", "essay_prompts", ["status"])
    op.create_table(
        "essay_submissions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("prompt_id", sa.Integer(), sa.ForeignKey("essay_prompts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("draft_text", sa.Text(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("word_count", sa.Integer(), nullable=False),
        sa.Column("analysis", sa.JSON(), nullable=False),
        sa.Column("submitted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_essay_submissions_user_id", "essay_submissions", ["user_id"])
    op.create_index("ix_essay_submissions_prompt_id", "essay_submissions", ["prompt_id"])
    op.create_index("ix_essay_submissions_status", "essay_submissions", ["status"])


def downgrade():
    op.drop_table("essay_submissions")
    op.drop_table("essay_prompts")
