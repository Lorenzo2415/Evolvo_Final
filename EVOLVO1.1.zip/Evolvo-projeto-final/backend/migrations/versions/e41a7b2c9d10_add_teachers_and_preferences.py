"""add teachers, reviews and subject preferences

Revision ID: e41a7b2c9d10
Revises: d3f91a2c7b40
Create Date: 2026-10-19
"""
from alembic import op
import sqlalchemy as sa

revision = "e41a7b2c9d10"
down_revision = "d3f91a2c7b40"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("subject_preferences",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("subject_id", sa.Integer(), sa.ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("priority", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("user_id", "subject_id"), sa.CheckConstraint("priority >= 1 AND priority <= 3"))
    op.create_index("ix_subject_preferences_user_id", "subject_preferences", ["user_id"])
    op.create_index("ix_subject_preferences_subject_id", "subject_preferences", ["subject_id"])
    op.create_table("teachers",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False), sa.Column("biography", sa.Text(), nullable=False),
        sa.Column("avatar_url", sa.String(500)), sa.Column("hourly_price", sa.Float(), nullable=False),
        sa.Column("modality", sa.String(20), nullable=False), sa.Column("city", sa.String(120)),
        sa.Column("contact", sa.String(200)), sa.Column("is_test_data", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False))
    op.create_index("ix_teachers_name", "teachers", ["name"]); op.create_index("ix_teachers_hourly_price", "teachers", ["hourly_price"]); op.create_index("ix_teachers_modality", "teachers", ["modality"]); op.create_index("ix_teachers_city", "teachers", ["city"])
    op.create_table("teacher_subjects",
        sa.Column("teacher_id", sa.Integer(), sa.ForeignKey("teachers.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("subject_id", sa.Integer(), sa.ForeignKey("subjects.id", ondelete="CASCADE"), primary_key=True))
    op.create_table("teacher_reviews",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("teacher_id", sa.Integer(), sa.ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("rating", sa.Integer(), nullable=False), sa.Column("comment", sa.String(800)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("teacher_id", "user_id"), sa.CheckConstraint("rating >= 1 AND rating <= 5"))
    op.create_index("ix_teacher_reviews_teacher_id", "teacher_reviews", ["teacher_id"]); op.create_index("ix_teacher_reviews_user_id", "teacher_reviews", ["user_id"])


def downgrade():
    op.drop_table("teacher_reviews"); op.drop_table("teacher_subjects"); op.drop_table("teachers"); op.drop_table("subject_preferences")
