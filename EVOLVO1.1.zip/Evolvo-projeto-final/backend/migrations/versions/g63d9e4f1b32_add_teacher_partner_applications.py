"""add teacher partner applications

Revision ID: g63d9e4f1b32
Revises: f52c8d3e0a21
Create Date: 2026-10-22
"""
from alembic import op
import sqlalchemy as sa

revision = "g63d9e4f1b32"
down_revision = "b74e8f2a3c19"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "teacher_partner_applications",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("biography", sa.Text(), nullable=False),
        sa.Column("hourly_price", sa.Float(), nullable=False),
        sa.Column("modality", sa.String(length=20), nullable=False),
        sa.Column("city", sa.String(length=120)),
        sa.Column("contact", sa.String(length=200), nullable=False),
        sa.Column("subject_ids", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="pending"),
        sa.Column("reviewed_by", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("reviewed_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("user_id"),
        sa.CheckConstraint("status IN ('pending', 'approved', 'rejected')"),
    )
    op.create_index("ix_teacher_partner_applications_user_id", "teacher_partner_applications", ["user_id"])
    op.create_index("ix_teacher_partner_applications_status", "teacher_partner_applications", ["status"])
    op.create_index("ix_teacher_partner_applications_reviewed_by", "teacher_partner_applications", ["reviewed_by"])


def downgrade():
    op.drop_table("teacher_partner_applications")
