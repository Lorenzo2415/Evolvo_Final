"""add question media

Revision ID: f52c8d3e0a21
Revises: e41a7b2c9d10
Create Date: 2026-10-20
"""
from alembic import op
import sqlalchemy as sa

revision = "f52c8d3e0a21"
down_revision = "e41a7b2c9d10"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("questions", sa.Column("media", sa.JSON(), nullable=False, server_default="{}"))


def downgrade():
    op.drop_column("questions", "media")
