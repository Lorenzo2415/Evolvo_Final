"""split ENEM areas into selectable subjects

Revision ID: d3f91a2c7b40
Revises: c2484e3bb17a
Create Date: 2026-10-13

"""
from datetime import datetime, timezone

from alembic import op
import sqlalchemy as sa


revision = "d3f91a2c7b40"
down_revision = "c2484e3bb17a"
branch_labels = None
depends_on = None


TOPIC_TAXONOMY = {
    "Porcentagem": ("Matemática", "Matemática"),
    "Probabilidade": ("Matemática", "Matemática"),
    "Funções": ("Matemática", "Matemática"),
    "Interpretação": ("Língua Portuguesa", "Linguagens"),
    "Variação linguística": ("Língua Portuguesa", "Linguagens"),
    "Gêneros textuais": ("Língua Portuguesa", "Linguagens"),
    "Coesão": ("Língua Portuguesa", "Linguagens"),
    "Ecologia": ("Biologia", "Ciências da Natureza"),
    "Genética": ("Biologia", "Ciências da Natureza"),
    "Energia": ("Física", "Ciências da Natureza"),
    "Movimento": ("Física", "Ciências da Natureza"),
    "Urbanização": ("Geografia", "Ciências Humanas"),
    "Cartografia": ("Geografia", "Ciências Humanas"),
    "Industrialização": ("História", "Ciências Humanas"),
    "Cidadania": ("Sociologia", "Ciências Humanas"),
    "Democracia": ("Sociologia", "Ciências Humanas"),
}


def _tables(connection):
    metadata = sa.MetaData()
    return (
        sa.Table("subjects", metadata, autoload_with=connection),
        sa.Table("topics", metadata, autoload_with=connection),
        sa.Table("questions", metadata, autoload_with=connection),
    )


def _ensure_subject(connection, subjects, exam_id, name, area):
    subject_id = connection.execute(
        sa.select(subjects.c.id).where(subjects.c.exam_id == exam_id, subjects.c.name == name)
    ).scalar()
    if subject_id:
        connection.execute(subjects.update().where(subjects.c.id == subject_id).values(area=area))
        return subject_id
    now = datetime.now(timezone.utc)
    result = connection.execute(subjects.insert().values(
        exam_id=exam_id,
        name=name,
        area=area,
        weight=1.0,
        created_at=now,
        updated_at=now,
    ))
    return result.inserted_primary_key[0]


def _move_topic(connection, subjects, topics, questions, exam_id, topic_name, subject_id):
    topic_ids = connection.execute(
        sa.select(topics.c.id)
        .select_from(topics.join(subjects, topics.c.subject_id == subjects.c.id))
        .where(subjects.c.exam_id == exam_id, topics.c.name == topic_name)
    ).scalars().all()
    if not topic_ids:
        return
    connection.execute(topics.update().where(topics.c.id.in_(topic_ids)).values(subject_id=subject_id))
    connection.execute(questions.update().where(questions.c.topic_id.in_(topic_ids)).values(subject_id=subject_id))


def upgrade():
    connection = op.get_bind()
    exam_id = connection.execute(sa.text("SELECT id FROM exams WHERE slug = 'enem'")).scalar()
    if not exam_id:
        return
    subjects, topics, questions = _tables(connection)
    target_ids = {}
    for name, area in set(TOPIC_TAXONOMY.values()):
        target_ids[name] = _ensure_subject(connection, subjects, exam_id, name, area)
    for topic_name, (name, _) in TOPIC_TAXONOMY.items():
        _move_topic(connection, subjects, topics, questions, exam_id, topic_name, target_ids[name])
    connection.execute(subjects.delete().where(
        subjects.c.exam_id == exam_id,
        subjects.c.name.in_(["Linguagens", "Ciências da Natureza", "Ciências Humanas"]),
    ))


def downgrade():
    connection = op.get_bind()
    exam_id = connection.execute(sa.text("SELECT id FROM exams WHERE slug = 'enem'")).scalar()
    if not exam_id:
        return
    subjects, topics, questions = _tables(connection)
    broad_ids = {
        area: _ensure_subject(connection, subjects, exam_id, area, area)
        for area in ["Matemática", "Linguagens", "Ciências da Natureza", "Ciências Humanas"]
    }
    granular = connection.execute(
        sa.select(subjects.c.id, subjects.c.name, subjects.c.area).where(subjects.c.exam_id == exam_id)
    ).all()
    for subject_id, name, area in granular:
        target_id = broad_ids.get(area)
        if not target_id or subject_id == target_id:
            continue
        topic_ids = connection.execute(sa.select(topics.c.id).where(topics.c.subject_id == subject_id)).scalars().all()
        if topic_ids:
            connection.execute(topics.update().where(topics.c.id.in_(topic_ids)).values(subject_id=target_id))
            connection.execute(questions.update().where(questions.c.topic_id.in_(topic_ids)).values(subject_id=target_id))
        connection.execute(subjects.delete().where(subjects.c.id == subject_id))
