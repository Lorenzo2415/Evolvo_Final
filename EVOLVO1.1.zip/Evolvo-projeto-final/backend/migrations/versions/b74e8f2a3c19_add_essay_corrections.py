"""add essay corrections

Revision ID: b74e8f2a3c19
Revises: a63d7e9f1b42
"""
from alembic import op
import sqlalchemy as sa


revision = "b74e8f2a3c19"
down_revision = "a63d7e9f1b42"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "essay_corrections",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("submission_id", sa.Integer(), sa.ForeignKey("essay_submissions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("feedback", sa.JSON(), nullable=False),
        sa.Column("reviewer_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("requested_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("submission_id", "kind"),
        sa.CheckConstraint("kind IN ('ai', 'human')"),
    )
    op.create_index("ix_essay_corrections_submission_id", "essay_corrections", ["submission_id"])
    op.create_index("ix_essay_corrections_kind", "essay_corrections", ["kind"])
    op.create_index("ix_essay_corrections_status", "essay_corrections", ["status"])
    op.create_index("ix_essay_corrections_reviewer_id", "essay_corrections", ["reviewer_id"])


def downgrade():
    op.drop_table("essay_corrections")
