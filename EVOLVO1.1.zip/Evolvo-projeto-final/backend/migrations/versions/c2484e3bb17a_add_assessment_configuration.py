"""add assessment configuration snapshot

Revision ID: c2484e3bb17a
Revises: 8f6e517450ac
Create Date: 2026-10-13

"""
from alembic import op
import sqlalchemy as sa


revision = "c2484e3bb17a"
down_revision = "8f6e517450ac"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assessments", sa.Column("configuration", sa.JSON(), nullable=False, server_default="{}"))


def downgrade():
    op.drop_column("assessments", "configuration")
