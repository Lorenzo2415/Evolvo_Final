"""add teacher contact requests

Revision ID: h74e0f5a2c43
Revises: g63d9e4f1b32
Create Date: 2026-10-23
"""
from alembic import op
import sqlalchemy as sa

revision = "h74e0f5a2c43"
down_revision = "g63d9e4f1b32"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("teachers") as batch:
        batch.add_column(sa.Column("user_id", sa.Integer(), nullable=True))
        batch.create_foreign_key("fk_teachers_user_id", "users", ["user_id"], ["id"], ondelete="SET NULL")
        batch.create_unique_constraint("uq_teachers_user_id", ["user_id"])
        batch.create_index("ix_teachers_user_id", ["user_id"])

    connection = op.get_bind()
    rows = connection.execute(sa.text("""
        SELECT a.user_id, u.name, a.contact
        FROM teacher_partner_applications a
        JOIN users u ON u.id = a.user_id
        WHERE a.status = 'approved'
    """)).fetchall()
    for user_id, name, contact in rows:
        connection.execute(sa.text("""
            UPDATE teachers SET user_id = :user_id
            WHERE id = (
                SELECT id FROM teachers
                WHERE user_id IS NULL AND name = :name AND contact = :contact
                ORDER BY id DESC LIMIT 1
            )
        """), {"user_id": user_id, "name": name, "contact": contact})

    op.create_table(
        "teacher_contact_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("teacher_id", sa.Integer(), sa.ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("student_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("subject_id", sa.Integer(), sa.ForeignKey("subjects.id", ondelete="SET NULL")),
        sa.Column("message", sa.String(length=1000), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="new"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("status IN ('new', 'contacted', 'closed')"),
    )
    op.create_index("ix_teacher_contact_requests_teacher_id", "teacher_contact_requests", ["teacher_id"])
    op.create_index("ix_teacher_contact_requests_student_id", "teacher_contact_requests", ["student_id"])
    op.create_index("ix_teacher_contact_requests_subject_id", "teacher_contact_requests", ["subject_id"])
    op.create_index("ix_teacher_contact_requests_status", "teacher_contact_requests", ["status"])


def downgrade():
    op.drop_table("teacher_contact_requests")
    with op.batch_alter_table("teachers") as batch:
        batch.drop_index("ix_teachers_user_id")
        batch.drop_constraint("uq_teachers_user_id", type_="unique")
        batch.drop_constraint("fk_teachers_user_id", type_="foreignkey")
        batch.drop_column("user_id")
