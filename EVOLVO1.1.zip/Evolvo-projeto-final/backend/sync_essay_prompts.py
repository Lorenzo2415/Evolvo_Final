"""Adiciona propostas autorais de redação sem apagar rascunhos existentes."""
from app import create_app
from app.extensions import db
from app.models.entities import EssayPrompt, Exam


PROMPTS = [
    ("Cidadania digital", "Desafios para combater a desinformação digital no Brasil", [
        {"title": "Contexto", "text": "A circulação acelerada de conteúdos amplia o acesso à informação, mas também favorece mensagens falsas fora de contexto."},
        {"title": "Ponto de reflexão", "text": "Educação midiática, transparência das plataformas e responsabilização devem preservar simultaneamente segurança e liberdade de expressão."},
    ]),
    ("Inclusão educacional", "Caminhos para reduzir a desigualdade de acesso à educação de qualidade no Brasil", [
        {"title": "Contexto", "text": "Infraestrutura, permanência escolar, formação docente e desigualdades territoriais afetam de maneiras diferentes a trajetória dos estudantes."},
        {"title": "Ponto de reflexão", "text": "Garantir matrícula é essencial, mas aprendizagem e permanência também dependem de políticas públicas coordenadas."},
    ]),
    ("Saúde mental", "A importância da promoção da saúde mental entre jovens brasileiros", [
        {"title": "Contexto", "text": "Pressões escolares, relações digitais e desigualdades sociais podem afetar o bem-estar emocional dos jovens."},
        {"title": "Ponto de reflexão", "text": "Prevenção, acolhimento e acesso a atendimento especializado exigem articulação entre família, escola, saúde e comunidade."},
    ]),
    ("Sustentabilidade urbana", "Obstáculos à construção de cidades brasileiras mais sustentáveis e inclusivas", [
        {"title": "Contexto", "text": "Mobilidade, moradia, saneamento, áreas verdes e adaptação climática integram o planejamento urbano sustentável."},
        {"title": "Ponto de reflexão", "text": "Os impactos ambientais e a falta de infraestrutura atingem de forma mais intensa grupos socialmente vulneráveis."},
    ]),
]


def sync():
    exam = Exam.query.filter_by(slug="enem").first()
    created = 0
    for title, theme, support_texts in PROMPTS:
        if EssayPrompt.query.filter_by(exam_id=exam.id, theme=theme).first():
            continue
        db.session.add(EssayPrompt(
            exam_id=exam.id, title=title, theme=theme,
            instructions="Escreva um texto dissertativo-argumentativo em modalidade formal da língua portuguesa, com tese, argumentos articulados e proposta de intervenção que respeite os direitos humanos.",
            support_texts=support_texts,
        ))
        created += 1
    db.session.commit()
    print(f"Propostas de redação sincronizadas: {created} novas.")


if __name__ == "__main__":
    with create_app().app_context():
        sync()
