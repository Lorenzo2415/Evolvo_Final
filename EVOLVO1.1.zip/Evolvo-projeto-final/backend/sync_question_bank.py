"""Adiciona ao banco existente as questões autorais ausentes, sem apagar usuários."""
import hashlib

from app import create_app
from app.extensions import db
from app.models.entities import Exam, Question, QuestionOption, Subject, Topic
from seed import QUESTION_BANK, TOPIC_TAXONOMY


def sync():
    exam = Exam.query.filter_by(slug="enem").first()
    if not exam:
        raise RuntimeError("Cadastre o ENEM antes de sincronizar o banco de questões.")

    subjects = {item.name: item for item in Subject.query.filter_by(exam_id=exam.id).all()}
    topics = {(item.subject.name, item.name): item for item in Topic.query.join(Subject).filter(Subject.exam_id == exam.id).all()}
    created = 0

    for _, topic_name, difficulty, statement, options, correct, explanation in QUESTION_BANK:
        subject_name, area_name = TOPIC_TAXONOMY[topic_name]
        subject = subjects.get(subject_name)
        if not subject:
            subject = Subject(exam_id=exam.id, name=subject_name, area=area_name, weight=1.0)
            db.session.add(subject)
            db.session.flush()
            subjects[subject_name] = subject

        key = (subject_name, topic_name)
        topic = topics.get(key)
        if not topic:
            topic = Topic(subject_id=subject.id, name=topic_name, importance=1.2 if topic_name in {"Interpretação", "Porcentagem", "Ecologia"} else 1.0)
            db.session.add(topic)
            db.session.flush()
            topics[key] = topic

        digest = hashlib.sha256(" ".join(statement.lower().split()).encode()).hexdigest()
        if Question.query.filter_by(content_hash=digest).first():
            continue
        question = Question(
            exam_id=exam.id,
            subject_id=subject.id,
            topic_id=topic.id,
            statement=statement,
            difficulty=difficulty,
            explanation=explanation,
            author_type="authorial",
            author_name="Equipe Evolvo",
            source_label="Banco autoral Evolvo",
            license_note="Conteúdo autoral para demonstração acadêmica",
            content_hash=digest,
            status="approved",
        )
        db.session.add(question)
        db.session.flush()
        for position, text in enumerate(options, 1):
            db.session.add(QuestionOption(question_id=question.id, position=position, text=text, is_correct=(position - 1 == correct)))
        created += 1

    db.session.commit()
    print(f"Banco sincronizado: {created} novas questões; {Question.query.filter_by(exam_id=exam.id, status='approved').count()} aprovadas no total.")


if __name__ == "__main__":
    with create_app().app_context():
        sync()
