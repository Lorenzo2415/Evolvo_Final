"""Importa questões oficiais textuais da API ENEM sem duplicar registros."""
import hashlib
import os
import re
import time

import requests

from app import create_app
from app.extensions import db
from app.models.entities import Exam, Question, QuestionOption, Subject, Topic
from app.services.question_taxonomy import ENEM_TAXONOMY, infer_subject, infer_topic


API_ROOT = "https://api.enem.dev/v1"
YEARS = [int(value) for value in os.getenv("ENEM_IMPORT_YEARS", ",".join(str(year) for year in range(2009, 2024))).split(",")]
DISCIPLINES = {
    "matematica": ("Matemática", "Matemática"),
    "linguagens": ("Língua Portuguesa", "Linguagens"),
    "ciencias-humanas": ("Ciências Humanas", "Ciências Humanas"),
    "ciencias-natureza": ("Ciências da Natureza", "Ciências da Natureza"),
}


def normalized_hash(text):
    return hashlib.sha256(" ".join(text.lower().split()).encode("utf-8")).hexdigest()


def file_url(value):
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return value.get("url") or value.get("filePath") or value.get("path")
    return None


def media_payload(record):
    statement = [file_url(value) for value in (record.get("files") or [])]
    markdown_urls = re.findall(r"!\[[^\]]*\]\((https?://[^)]+)\)", f"{record.get('context') or ''}\n{record.get('alternativesIntroduction') or ''}")
    statement.extend(markdown_urls)
    statement = list(dict.fromkeys(url for url in statement if url and "broken-image.svg" not in url))
    options = {}
    for position, option in enumerate(record.get("alternatives") or [], 1):
        url = file_url(option.get("file"))
        if url and "broken-image.svg" not in url:
            options[str(position)] = [url]
    return {"statement": statement, "options": options} if statement or options else {}


def usable(record):
    statement = f"{record.get('context') or ''}\n\n{record.get('alternativesIntroduction') or ''}".strip()
    alternatives = record.get("alternatives") or []
    media = media_payload(record)
    return (
        record.get("discipline") in DISCIPLINES
        and not record.get("language")
        and len(alternatives) >= 4
        and all((item.get("text") or "").strip() or file_url(item.get("file")) for item in alternatives)
        and sum(bool(item.get("isCorrect")) for item in alternatives) == 1
        and ("![" not in statement or bool(media.get("statement")))
    )


def clean_markdown(text):
    text = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", text or "")
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text or "")
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def fetch_year(year):
    questions = []
    offset = 0
    while True:
        for attempt in range(5):
            response = requests.get(f"{API_ROOT}/exams/{year}/questions", params={"limit": 50, "offset": offset}, timeout=45)
            if response.status_code != 429:
                break
            time.sleep(min(10, 2 ** attempt))
        response.raise_for_status()
        payload = response.json()
        batch = payload.get("questions", [])
        questions.extend(batch)
        if not payload.get("metadata", {}).get("hasMore") or not batch:
            return questions
        offset += len(batch)
        time.sleep(0.8)


def sync():
    exam = Exam.query.filter_by(slug="enem").first()
    if not exam:
        raise RuntimeError("Cadastre o ENEM antes de importar questões oficiais.")
    subjects = {item.name: item for item in Subject.query.filter_by(exam_id=exam.id).all()}
    created = skipped = 0
    for year in YEARS:
        for record in fetch_year(year):
            if not usable(record):
                skipped += 1
                continue
            statement = clean_markdown(f"{record.get('context') or ''}\n\n{record.get('alternativesIntroduction') or ''}")
            broad_subject, _ = DISCIPLINES[record["discipline"]]
            subject_name = infer_subject(broad_subject, statement)
            area = ENEM_TAXONOMY[subject_name][0]
            subject = subjects.get(subject_name)
            if not subject:
                subject = Subject(exam_id=exam.id, name=subject_name, area=area, weight=1.0)
                db.session.add(subject)
                db.session.flush()
                subjects[subject_name] = subject
            topic_name = infer_topic(subject_name, statement)
            topic = Topic.query.filter_by(subject_id=subject.id, name=topic_name).first()
            if not topic:
                topic = Topic(subject_id=subject.id, name=topic_name, importance=1.0)
                db.session.add(topic)
                db.session.flush()
            digest = normalized_hash(statement)
            if Question.query.filter_by(content_hash=digest).first():
                skipped += 1
                continue
            identifier = f"ENEM-{year}-{record['index']}-{record['discipline']}"
            question = Question(
                exam_id=exam.id, subject_id=subject.id, topic_id=topic.id,
                statement=statement, difficulty="medium",
                explanation=f"Gabarito oficial: alternativa {record['correctAlternative']}. A fonte pública não fornece resolução comentada.",
                author_type="official", author_name="INEP",
                source_label=f"ENEM {year} — questão {record['index']}",
                source_url=f"{API_ROOT}/exams/{year}/questions/{record['index']}",
                license_note="Questão de prova pública obtida via API ENEM (GPL-2.0); fonte oficial identificada como INEP.",
                original_identifier=identifier, media=media_payload(record), content_hash=digest, status="approved",
            )
            db.session.add(question)
            db.session.flush()
            for position, option in enumerate(record["alternatives"], 1):
                db.session.add(QuestionOption(question_id=question.id, position=position, text=clean_markdown(option.get("text") or "Imagem da alternativa"), is_correct=bool(option["isCorrect"])))
            created += 1
        db.session.commit()
        print(f"ENEM {year}: sincronização concluída.")
    total = Question.query.filter_by(exam_id=exam.id, status="approved").count()
    print(f"Importação oficial concluída: {created} novas, {skipped} ignoradas/duplicadas, {total} aprovadas no total.")


if __name__ == "__main__":
    with create_app().app_context():
        sync()
