"""Sincroniza dados fictícios do catálogo sem remover contas ou históricos."""
from app import create_app
from app.extensions import db
from app.models.entities import Subject, Teacher, TeacherReview, User


TEACHERS = [
    ("Ana Martins", "Professora de Matemática com foco em resolução de problemas e preparação para o ENEM.", 75, "both", "São Paulo — SP", ["Matemática"]),
    ("Bruno Almeida", "Professor de Física e Biologia. Trabalha conceitos por experimentos e situações do cotidiano.", 65, "online", None, ["Física", "Biologia"]),
    ("Carla Nogueira", "Professora de Língua Portuguesa, redação e interpretação de textos para vestibulares.", 90, "presential", "Campinas — SP", ["Língua Portuguesa"]),
    ("Diego Santos", "Professor de História, Geografia e Sociologia com abordagem interdisciplinar.", 55, "both", "Rio de Janeiro — RJ", ["História", "Geografia", "Sociologia"]),
]


def sync():
    subjects = {item.name: item for item in Subject.query.all()}
    created = 0
    for name, biography, price, modality, city, subject_names in TEACHERS:
        teacher = Teacher.query.filter_by(name=name, is_test_data=True).first()
        if not teacher:
            teacher = Teacher(name=name, biography=biography, hourly_price=price, modality=modality, city=city, contact="Contato disponibilizado após solicitação", is_test_data=True)
            db.session.add(teacher)
            created += 1
        teacher.subjects = [subjects[item] for item in subject_names if item in subjects]
    db.session.flush()

    demo = User.query.filter_by(email="demo@evolvo.local").first()
    sample_reviews = {
        "Ana Martins": (5, "Explicação clara e objetiva."),
        "Bruno Almeida": (4, "Boa organização da aula."),
    }
    if demo:
        for teacher_name, (rating, comment) in sample_reviews.items():
            teacher = Teacher.query.filter_by(name=teacher_name, is_test_data=True).first()
            if teacher and not TeacherReview.query.filter_by(teacher_id=teacher.id, user_id=demo.id).first():
                db.session.add(TeacherReview(teacher_id=teacher.id, user_id=demo.id, rating=rating, comment=comment))
    db.session.commit()
    print(f"Catálogo sincronizado: {created} professores fictícios adicionados; {Teacher.query.count()} no total.")


if __name__ == "__main__":
    with create_app().app_context():
        sync()
