from datetime import datetime, timezone
from ..extensions import db
from ..errors import AppError
from ..models.entities import Assessment, AssessmentQuestion, Performance, ReviewSchedule, StudyPlan, StudyTask, Subject, Topic, UserGoal
from ..repositories import QuestionRepository, AnalyticsRepository
from .personalization import UpdatePerformanceService


class AssessmentFactory:
    TITLES = {"diagnostic": "Diagnóstico inicial", "exercise": "Lista adaptativa", "simulation": "Simulado personalizado", "review": "Revisão programada"}

    def __init__(self):
        self.questions = QuestionRepository()

    def create(self, user_id, exam_id, kind, limit, topic_ids=None, personalized=True, subject_ids=None, extra_configuration=None, difficulty=None):
        items = self.questions.select_for_user(user_id, exam_id, limit, kind, topic_ids, subject_ids, difficulty)
        if topic_ids and len(items) < limit:
            fallback = self.questions.select_for_user(user_id, exam_id, limit, kind, None, subject_ids, difficulty)
            existing_ids = {item.id for item in items}
            items.extend(item for item in fallback if item.id not in existing_ids)
            items = items[:limit]
        if not items:
            raise AppError("Não há questões aprovadas suficientes para esta seleção.", 409, "questions_unavailable")
        if len(items) < limit:
            raise AppError(f"Há somente {len(items)} questões aprovadas para esta seleção. Escolha uma quantidade menor ou mais matérias.", 409, "questions_unavailable")
        assessment = Assessment(
            user_id=user_id,
            exam_id=exam_id,
            kind=kind,
            title=self.TITLES[kind],
            total_questions=len(items),
            personalized=personalized,
            configuration={
                "requestedQuestionCount": limit,
                "subjectIds": subject_ids or [],
                "allSubjects": not bool(subject_ids),
                "difficulty": difficulty,
                "selectionStrategy": {
                    "diagnostic": "balanced_by_subject",
                    "exercise": "adaptive_within_selection",
                    "simulation": "balanced_exam_blueprint",
                    "review": "spaced_review",
                }[kind],
                **(extra_configuration or {}),
            },
        )
        db.session.add(assessment)
        db.session.flush()
        for position, question in enumerate(items, 1):
            db.session.add(AssessmentQuestion(assessment_id=assessment.id, question_id=question.id, position=position))
        db.session.commit()
        return assessment


def requested_count(data, default, maximum):
    try:
        value = int(data.get("questionCount", default))
    except (TypeError, ValueError):
        raise AppError("Quantidade de questões inválida.", 422, "invalid_question_count")
    if value < 1 or value > maximum:
        raise AppError(f"A quantidade deve ficar entre 1 e {maximum} questões.", 422, "invalid_question_count")
    return value


def requested_subjects(data, exam_id):
    raw = data.get("subjectIds") or []
    if not isinstance(raw, list):
        raise AppError("A seleção de matérias é inválida.", 422, "invalid_subjects")
    try:
        subject_ids = sorted({int(item) for item in raw})
    except (TypeError, ValueError):
        raise AppError("A seleção de matérias é inválida.", 422, "invalid_subjects")
    if not subject_ids:
        return None
    valid = {item.id for item in Subject.query.filter(Subject.exam_id == exam_id, Subject.id.in_(subject_ids)).all()}
    if valid != set(subject_ids):
        raise AppError("Uma das matérias não pertence à prova selecionada.", 422, "invalid_subjects")
    return subject_ids


class StartDiagnosticService:
    def execute(self, user_id, data):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo antes de iniciar o diagnóstico.", 409, "goal_required")
        exam_id = goal.exam_id
        subject_ids = requested_subjects(data, exam_id)
        count = requested_count(data, 20, 50)
        existing = Assessment.query.filter_by(user_id=user_id, exam_id=exam_id, kind="diagnostic", status="in_progress").first()
        requested_configuration = {"requestedQuestionCount": count, "subjectIds": subject_ids or []}
        if existing:
            current = existing.configuration or {}
            if all(current.get(key) == value for key, value in requested_configuration.items()):
                return existing
            db.session.delete(existing)
            db.session.commit()
        return AssessmentFactory().create(user_id, exam_id, "diagnostic", count, subject_ids=subject_ids)


class FinishAssessmentService:
    def execute(self, user_id, assessment_id, answers, expected_kind=None, timing=None):
        assessment = Assessment.query.filter_by(id=assessment_id, user_id=user_id).first()
        if not assessment:
            raise AppError("Atividade não encontrada.", 404, "assessment_not_found")
        if expected_kind and assessment.kind != expected_kind:
            raise AppError("Tipo de atividade inválido.", 409, "invalid_assessment_kind")
        if assessment.status == "completed":
            raise AppError("Esta atividade já foi finalizada.", 409, "already_completed")
        answer_map = {int(item["questionId"]): int(item["optionId"]) for item in answers if item.get("questionId") and item.get("optionId")}
        if len(answer_map) != assessment.total_questions:
            raise AppError("Responda todas as questões antes de finalizar.", 422, "incomplete_answers")
        correct = 0
        now = datetime.now(timezone.utc)
        for link in assessment.questions:
            selected = next((option for option in link.question.options if option.id == answer_map.get(link.question_id)), None)
            if not selected:
                raise AppError("Uma alternativa informada não pertence à questão.", 422, "invalid_option")
            link.selected_option_id = selected.id
            link.is_correct = selected.is_correct
            link.answered_at = now
            correct += int(selected.is_correct)
        assessment.correct_answers = correct
        assessment.score = round(100 * correct / assessment.total_questions, 1)
        assessment.status = "completed"
        assessment.completed_at = now
        if timing and isinstance(timing, dict):
            raw_question_times = timing.get("questionSeconds") or {}
            allowed_ids = {link.question_id for link in assessment.questions}
            question_times = {}
            if isinstance(raw_question_times, dict):
                for question_id, seconds in raw_question_times.items():
                    try:
                        parsed_id = int(question_id)
                        parsed_seconds = max(0, min(int(seconds), 86400))
                    except (TypeError, ValueError):
                        continue
                    if parsed_id in allowed_ids:
                        question_times[str(parsed_id)] = parsed_seconds
            configuration = dict(assessment.configuration or {})
            configuration["timing"] = {
                "totalSeconds": max(0, min(int(timing.get("totalSeconds", 0)), 604800)),
                "questionSeconds": question_times,
            }
            assessment.configuration = configuration
        UpdatePerformanceService().execute(user_id, assessment)
        from .plan_services import AdaptActivePlanService
        AdaptActivePlanService().execute(user_id)
        db.session.commit()
        return assessment


class FinishDiagnosticService(FinishAssessmentService):
    def execute(self, user_id, assessment_id, answers):
        return super().execute(user_id, assessment_id, answers, "diagnostic")


class AnalyzeDifficultiesService:
    def __init__(self):
        self.analytics = AnalyticsRepository()

    def execute(self, user_id, assessment_id):
        assessment = Assessment.query.filter_by(id=assessment_id, user_id=user_id, status="completed").first()
        if not assessment:
            raise AppError("Conclua o diagnóstico para consultar a análise.", 409, "diagnostic_incomplete")
        subjects = self.analytics.accuracy_by_subject(user_id, assessment.exam_id)
        topics = self.analytics.error_topics(user_id, assessment.exam_id)
        return {"assessmentId": assessment.id, "score": assessment.score, "subjects": subjects, "priorityTopics": topics}


class GenerateExerciseListService:
    def execute(self, user_id, data):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo.", 409, "goal_required")
        task = None
        task_id = data.get("taskId")
        if task_id:
            try:
                task_id = int(task_id)
            except (TypeError, ValueError):
                raise AppError("Sessão do plano inválida.", 422, "invalid_task")
            task = StudyTask.query.join(StudyPlan).join(UserGoal, StudyPlan.goal_id == UserGoal.id).filter(
                StudyTask.id == task_id,
                StudyPlan.user_id == user_id,
                StudyPlan.status == "active",
                UserGoal.active.is_(True),
                UserGoal.exam_id == goal.exam_id,
            ).first()
            if not task:
                raise AppError("Esta sessão não pertence ao seu plano ativo.", 404, "task_not_found")
            subject_ids = [task.topic.subject_id]
            topic_ids = [task.topic_id]
            task.status = "in_progress"
            task.started_at = task.started_at or datetime.now(timezone.utc)
        else:
            subject_ids = requested_subjects(data, goal.exam_id)
            priority_query = Performance.query.filter_by(user_id=user_id, exam_id=goal.exam_id)
            if subject_ids:
                priority_query = priority_query.join(Topic, Performance.topic_id == Topic.id).filter(Topic.subject_id.in_(subject_ids))
            priorities = priority_query.order_by(Performance.mastery.asc(), Performance.attempts.asc()).limit(4).all()
            topic_ids = [item.topic_id for item in priorities] or None
        return AssessmentFactory().create(
            user_id,
            goal.exam_id,
            "exercise",
            requested_count(data, 15, 50),
            topic_ids,
            subject_ids=subject_ids,
            extra_configuration={"taskId": task.id} if task else None,
        )


class FinishExerciseListService(FinishAssessmentService):
    def execute(self, user_id, assessment_id, answers, timing=None):
        assessment = Assessment.query.filter_by(id=assessment_id, user_id=user_id).first()
        if not assessment or assessment.kind not in {"exercise", "review"}:
            raise AppError("Lista de exercícios não encontrada.", 404, "assessment_not_found")
        result = super().execute(user_id, assessment_id, answers, timing=timing)
        task_id = (result.configuration or {}).get("taskId")
        if task_id:
            task = StudyTask.query.join(StudyPlan).filter(
                StudyTask.id == task_id,
                StudyPlan.user_id == user_id,
                StudyPlan.status == "active",
            ).first()
            if task:
                task.status = "completed"
                task.completed_at = datetime.now(timezone.utc)
                db.session.commit()
        return result


class GetCommentedResolutionService:
    def execute(self, user_id, assessment_id):
        assessment = Assessment.query.filter_by(id=assessment_id, user_id=user_id, status="completed").first()
        if not assessment:
            raise AppError("A resolução fica disponível após a conclusão.", 409, "assessment_incomplete")
        return assessment


class GenerateReviewService:
    def execute(self, user_id, data):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo.", 409, "goal_required")
        now = datetime.now(timezone.utc)
        schedules = ReviewSchedule.query.join(Topic, ReviewSchedule.topic_id == Topic.id).join(Subject, Topic.subject_id == Subject.id).filter(ReviewSchedule.user_id == user_id, ReviewSchedule.next_review_at <= now, Subject.exam_id == goal.exam_id).order_by(ReviewSchedule.next_review_at.asc()).limit(5).all()
        topic_ids = [item.topic_id for item in schedules]
        if not topic_ids:
            topic_ids = [item.topic_id for item in Performance.query.filter_by(user_id=user_id, exam_id=goal.exam_id).order_by(Performance.mastery.asc()).limit(3)]
        return AssessmentFactory().create(user_id, goal.exam_id, "review", requested_count(data, 5, 10), topic_ids or None)


class GenerateSimulationService:
    def execute(self, user_id, data):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo.", 409, "goal_required")
        blueprint = data.get("blueprint", "custom")
        blueprints = {
            "custom": None,
            "day1": {"Linguagens", "Ciências Humanas"},
            "day2": {"Matemática", "Ciências da Natureza"},
            "full": {"Linguagens", "Ciências Humanas", "Matemática", "Ciências da Natureza"},
        }
        if blueprint not in blueprints:
            raise AppError("Formato de simulado inválido.", 422, "invalid_blueprint")
        if blueprints[blueprint]:
            subject_ids = [item.id for item in Subject.query.filter(
                Subject.exam_id == goal.exam_id,
                Subject.area.in_(blueprints[blueprint]),
            ).all()]
        else:
            subject_ids = requested_subjects(data, goal.exam_id)
        difficulty = data.get("difficulty")
        if difficulty and difficulty not in {"easy", "medium", "hard"}:
            raise AppError("Dificuldade inválida.", 422, "invalid_difficulty")
        expected_counts = {"day1": 90, "day2": 90, "full": 180}
        count = expected_counts.get(blueprint, requested_count(data, 30, 180))
        return AssessmentFactory().create(
            user_id, goal.exam_id, "simulation", count, personalized=True,
            subject_ids=subject_ids, difficulty=difficulty,
            extra_configuration={"blueprint": blueprint, "includesEssay": False},
        )


class FinishSimulationService(FinishAssessmentService):
    def execute(self, user_id, assessment_id, answers, timing=None):
        return super().execute(user_id, assessment_id, answers, "simulation", timing=timing)

