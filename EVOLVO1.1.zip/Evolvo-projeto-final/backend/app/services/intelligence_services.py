from datetime import date
from ..errors import AppError
from ..models.entities import Assessment, Performance, StudyPlan, StudyTask, User, UserGoal
from ..repositories import AnalyticsRepository
from .personalization import UpdatePerformanceService


class RefreshPerformanceProfileService:
    def execute(self, user_id):
        assessments = Assessment.query.filter_by(user_id=user_id, status="completed").order_by(Assessment.completed_at.asc()).all()
        Performance.query.filter_by(user_id=user_id).delete()
        for assessment in assessments:
            UpdatePerformanceService().execute(user_id, assessment)
        from ..extensions import db
        db.session.commit()
        return Performance.query.filter_by(user_id=user_id).all()


class GenerateEvolutionReportService:
    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo.", 409, "goal_required")
        repo = AnalyticsRepository()
        subjects = [item for item in repo.accuracy_by_subject(user_id, goal.exam_id) if item["answered"]]
        evolution = repo.evolution_by_day(user_id, goal.exam_id)
        total = sum(item["answered"] for item in subjects)
        correct = sum(item["correct"] for item in subjects)
        return {"overallAccuracy": round(100 * correct / total, 1) if total else 0, "totalAnswered": total, "subjects": subjects, "evolution": evolution, "errorTopics": repo.error_topics(user_id, goal.exam_id)}


class RecommendNextStudyService:
    def execute(self, user_id):
        plan = StudyPlan.query.filter_by(user_id=user_id, status="active").order_by(StudyPlan.created_at.desc()).first()
        if not plan:
            raise AppError("Gere um plano para receber recomendações.", 409, "plan_required")
        task = StudyTask.query.filter(StudyTask.plan_id == plan.id, StudyTask.status != "completed").order_by(StudyTask.scheduled_date.asc(), StudyTask.priority_score.desc()).first()
        if not task:
            return {"completed": True, "message": "Seu plano atual está concluído."}
        return {"completed": False, "taskId": task.id, "title": task.title, "scheduledDate": task.scheduled_date.isoformat(), "priorityScore": task.priority_score, "reason": task.reason, "action": "review" if task.scheduled_date <= date.today() else "prepare"}


class GetDashboardService:
    """Consolida métricas e recomendações da visão geral em um único caso de uso."""

    def execute(self, user_id):
        user = User.query.filter_by(id=user_id, is_active=True).first()
        if not user:
            raise AppError("Usuário não encontrado.", 404, "user_not_found")
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            return {
                "userName": user.name,
                "goal": None,
                "todayTasks": [],
                "metrics": {"accuracy": 0, "answered": 0, "planProgress": 0},
                "evolution": [],
                "priorities": [],
                "recent": [],
            }

        repo = AnalyticsRepository()
        plan = StudyPlan.query.filter_by(user_id=user_id, goal_id=goal.id, status="active").first()
        tasks = plan.tasks if plan else []
        completed = sum(1 for task in tasks if task.status == "completed")
        subjects = repo.accuracy_by_subject(user_id, goal.exam_id)
        answered = sum(item["answered"] for item in subjects)
        correct = sum(item["correct"] for item in subjects)
        today_tasks = StudyTask.query.filter_by(plan_id=plan.id, scheduled_date=date.today()).all() if plan else []
        return {
            "userName": user.name,
            "goal": {
                "exam": goal.exam.name,
                "examDate": goal.exam_date.isoformat(),
                "daysRemaining": max(0, (goal.exam_date - date.today()).days),
            },
            "metrics": {
                "accuracy": round(100 * correct / answered, 1) if answered else 0,
                "answered": answered,
                "planProgress": round(100 * completed / len(tasks), 1) if tasks else 0,
            },
            "todayTasks": today_tasks,
            "priorities": repo.error_topics(user_id, goal.exam_id, 4),
            "evolution": repo.evolution_by_day(user_id, goal.exam_id),
            "recent": repo.recent_history(user_id, goal.exam_id),
        }

