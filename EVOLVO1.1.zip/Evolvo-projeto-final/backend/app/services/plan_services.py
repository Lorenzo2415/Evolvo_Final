from datetime import date, datetime, timedelta, timezone
from ..extensions import db
from ..errors import AppError
from ..models.entities import Assessment, Performance, Question, ReviewSchedule, StudyPlan, StudyTask, SubjectPreference, Topic, UserGoal
from .personalization import PriorityEngine


class GenerateStudyPlanService:
    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo antes de gerar o plano.", 409, "goal_required")
        diagnostic = Assessment.query.filter_by(user_id=user_id, exam_id=goal.exam_id, kind="diagnostic", status="completed").order_by(Assessment.completed_at.desc()).first()
        if not diagnostic:
            raise AppError("Conclua um diagnóstico da prova selecionada antes de gerar o plano.", 409, "diagnostic_required")
        StudyPlan.query.filter_by(user_id=user_id, status="active").update({"status": "archived"})
        previous = StudyPlan.query.filter_by(user_id=user_id, goal_id=goal.id).order_by(StudyPlan.version.desc()).first()
        plan = StudyPlan(user_id=user_id, goal_id=goal.id, version=(previous.version + 1 if previous else 1), rationale={"formula": PriorityEngine.WEIGHTS, "source": "desempenho, importância, evidência, urgência e revisão"})
        db.session.add(plan)
        db.session.flush()
        self._build_tasks(plan, goal)
        db.session.commit()
        return plan

    def _build_tasks(self, plan, goal, start=None):
        start = start or date.today()
        days_to_exam = max(1, (goal.exam_date - start).days)
        topics = Topic.query.join(Topic.subject).join(Question, Question.topic_id == Topic.id).filter_by(exam_id=goal.exam_id).filter(Question.status == "approved").distinct().all()
        performances = {p.topic_id: p for p in Performance.query.filter_by(user_id=goal.user_id, exam_id=goal.exam_id)}
        reviews = {r.topic_id: r for r in ReviewSchedule.query.filter_by(user_id=goal.user_id)}
        preferences = {item.subject_id: item.priority for item in SubjectPreference.query.filter_by(user_id=goal.user_id)}
        ranked = self._rank_topics(topics, performances, reviews, preferences, days_to_exam)
        cursor = start
        created = 0
        max_tasks = min(28, max(10, days_to_exam))
        while created < max_tasks and cursor <= goal.exam_date:
            if cursor.weekday() in goal.study_days:
                score, topic, parts = ranked[created % len(ranked)]
                values = self._task_values(topic, performances.get(topic.id), score, parts)
                db.session.add(StudyTask(plan_id=plan.id, topic_id=topic.id, scheduled_date=cursor, duration_minutes=goal.daily_minutes, **values))
                created += 1
            cursor += timedelta(days=1)

    def _rank_topics(self, topics, performances, reviews, preferences, days_to_exam):
        engine = PriorityEngine()
        ranked = []
        now = datetime.now(timezone.utc)
        for topic in topics:
            perf = performances.get(topic.id)
            review = reviews.get(topic.id)
            review_due = False
            if review:
                next_review = review.next_review_at
                if next_review.tzinfo is None:
                    next_review = next_review.replace(tzinfo=timezone.utc)
                review_due = next_review <= now
            # Ausência de evidência não significa domínio zero. Usamos um ponto neutro
            # e deixamos a parcela de baixa evidência incentivar a exploração gradual.
            mastery = perf.mastery if perf else .5
            score, parts = engine.score(mastery, perf.attempts if perf else 0, topic.importance, days_to_exam, review_due)
            preference_priority = preferences.get(topic.subject_id, 0)
            score = min(100, score + preference_priority * 4)
            parts["subjectPreference"] = preference_priority
            ranked.append((score, topic, parts))
        ranked.sort(key=lambda item: (item[0], bool(performances.get(item[1].id))), reverse=True)
        return ranked

    def _task_values(self, topic, performance, score, parts):
        generic_batch = topic.name.lower().startswith("enem oficial ")
        focus = topic.subject.name if generic_batch else topic.name
        activity_type = "review" if parts.get("review") else "practice"
        verb = "Revisar" if activity_type == "review" else "Praticar"
        if performance:
            accuracy = round(100 * performance.correct / performance.attempts) if performance.attempts else 0
            reason = (
                f"{focus} foi priorizada pelo seu desempenho recente: {accuracy}% de acertos "
                f"em {performance.attempts} {'resposta' if performance.attempts == 1 else 'respostas'}, "
                "considerando também a importância curricular e a proximidade da prova."
            )
        else:
            reason = (
                f"{focus} entrou na rotina para ampliar as evidências sobre seu domínio, "
                "considerando a importância curricular e a proximidade da prova."
            )
        if parts.get("subjectPreference"):
            reason += " Você também marcou esta matéria como prioritária no perfil."
        return {
            "title": f"{verb} {focus}",
            "activity_type": activity_type,
            "priority_score": score,
            "reason": reason,
        }


class GetStudyPlanService:
    """Recupera o plano ativo vinculado ao objetivo atual do estudante."""

    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            return None
        return StudyPlan.query.filter_by(
            user_id=user_id,
            goal_id=goal.id,
            status="active",
        ).order_by(StudyPlan.created_at.desc()).first()


class AdaptActivePlanService:
    """Atualiza somente sessões pendentes com as evidências mais recentes do aluno."""

    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        plan = StudyPlan.query.filter_by(user_id=user_id, goal_id=goal.id, status="active").order_by(StudyPlan.created_at.desc()).first() if goal else None
        if not plan:
            return None
        tasks = StudyTask.query.filter(
            StudyTask.plan_id == plan.id,
            StudyTask.status == "pending",
            StudyTask.scheduled_date >= date.today(),
        ).order_by(StudyTask.scheduled_date.asc(), StudyTask.id.asc()).all()
        if not tasks:
            return plan
        builder = GenerateStudyPlanService()
        topics = Topic.query.join(Topic.subject).join(Question, Question.topic_id == Topic.id).filter_by(exam_id=goal.exam_id).filter(Question.status == "approved").distinct().all()
        performances = {p.topic_id: p for p in Performance.query.filter_by(user_id=user_id, exam_id=goal.exam_id)}
        reviews = {r.topic_id: r for r in ReviewSchedule.query.filter_by(user_id=user_id)}
        preferences = {item.subject_id: item.priority for item in SubjectPreference.query.filter_by(user_id=user_id)}
        days_to_exam = max(1, (goal.exam_date - date.today()).days)
        ranked = builder._rank_topics(topics, performances, reviews, preferences, days_to_exam)
        for index, task in enumerate(tasks):
            score, topic, parts = ranked[index % len(ranked)]
            task.topic_id = topic.id
            values = builder._task_values(topic, performances.get(topic.id), score, parts)
            for key, value in values.items():
                setattr(task, key, value)
        db.session.flush()
        return plan


class GenerateDailyRoutineService:
    def execute(self, user_id, day=None):
        selected = datetime.strptime(day, "%Y-%m-%d").date() if day else date.today()
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        plan = StudyPlan.query.filter_by(user_id=user_id, goal_id=goal.id, status="active").order_by(StudyPlan.created_at.desc()).first() if goal else None
        if not plan:
            raise AppError("Gere um plano para ver sua rotina.", 409, "plan_required")
        AdaptActivePlanService().execute(user_id)
        db.session.commit()
        return StudyTask.query.filter_by(plan_id=plan.id, scheduled_date=selected).order_by(StudyTask.priority_score.desc()).all()


class UpdateStudyTaskService:
    def execute(self, user_id, task_id, status):
        task = StudyTask.query.join(StudyPlan).join(UserGoal, StudyPlan.goal_id == UserGoal.id).filter(StudyTask.id == task_id, StudyPlan.user_id == user_id, StudyPlan.status == "active", UserGoal.active.is_(True)).first()
        if not task:
            raise AppError("Tarefa não encontrada.", 404, "task_not_found")
        if status == "completed":
            raise AppError("Conclua a atividade vinculada para finalizar esta sessão.", 409, "activity_required")
        if status not in {"pending", "in_progress"}:
            raise AppError("Status inválido.", 422, "invalid_status")
        now = datetime.now(timezone.utc)
        task.status = status
        if status == "in_progress" and not task.started_at:
            task.started_at = now
        if status == "completed":
            task.completed_at = now
        db.session.commit()
        return task


class ReplanStudiesService:
    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo antes de replanejar.", 409, "goal_required")
        old = StudyPlan.query.filter_by(user_id=user_id, goal_id=goal.id, status="active").order_by(StudyPlan.created_at.desc()).first()
        if not old:
            raise AppError("Não há plano ativo para replanejar.", 409, "plan_required")
        old.status = "archived"
        new = StudyPlan(user_id=user_id, goal_id=goal.id, version=old.version + 1, rationale={"replannedFrom": old.id, "formula": PriorityEngine.WEIGHTS})
        db.session.add(new)
        db.session.flush()
        GenerateStudyPlanService()._build_tasks(new, goal, start=date.today())
        db.session.commit()
        return new

