from sqlalchemy import func

from ..errors import AppError
from ..extensions import db
from ..models.entities import Exam, Question, Subject


class ListExamsService:
    """Lista as provas disponíveis para seleção no objetivo acadêmico."""

    def execute(self):
        return Exam.query.order_by(Exam.support_status.asc(), Exam.name.asc()).all()


class ListExamSubjectsService:
    """Entrega matérias, assuntos e disponibilidade real de questões de uma prova."""

    def execute(self, exam_id):
        if not db.session.get(Exam, exam_id):
            raise AppError("Prova não encontrada.", 404, "exam_not_found")

        counts = dict(
            db.session.query(Question.subject_id, func.count(Question.id))
            .filter(Question.exam_id == exam_id, Question.status == "approved")
            .group_by(Question.subject_id)
            .all()
        )
        subjects = Subject.query.filter_by(exam_id=exam_id).order_by(Subject.name).all()
        result = []
        for subject in subjects:
            topics = [
                {"id": topic.id, "name": topic.name, "importance": topic.importance}
                for topic in subject.topics
                if not topic.name.lower().startswith("enem oficial ")
            ]
            if topics:
                result.append({
                    "id": subject.id,
                    "name": subject.name,
                    "area": subject.area,
                    "approvedQuestionCount": counts.get(subject.id, 0),
                    "topics": topics,
                })
        return result
