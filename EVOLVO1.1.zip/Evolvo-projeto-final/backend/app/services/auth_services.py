from flask_jwt_extended import create_access_token
from ..extensions import db
from ..errors import AppError
from ..models.entities import User, UserConsent


LEGAL_VERSION = "2.1"
REQUIRED_CONSENTS = ("terms", "privacy_notice", "academic_processing", "age_responsibility")


def onboarding_complete(user_id):
    accepted = {
        item.consent_type for item in UserConsent.query.filter_by(user_id=user_id, version=LEGAL_VERSION, accepted=True).all()
    }
    return all(item in accepted for item in REQUIRED_CONSENTS)


def user_payload(user):
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "onboardingComplete": onboarding_complete(user.id),
    }


class RegisterUserService:
    def execute(self, data):
        name = (data.get("name") or "").strip()
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""
        if len(name) < 2 or "@" not in email or len(password) < 8:
            raise AppError("Informe nome, e-mail válido e senha com pelo menos 8 caracteres.", 422, "validation_error")
        if User.query.filter_by(email=email).first():
            raise AppError("Este e-mail já está cadastrado.", 409, "email_in_use")
        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()
        db.session.commit()
        return {"user": user_payload(user), "accessToken": create_access_token(identity=str(user.id), additional_claims={"role": user.role})}


class AuthenticateUserService:
    def execute(self, data):
        user = User.query.filter_by(email=(data.get("email") or "").strip().lower()).first()
        if not user or not user.check_password(data.get("password") or "") or not user.is_active:
            raise AppError("E-mail ou senha incorretos.", 401, "invalid_credentials")
        return {"user": user_payload(user), "accessToken": create_access_token(identity=str(user.id), additional_claims={"role": user.role})}


class GetCurrentUserService:
    """Recupera a conta autenticada sem expor persistência ao Controller."""

    def execute(self, user_id):
        user = db.session.get(User, user_id)
        if not user or not user.is_active:
            raise AppError("Usuário não encontrado.", 404, "user_not_found")
        return user


class RecordConsentService:
    def execute(self, user_id, data):
        consent_type = (data.get("type") or "").strip()
        version = (data.get("version") or LEGAL_VERSION).strip()
        is_required = consent_type in REQUIRED_CONSENTS and version == LEGAL_VERSION
        is_optional = consent_type == "anonymous_academic_improvement" and version == "1.0"
        if not is_required and not is_optional:
            raise AppError("Consentimento ou versão inválidos.", 422, "invalid_consent")
        if is_required and data.get("accepted") is not True:
            raise AppError("A confirmação precisa ser explícita.", 422, "explicit_consent_required")
        consent = UserConsent.query.filter_by(user_id=user_id, consent_type=consent_type, version=version).first()
        if not consent:
            consent = UserConsent(user_id=user_id, consent_type=consent_type, version=version)
            db.session.add(consent)
        consent.accepted = bool(data.get("accepted"))
        db.session.commit()
        return {"id": consent.id, "type": consent.consent_type, "version": consent.version, "accepted": consent.accepted}


class GetConsentStatusService:
    def execute(self, user_id):
        rows = UserConsent.query.filter_by(user_id=user_id, version=LEGAL_VERSION).all()
        decisions = {item.consent_type: item.accepted for item in rows}
        return {
            "version": LEGAL_VERSION,
            "required": list(REQUIRED_CONSENTS),
            "decisions": decisions,
            "complete": onboarding_complete(user_id),
        }

