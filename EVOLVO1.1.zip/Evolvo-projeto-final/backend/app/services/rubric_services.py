from ..errors import AppError
from ..extensions import db
from ..models.entities import Assessment, Question, Subject, SubjectPreference, User, UserGoal
from ..repositories.question_repository import QuestionRepository


class UpdateProfileService:
    def execute(self, user_id, data):
        user = db.session.get(User, user_id)
        name = str(data.get("name", "")).strip()
        email = str(data.get("email", "")).strip().lower()
        if len(name) < 2:
            raise AppError("Informe um nome válido.", 422, "invalid_name")
        if "@" not in email:
            raise AppError("Informe um e-mail válido.", 422, "invalid_email")
        duplicate = User.query.filter(User.email == email, User.id != user_id).first()
        if duplicate:
            raise AppError("Este e-mail já está cadastrado.", 409, "email_exists")
        user.name, user.email = name, email
        db.session.commit()
        return user


class GetSubjectPreferencesService:
    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo primeiro.", 409, "goal_required")
        selected = {item.subject_id: item.priority for item in SubjectPreference.query.filter_by(user_id=user_id).all()}
        return [(subject, selected.get(subject.id)) for subject in Subject.query.filter_by(exam_id=goal.exam_id).order_by(Subject.name).all()]


class SaveSubjectPreferencesService:
    def execute(self, user_id, data):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo primeiro.", 409, "goal_required")
        raw = data.get("subjects")
        if not isinstance(raw, list):
            raise AppError("Selecione as matérias prioritárias.", 422, "invalid_preferences")
        parsed = {}
        try:
            for item in raw:
                parsed[int(item["subjectId"])] = int(item.get("priority", 1))
        except (KeyError, TypeError, ValueError):
            raise AppError("Preferências inválidas.", 422, "invalid_preferences")
        if any(value not in {1, 2, 3} for value in parsed.values()):
            raise AppError("A prioridade deve estar entre 1 e 3.", 422, "invalid_preferences")
        valid_ids = {item.id for item in Subject.query.filter_by(exam_id=goal.exam_id).all()}
        if not set(parsed).issubset(valid_ids):
            raise AppError("Uma matéria não pertence ao objetivo atual.", 422, "invalid_preferences")
        SubjectPreference.query.filter_by(user_id=user_id).delete()
        db.session.add_all([SubjectPreference(user_id=user_id, subject_id=subject_id, priority=priority) for subject_id, priority in parsed.items()])
        db.session.commit()
        return GetSubjectPreferencesService().execute(user_id)


class SearchQuestionsService:
    def execute(self, user_id, args):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo primeiro.", 409, "goal_required")
        subject_id = args.get("subjectId", type=int)
        difficulty = args.get("difficulty")
        if difficulty and difficulty not in {"easy", "medium", "hard"}:
            raise AppError("Dificuldade inválida.", 422, "invalid_difficulty")
        if subject_id and not Subject.query.filter_by(id=subject_id, exam_id=goal.exam_id).first():
            raise AppError("Matéria inválida.", 422, "invalid_subject")
        visual_only = args.get("visual", "").lower() in {"1", "true", "yes"}
        return QuestionRepository().search(goal.exam_id, subject_id, difficulty, min(args.get("limit", 50, type=int), 100), visual_only)


class SimulationHistoryService:
    def execute(self, user_id):
        return Assessment.query.filter_by(user_id=user_id, kind="simulation", status="completed").order_by(Assessment.completed_at.desc()).all()
