import re
import unicodedata


ENEM_TAXONOMY = {
    "Matemática": ("Matemática", ["Aritmética", "Razão e proporção", "Porcentagem", "Matemática financeira", "Estatística", "Probabilidade", "Análise combinatória", "Funções", "Equações e inequações", "Geometria plana", "Geometria espacial", "Geometria analítica", "Trigonometria", "Grandezas e medidas", "Sequências e progressões"]),
    "Língua Portuguesa": ("Linguagens", ["Interpretação de textos", "Gêneros textuais", "Variação linguística", "Coesão e coerência", "Semântica", "Gramática e norma-padrão", "Figuras de linguagem", "Funções da linguagem", "Tecnologias da comunicação", "Literatura brasileira"]),
    "Literatura": ("Linguagens", ["Teoria literária", "Escolas literárias", "Literatura brasileira", "Literatura contemporânea"]),
    "Língua Inglesa": ("Linguagens", ["Interpretação em inglês", "Vocabulário e contexto", "Gêneros textuais em inglês"]),
    "Língua Espanhola": ("Linguagens", ["Interpretação em espanhol", "Vocabulário e contexto", "Gêneros textuais em espanhol"]),
    "Artes": ("Linguagens", ["Artes visuais", "Música", "Teatro", "Dança", "Patrimônio cultural", "Arte contemporânea"]),
    "Educação Física": ("Linguagens", ["Corpo e saúde", "Esportes", "Práticas corporais", "Lazer e sociedade"]),
    "História": ("Ciências Humanas", ["Antiguidade", "Idade Média", "Idade Moderna", "Brasil Colônia", "Brasil Império", "Brasil República", "Era Vargas", "Ditadura militar", "História da África", "História indígena", "Revoluções", "Guerras mundiais", "Guerra Fria", "Industrialização", "Cidadania e movimentos sociais"]),
    "Geografia": ("Ciências Humanas", ["Cartografia", "Geografia física", "Climatologia", "Geomorfologia", "Hidrografia", "Biomas", "Questões ambientais", "População e demografia", "Urbanização", "Espaço agrário", "Industrialização", "Globalização", "Geopolítica", "Economia e trabalho", "Energia e recursos naturais"]),
    "Filosofia": ("Ciências Humanas", ["Filosofia antiga", "Filosofia moderna", "Filosofia contemporânea", "Ética", "Política", "Teoria do conhecimento", "Estética", "Filosofia da ciência"]),
    "Sociologia": ("Ciências Humanas", ["Cultura e identidade", "Cidadania e direitos", "Trabalho e sociedade", "Estratificação social", "Movimentos sociais", "Estado e democracia", "Indústria cultural", "Desigualdade social"]),
    "Biologia": ("Ciências da Natureza", ["Citologia", "Bioquímica", "Genética", "Evolução", "Ecologia", "Fisiologia humana", "Botânica", "Zoologia", "Microbiologia", "Imunologia", "Biotecnologia", "Saúde pública"]),
    "Física": ("Ciências da Natureza", ["Cinemática", "Dinâmica", "Trabalho e energia", "Gravitação", "Hidrostática", "Termologia", "Termodinâmica", "Ondulatória", "Óptica", "Eletrostática", "Eletrodinâmica", "Eletromagnetismo", "Física moderna"]),
    "Química": ("Ciências da Natureza", ["Estrutura atômica", "Tabela periódica", "Ligações químicas", "Funções inorgânicas", "Reações químicas", "Estequiometria", "Soluções", "Termoquímica", "Cinética química", "Equilíbrio químico", "Eletroquímica", "Química orgânica", "Polímeros", "Química ambiental"]),
}


RULES = {
    "Matemática": {
        "Probabilidade": ["probabilidade", "sorteio", "ao acaso", "chance"], "Estatística": ["media", "mediana", "moda", "grafico", "frequencia", "desvio"],
        "Porcentagem": ["porcent", "%", "percentual"], "Matemática financeira": ["juros", "desconto", "prestacao", "financiamento"],
        "Funções": ["funcao", "f(x)", "grafico de", "variacao"], "Geometria espacial": ["volume", "cubo", "cilindro", "cone", "esfera", "prisma"],
        "Geometria plana": ["area", "triangulo", "quadrado", "circulo", "poligono"], "Trigonometria": ["seno", "cosseno", "tangente"],
        "Razão e proporção": ["proporcao", "escala", "regra de tres", "razao"], "Sequências e progressões": ["sequencia", "progressao"],
        "Análise combinatória": ["combinacao", "permutacao", "arranjo"], "Grandezas e medidas": ["litro", "metro", "medida", "unidade"],
    },
    "Língua Portuguesa": {
        "Gêneros textuais": ["genero", "charge", "tirinha", "anuncio", "campanha", "poema", "cronica"], "Variação linguística": ["variacao linguistica", "dialeto", "fala", "oralidade"],
        "Coesão e coerência": ["coesao", "conectivo", "referencia", "pronome"], "Figuras de linguagem": ["metafora", "ironia", "metonimia", "figura de linguagem"],
        "Funções da linguagem": ["funcao da linguagem", "emissor", "receptor"], "Gramática e norma-padrão": ["norma-padrao", "concordancia", "regencia", "pontuacao"],
        "Literatura brasileira": ["romantismo", "modernismo", "realismo", "literatura"], "Tecnologias da comunicação": ["internet", "rede social", "tecnologia da informacao"],
    },
    "Biologia": {
        "Genética": ["dna", "gene", "genet", "hereditar", "cromossomo"], "Evolução": ["evolucao", "selecao natural", "darwin"], "Ecologia": ["ecossistema", "cadeia alimentar", "bioma", "ciclo do", "populacao"],
        "Fisiologia humana": ["sangue", "hormon", "sistema digest", "respiracao", "coracao"], "Citologia": ["celula", "mitose", "meiose", "organela"],
        "Microbiologia": ["bacteria", "virus", "fungo", "micro-organismo", "microrganismo"], "Imunologia": ["vacina", "anticorpo", "imun"], "Biotecnologia": ["transgen", "clonagem", "biotecnologia"],
    },
    "Física": {
        "Cinemática": ["velocidade", "aceleracao", "movimento", "trajetoria"], "Dinâmica": ["forca", "atrito", "newton"], "Trabalho e energia": ["energia", "potencia", "trabalho"],
        "Termologia": ["temperatura", "calor", "dilatacao"], "Termodinâmica": ["maquina termica", "gas ideal", "pressao"], "Ondulatória": ["onda", "frequencia", "som"],
        "Óptica": ["luz", "lente", "espelho", "reflexao"], "Eletrodinâmica": ["circuito", "corrente eletrica", "resistor", "tensao"], "Eletromagnetismo": ["campo magnet", "inducao"],
    },
    "Química": {
        "Estequiometria": ["mol", "massa molar", "estequiometr"], "Soluções": ["solucao", "concentracao", "solubilidade"], "Química orgânica": ["hidrocarboneto", "carbono", "alcool", "ester", "organica"],
        "Eletroquímica": ["pilha", "eletrolise", "oxidacao", "reducao"], "Equilíbrio químico": ["equilibrio", "ph", "acido", "base"], "Termoquímica": ["entalpia", "combustao"],
        "Reações químicas": ["reacao quimica", "equacao quimica", "produto", "reagente"], "Química ambiental": ["poluicao", "tratamento de agua", "efeito estufa"],
    },
    "História": {
        "Brasil Colônia": ["brasil colonia", "colonial", "escrav", "engenho"], "Brasil Império": ["imperio", "dom pedro", "monarquia"], "Brasil República": ["republica", "coronelismo"],
        "Era Vargas": ["vargas", "estado novo"], "Ditadura militar": ["ditadura", "regime militar", "ai-5"], "Guerras mundiais": ["guerra mundial", "nazismo", "fascismo"],
        "Guerra Fria": ["guerra fria", "uniao sovietica", "socialismo"], "História da África": ["africa", "african"], "História indígena": ["indigena", "povos originarios"],
    },
    "Geografia": {
        "Cartografia": ["mapa", "escala", "coordenada", "projecao"], "Climatologia": ["clima", "chuva", "temperatura", "atmosfera"], "Biomas": ["bioma", "amazonia", "cerrado", "caatinga"],
        "Questões ambientais": ["ambient", "desmatamento", "poluicao", "sustent"], "Urbanização": ["urban", "cidade", "metropole"], "Espaço agrário": ["agrari", "agricultura", "campo", "latifundio"],
        "Globalização": ["globalizacao", "multinacional"], "Geopolítica": ["fronteira", "territorio", "geopolit", "conflito"], "População e demografia": ["demograf", "migracao", "populacao"],
    },
    "Filosofia": {"Ética": ["etica", "moral"], "Política": ["filosofia politica", "contrato social"], "Teoria do conhecimento": ["conhecimento", "verdade", "razao"], "Filosofia antiga": ["platao", "aristoteles", "socrates"]},
    "Sociologia": {"Cultura e identidade": ["cultura", "identidade"], "Cidadania e direitos": ["cidadania", "direitos humanos"], "Trabalho e sociedade": ["trabalho", "capitalismo"], "Movimentos sociais": ["movimento social", "feminismo"], "Estado e democracia": ["democracia", "estado", "poder"]},
}


def normalize(value):
    value = unicodedata.normalize("NFKD", value or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", value)


def infer_subject(current_subject, statement):
    text = normalize(statement)
    if current_subject == "Ciências da Natureza":
        scores = {name: sum(keyword in text for values in RULES.get(name, {}).values() for keyword in values) for name in ("Biologia", "Física", "Química")}
        return max(scores, key=scores.get) if max(scores.values()) else "Biologia"
    if current_subject == "Ciências Humanas":
        scores = {name: sum(keyword in text for values in RULES.get(name, {}).values() for keyword in values) for name in ("História", "Geografia", "Filosofia", "Sociologia")}
        return max(scores, key=scores.get) if max(scores.values()) else "Geografia"
    return current_subject if current_subject in ENEM_TAXONOMY else "Língua Portuguesa"


def infer_topic(subject, statement):
    text = normalize(statement)
    best_name = None
    best_score = 0
    for name, keywords in RULES.get(subject, {}).items():
        score = sum(keyword in text for keyword in keywords)
        if score > best_score:
            best_name, best_score = name, score
    if best_name:
        return best_name
    defaults = {
        "Matemática": "Aritmética", "Língua Portuguesa": "Interpretação de textos", "Biologia": "Ecologia",
        "Física": "Dinâmica", "Química": "Reações químicas", "História": "Brasil República", "Geografia": "Geografia física",
        "Filosofia": "Filosofia contemporânea", "Sociologia": "Cultura e identidade",
    }
    return defaults.get(subject, ENEM_TAXONOMY[subject][1][0])
