from datetime import datetime, timezone

from ..errors import AppError
from ..extensions import db
from ..models.entities import Subject, Teacher, TeacherContactRequest, TeacherPartnerApplication, TeacherReview, User
from ..repositories.teacher_repository import TeacherRepository


class SearchTeachersService:
    def execute(self, args):
        subject_id = args.get("subjectId", type=int)
        if subject_id and not db.session.get(Subject, subject_id):
            raise AppError("Matéria não encontrada.", 404, "subject_not_found")
        modality = args.get("modality")
        if modality and modality not in {"online", "presential", "both"}:
            raise AppError("Modalidade inválida.", 422, "invalid_modality")
        sort = args.get("sort", "rating_desc")
        if sort not in {"rating_desc", "price_asc", "name_asc"}:
            raise AppError("Ordenação inválida.", 422, "invalid_sort")
        return TeacherRepository().search(args.get("name"), subject_id, modality, sort)


class GetTeacherProfileService:
    def execute(self, teacher_id):
        teacher = Teacher.query.filter_by(id=teacher_id, active=True).first()
        if not teacher:
            raise AppError("Professor não encontrado.", 404, "teacher_not_found")
        return teacher, TeacherRepository().rating_summary(teacher_id)


class ReviewTeacherService:
    def execute(self, user_id, teacher_id, data):
        teacher = Teacher.query.filter_by(id=teacher_id, active=True).first()
        if not teacher:
            raise AppError("Professor não encontrado.", 404, "teacher_not_found")
        try:
            rating = int(data.get("rating"))
        except (TypeError, ValueError):
            raise AppError("Informe uma nota de 1 a 5.", 422, "invalid_rating")
        if rating not in range(1, 6):
            raise AppError("Informe uma nota de 1 a 5.", 422, "invalid_rating")
        comment = str(data.get("comment") or "").strip()
        if len(comment) > 800:
            raise AppError("O comentário deve ter até 800 caracteres.", 422, "invalid_comment")
        review = TeacherReview.query.filter_by(user_id=user_id, teacher_id=teacher_id).first()
        if review:
            review.rating, review.comment = rating, comment or None
        else:
            review = TeacherReview(user_id=user_id, teacher_id=teacher_id, rating=rating, comment=comment or None)
            db.session.add(review)
        db.session.commit()
        return review, TeacherRepository().rating_summary(teacher_id)


class DeleteTeacherReviewService:
    def execute(self, user_id, teacher_id):
        review = TeacherReview.query.filter_by(user_id=user_id, teacher_id=teacher_id).first()
        if not review:
            raise AppError("Avaliação não encontrada.", 404, "review_not_found")
        db.session.delete(review)
        db.session.commit()
        return TeacherRepository().rating_summary(teacher_id)


class CreateTeacherContactRequestService:
    def execute(self, student_id, teacher_id, data):
        teacher = Teacher.query.filter_by(id=teacher_id, active=True).first()
        if not teacher:
            raise AppError("Professor não encontrado.", 404, "teacher_not_found")
        if teacher.user_id == student_id:
            raise AppError("Você não pode solicitar contato com o próprio perfil.", 422, "own_teacher_profile")
        message = str(data.get("message") or "").strip()
        if len(message) < 10 or len(message) > 1000:
            raise AppError("Escreva uma mensagem de 10 a 1000 caracteres.", 422, "invalid_contact_message")
        try:
            subject_id = int(data.get("subjectId")) if data.get("subjectId") else None
        except (TypeError, ValueError):
            raise AppError("Matéria inválida.", 422, "invalid_subject")
        if subject_id and subject_id not in {subject.id for subject in teacher.subjects}:
            raise AppError("Selecione uma matéria atendida por este professor.", 422, "invalid_subject")
        item = TeacherContactRequest.query.filter_by(
            student_id=student_id, teacher_id=teacher_id, status="new"
        ).first()
        if item:
            item.message, item.subject_id = message, subject_id
        else:
            item = TeacherContactRequest(
                student_id=student_id, teacher_id=teacher_id, subject_id=subject_id,
                message=message, status="new",
            )
            db.session.add(item)
        db.session.commit()
        return item


class ListTeacherContactRequestsService:
    def execute(self, user_id):
        teacher = Teacher.query.filter_by(user_id=user_id, active=True).first()
        if not teacher:
            raise AppError("Perfil profissional não encontrado.", 404, "teacher_profile_not_found")
        return TeacherContactRequest.query.filter_by(teacher_id=teacher.id).order_by(
            TeacherContactRequest.created_at.desc()
        ).all()


class UpdateTeacherContactRequestService:
    def execute(self, user_id, request_id, status):
        if status not in {"contacted", "closed"}:
            raise AppError("Situação inválida.", 422, "invalid_contact_status")
        teacher = Teacher.query.filter_by(user_id=user_id, active=True).first()
        item = db.session.get(TeacherContactRequest, request_id)
        if not teacher or not item or item.teacher_id != teacher.id:
            raise AppError("Solicitação não encontrada.", 404, "contact_request_not_found")
        item.status = status
        db.session.commit()
        return item


class GetTeacherPartnershipService:
    def execute(self, user_id):
        return TeacherPartnerApplication.query.filter_by(user_id=user_id).first()


class ApplyTeacherPartnershipService:
    def execute(self, user_id, data):
        biography = str(data.get("biography") or "").strip()
        contact = str(data.get("contact") or "").strip()
        city = str(data.get("city") or "").strip()
        modality = str(data.get("modality") or "")
        try:
            hourly_price = float(data.get("hourlyPrice"))
            subject_ids = sorted({int(value) for value in (data.get("subjectIds") or [])})
        except (TypeError, ValueError):
            raise AppError("Revise preço e matérias selecionadas.", 422, "invalid_teacher_application")
        if len(biography) < 40 or len(contact) < 5 or hourly_price <= 0:
            raise AppError("Informe apresentação, contato e valor de aula válidos.", 422, "invalid_teacher_application")
        if modality not in {"online", "presential", "both"}:
            raise AppError("Modalidade inválida.", 422, "invalid_modality")
        subjects = Subject.query.filter(Subject.id.in_(subject_ids)).all() if subject_ids else []
        if not subjects or len(subjects) != len(subject_ids):
            raise AppError("Selecione ao menos uma matéria válida.", 422, "invalid_subjects")
        item = TeacherPartnerApplication.query.filter_by(user_id=user_id).first()
        if not item:
            item = TeacherPartnerApplication(user_id=user_id)
            db.session.add(item)
        item.biography = biography
        item.contact = contact
        item.city = city or None
        item.modality = modality
        item.hourly_price = hourly_price
        item.subject_ids = subject_ids
        item.status = "approved"
        item.reviewed_by = None
        item.reviewed_at = datetime.now(timezone.utc)
        user = db.session.get(User, user_id)
        user.role = "teacher"
        profile = Teacher.query.filter_by(user_id=user_id).first() or Teacher.query.filter_by(contact=contact, name=user.name).first()
        if not profile:
            profile = Teacher(name=user.name, contact=contact, is_test_data=False)
            db.session.add(profile)
        profile.biography = biography
        profile.user_id = user_id
        profile.hourly_price = hourly_price
        profile.modality = modality
        profile.city = city or None
        profile.active = True
        profile.subjects = subjects
        db.session.commit()
        return item


class ListTeacherPartnershipsService:
    def execute(self):
        return TeacherPartnerApplication.query.order_by(TeacherPartnerApplication.created_at.asc()).all()


class ReviewTeacherPartnershipService:
    def execute(self, reviewer_id, application_id, status):
        if status not in {"approved", "rejected"}:
            raise AppError("Decisão inválida.", 422, "invalid_partnership_status")
        item = db.session.get(TeacherPartnerApplication, application_id)
        if not item:
            raise AppError("Solicitação não encontrada.", 404, "partnership_not_found")
        item.status = status
        item.reviewed_by = reviewer_id
        item.reviewed_at = datetime.now(timezone.utc)
        if status == "approved":
            user = db.session.get(User, item.user_id)
            user.role = "teacher"
            existing = Teacher.query.filter_by(user_id=item.user_id).first() or Teacher.query.filter_by(contact=item.contact, name=user.name).first()
            if not existing:
                subjects = Subject.query.filter(Subject.id.in_(item.subject_ids)).all()
                db.session.add(Teacher(
                    user_id=item.user_id, name=user.name, biography=item.biography, hourly_price=item.hourly_price,
                    modality=item.modality, city=item.city, contact=item.contact,
                    is_test_data=False, active=True, subjects=subjects,
                ))
            else:
                existing.user_id = item.user_id
        db.session.commit()
        return item
