from datetime import date, datetime
from ..extensions import db
from ..errors import AppError
from ..models.entities import Exam, StudyPlan, UserGoal


class ConfigureGoalService:
    def execute(self, user_id, data):
        exam = db.session.get(Exam, data.get("examId"))
        if not exam:
            raise AppError("Prova inválida.", 404, "exam_not_found")
        if exam.support_status != "full":
            raise AppError("Esta prova ainda possui suporte limitado e não pode ser escolhida como objetivo ativo.", 409, "exam_not_supported")
        try:
            exam_date = datetime.strptime(data.get("examDate"), "%Y-%m-%d").date()
        except (TypeError, ValueError):
            raise AppError("Informe a data da prova.", 422, "invalid_exam_date")
        if exam_date <= date.today():
            raise AppError("A data da prova deve estar no futuro.", 422, "invalid_exam_date")
        minutes = int(data.get("dailyMinutes", 0))
        if minutes < 20 or minutes > 480:
            raise AppError("A disponibilidade diária deve ficar entre 20 e 480 minutos.", 422, "invalid_availability")
        UserGoal.query.filter_by(user_id=user_id, active=True).update({"active": False})
        StudyPlan.query.filter_by(user_id=user_id, status="active").update({"status": "archived"})
        goal = UserGoal(user_id=user_id, exam_id=exam.id, exam_date=exam_date, daily_minutes=minutes, study_days=data.get("studyDays") or [0, 1, 2, 3, 4], preferences=data.get("preferences") or {}, active=True)
        db.session.add(goal)
        db.session.commit()
        return goal


class GetGoalService:
    def execute(self, user_id):
        return UserGoal.query.filter_by(user_id=user_id, active=True).order_by(UserGoal.created_at.desc()).first()

