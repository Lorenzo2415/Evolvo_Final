import hashlib
import json
from flask import current_app
from ..extensions import db
from ..errors import AppError
from ..integrations.ai_provider import AIProviderClient
from ..models.entities import AIInteraction, Exam, Question, QuestionOption, Subject, Topic
from ..repositories.question_repository import AdminQuestionRepository, QuestionRepository


def content_hash(statement):
    return hashlib.sha256(" ".join(statement.lower().split()).encode()).hexdigest()


class CreateQuestionService:
    def execute(self, data, commit=True):
        statement = (data.get("statement") or "").strip()
        options = data.get("options") or []
        if len(statement) < 20 or len(options) < 2 or sum(bool(item.get("isCorrect")) for item in options) != 1:
            raise AppError("Questão inválida: enunciado, alternativas e um único gabarito são obrigatórios.", 422, "invalid_question")
        digest = content_hash(statement)
        if QuestionRepository().duplicate_candidates(digest):
            raise AppError("Questão duplicada detectada.", 409, "duplicate_question")
        topic = db.session.get(Topic, data.get("topicId"))
        subject = db.session.get(Subject, data.get("subjectId"))
        if not topic or not subject or topic.subject_id != subject.id or subject.exam_id != data.get("examId"):
            raise AppError("Exame, disciplina e assunto não formam uma classificação válida.", 422, "invalid_classification")
        item = Question(
            exam_id=data["examId"], subject_id=subject.id, topic_id=topic.id,
            statement=statement, difficulty=data.get("difficulty", "medium"),
            format=data.get("format", "multiple_choice"),
            explanation=(data.get("explanation") or "").strip(), status=data.get("status", "draft"),
            author_type=data.get("authorType", "authorial"), author_name=data.get("authorName", "Equipe Evolvo"),
            source_label=data.get("sourceLabel"), source_url=data.get("sourceUrl"),
            license_note=data.get("licenseNote"), original_identifier=data.get("originalIdentifier"), content_hash=digest,
        )
        if len(item.explanation) < 10:
            raise AppError("Inclua uma explicação verificável.", 422, "explanation_required")
        db.session.add(item)
        db.session.flush()
        for index, option in enumerate(options, 1):
            db.session.add(QuestionOption(question_id=item.id, position=index, text=(option.get("text") or "").strip(), is_correct=bool(option.get("isCorrect"))))
        if commit:
            db.session.commit()
        else:
            db.session.flush()
        return item


class ListAdminQuestionsService:
    """Aplica paginação e filtros administrativos fora da camada HTTP."""

    def execute(self, exam_id=None, status=None, page=1):
        return AdminQuestionRepository().list_filtered(exam_id, status, page)


class UpdateQuestionService:
    def execute(self, question_id, data):
        item = db.session.get(Question, question_id)
        if not item:
            raise AppError("Questão não encontrada.", 404, "question_not_found")
        for field, attr in {"statement":"statement", "difficulty":"difficulty", "format":"format", "explanation":"explanation", "sourceLabel":"source_label", "licenseNote":"license_note"}.items():
            if field in data:
                setattr(item, attr, data[field])
        if "statement" in data:
            digest = content_hash(item.statement)
            duplicate = Question.query.filter(Question.content_hash == digest, Question.id != item.id).first()
            if duplicate:
                raise AppError("Questão duplicada detectada.", 409, "duplicate_question")
            item.content_hash = digest
        item.status = "draft"
        db.session.commit()
        return item


class ReviewQuestionService:
    def execute(self, question_id, status):
        if status not in {"approved", "rejected", "draft"}:
            raise AppError("Status de revisão inválido.", 422, "invalid_status")
        item = db.session.get(Question, question_id)
        if not item:
            raise AppError("Questão não encontrada.", 404, "question_not_found")
        item.status = status
        db.session.commit()
        return item


class ImportQuestionsService:
    def execute(self, items):
        if not isinstance(items, list) or not items or len(items) > 100:
            raise AppError("Envie entre 1 e 100 questões por importação.", 422, "invalid_import")
        created = []
        try:
            for data in items:
                data = dict(data)
                data["status"] = "draft" if data.get("authorType") == "ai" else data.get("status", "draft")
                created.append(CreateQuestionService().execute(data, commit=False))
            db.session.commit()
            return created
        except Exception:
            db.session.rollback()
            raise


class CheckDuplicateQuestionService:
    def execute(self, statement):
        digest = content_hash(statement or "")
        matches = QuestionRepository().duplicate_candidates(digest)
        return {"duplicate": bool(matches), "matches": [{"id": item.id, "statement": item.statement, "status": item.status} for item in matches]}


class GenerateQuestionDraftService:
    def execute(self, user_id, data):
        required = ["examId", "subjectId", "topicId", "subject", "topic", "difficulty"]
        if any(not data.get(key) for key in required):
            raise AppError("Exame, disciplina, assunto e dificuldade são obrigatórios.", 422, "generation_context_required")
        exam = db.session.get(Exam, data["examId"])
        if not exam or exam.support_status != "full":
            raise AppError("A geração exige uma prova com perfil e suporte completos.", 409, "exam_not_supported")
        characteristics = ", ".join(exam.profile.characteristics) if exam.profile else "seguir o perfil cadastrado da prova"
        prompt = (
            f"Gere uma questão autoral compatível com {exam.name}, organizado por {exam.board or exam.institution}. "
            "Responda somente JSON com as chaves statement, explanation e options; "
            "options deve conter objetos text e isCorrect, com exatamente uma correta. "
            f"Disciplina: {data['subject']}. Assunto: {data['topic']}. Dificuldade: {data['difficulty']}. "
            f"Características do perfil: {characteristics}. Use linguagem clara e não alegue que a questão é oficial."
        )
        interaction = AIInteraction(user_id=user_id, purpose="question_generation", prompt_excerpt=prompt[:500], provider="configurable-http", model=current_app.config["AI_MODEL"], status="pending")
        db.session.add(interaction)
        db.session.flush()
        try:
            raw = AIProviderClient().respond(prompt)
            parsed = json.loads(raw.removeprefix("```json").removesuffix("```").strip())
            parsed.update({
                "examId": data["examId"], "subjectId": data["subjectId"], "topicId": data["topicId"],
                "difficulty": data["difficulty"], "format": data.get("format", "multiple_choice"),
                "status": "draft", "authorType": "ai", "authorName": current_app.config["AI_MODEL"],
                "sourceLabel": "Gerada por IA — revisão obrigatória", "licenseNote": "Rascunho não publicado",
            })
            item = CreateQuestionService().execute(parsed, commit=False)
            interaction.response_excerpt = raw[:2000]
            interaction.status = "completed"
            db.session.commit()
            return item
        except (json.JSONDecodeError, KeyError) as exc:
            interaction.status = "failed"
            db.session.commit()
            raise AppError("O provedor devolveu uma questão fora do formato esperado.", 502, "invalid_ai_question") from exc

