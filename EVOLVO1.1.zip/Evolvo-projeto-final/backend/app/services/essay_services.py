import json
import re
from datetime import datetime, timezone

from flask import current_app

from ..errors import AppError
from ..extensions import db
from ..integrations.ai_provider import AIProviderClient
from ..models.entities import AIInteraction, EssayCorrection, EssayPrompt, EssaySubmission, UserGoal


COMPETENCIES = {
    "C1": "Domínio da modalidade escrita formal da língua portuguesa",
    "C2": "Compreensão do tema e desenvolvimento do texto dissertativo-argumentativo",
    "C3": "Seleção e organização de argumentos em defesa de um ponto de vista",
    "C4": "Mecanismos linguísticos de coesão e articulação",
    "C5": "Proposta de intervenção detalhada e respeitosa aos direitos humanos",
}
VALID_SCORES = {0, 40, 80, 120, 160, 200}


def pre_analysis(text):
    clean = (text or "").strip()
    words = re.findall(r"\b[\wÀ-ÿ'-]+\b", clean)
    character_count = len(clean)
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n|\n", clean) if part.strip()]
    lowered = clean.lower()
    connectors = sorted({item for item in (
        "além disso", "portanto", "porém", "contudo", "entretanto", "desse modo",
        "nesse sentido", "assim", "logo", "por conseguinte", "em primeiro lugar",
    ) if item in lowered})
    agents = sorted({item for item in ("governo", "estado", "escola", "sociedade", "mídia", "empresa", "família") if item in lowered})
    actions = sorted({item for item in ("deve", "devem", "criar", "promover", "ampliar", "garantir", "implementar", "fiscalizar") if item in lowered})
    purposes = any(item in lowered for item in ("para que", "a fim de", "com o objetivo de", "visando"))
    checks = [
        {"label": "Extensão suficiente para desenvolver a tese", "ok": character_count >= 1000},
        {"label": "Organização em introdução, desenvolvimento e conclusão", "ok": len(paragraphs) >= 4},
        {"label": "Conectivos variados entre as ideias", "ok": len(connectors) >= 3},
        {"label": "Agente e ação na proposta de intervenção", "ok": bool(agents and actions)},
        {"label": "Finalidade explícita da intervenção", "ok": purposes},
    ]
    alerts = []
    if character_count < 500:
        alerts.append("O texto ainda está curto para uma dissertação-argumentativa completa.")
    if len(paragraphs) < 3:
        alerts.append("Separe a tese, os argumentos e a proposta de intervenção em parágrafos claros.")
    if not connectors:
        alerts.append("Use conectivos para tornar visível a relação entre os argumentos.")
    if not agents or not actions:
        alerts.append("A proposta de intervenção precisa indicar quem fará o quê.")
    return {
        "wordCount": len(words),
        "characterCount": character_count,
        "paragraphCount": len(paragraphs),
        "connectors": connectors,
        "interventionAgents": agents,
        "checks": checks,
        "alerts": alerts,
        "disclaimer": "Pré-análise estrutural automática. Não é correção oficial, não atribui nota e não substitui avaliação pelas cinco competências do ENEM.",
    }


class ListEssayPromptsService:
    def execute(self, user_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        if not goal:
            raise AppError("Configure seu objetivo.", 409, "goal_required")
        return EssayPrompt.query.filter_by(exam_id=goal.exam_id, status="approved").order_by(EssayPrompt.created_at.desc()).all()


class StartEssayService:
    def execute(self, user_id, prompt_id):
        goal = UserGoal.query.filter_by(user_id=user_id, active=True).first()
        prompt = EssayPrompt.query.filter_by(id=prompt_id, status="approved").first()
        if not goal or not prompt or prompt.exam_id != goal.exam_id:
            raise AppError("Proposta de redação não encontrada para sua prova.", 404, "essay_prompt_not_found")
        item = EssaySubmission(user_id=user_id, prompt_id=prompt.id, draft_text="", analysis=pre_analysis(""))
        db.session.add(item)
        db.session.commit()
        return item


class SaveEssayDraftService:
    def execute(self, user_id, submission_id, text):
        item = EssaySubmission.query.filter_by(id=submission_id, user_id=user_id).first()
        if not item:
            raise AppError("Redação não encontrada.", 404, "essay_not_found")
        if item.status != "draft":
            raise AppError("Uma redação entregue não pode mais ser alterada.", 409, "essay_submitted")
        if not isinstance(text, str) or len(text) > 30000:
            raise AppError("Texto de redação inválido.", 422, "invalid_essay")
        item.draft_text = text
        item.analysis = pre_analysis(text)
        item.word_count = item.analysis["wordCount"]
        db.session.commit()
        return item


class SubmitEssayService(SaveEssayDraftService):
    def execute(self, user_id, submission_id, text):
        item = super().execute(user_id, submission_id, text)
        if item.analysis.get("characterCount", len(item.draft_text.strip())) < 500:
            raise AppError("Desenvolva pelo menos 500 caracteres antes de entregar.", 422, "essay_too_short")
        item.status = "submitted"
        item.submitted_at = datetime.now(timezone.utc)
        db.session.commit()
        return item


class ListEssaySubmissionsService:
    def execute(self, user_id):
        return EssaySubmission.query.filter_by(user_id=user_id).order_by(EssaySubmission.updated_at.desc()).all()


def _submitted_essay(user_id, submission_id):
    item = EssaySubmission.query.filter_by(id=submission_id, user_id=user_id).first()
    if not item:
        raise AppError("Redação não encontrada.", 404, "essay_not_found")
    if item.status != "submitted":
        raise AppError("Entregue a redação antes de solicitar uma correção.", 409, "essay_not_submitted")
    return item


def _extract_json(raw):
    content = (raw or "").strip()
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content, flags=re.IGNORECASE)
    try:
        return json.loads(content)
    except (TypeError, json.JSONDecodeError) as exc:
        raise AppError("A IA respondeu em um formato inesperado. Tente novamente.", 502, "invalid_ai_correction") from exc


def _validate_feedback(data, *, human=False):
    rows = data.get("competencies") if isinstance(data, dict) else None
    if not isinstance(rows, list) or len(rows) != 5:
        raise AppError("Informe a avaliação das cinco competências.", 422, "invalid_competencies")
    normalized = []
    by_code = {str(row.get("code", "")).upper(): row for row in rows if isinstance(row, dict)}
    for code, label in COMPETENCIES.items():
        row = by_code.get(code)
        if not row:
            raise AppError(f"A avaliação de {code} está ausente.", 422, "invalid_competencies")
        try:
            score = int(row.get("score"))
        except (TypeError, ValueError) as exc:
            raise AppError(f"A nota de {code} é inválida.", 422, "invalid_score") from exc
        if score not in VALID_SCORES:
            raise AppError("Cada competência deve receber 0, 40, 80, 120, 160 ou 200 pontos.", 422, "invalid_score")
        feedback = str(row.get("feedback") or "").strip()
        if len(feedback) < (8 if human else 1):
            raise AppError(f"Explique a avaliação de {code}.", 422, "feedback_required")
        normalized.append({"code": code, "label": label, "score": score, "feedback": feedback[:2000]})
    return {
        "competencies": normalized,
        "totalScore": sum(row["score"] for row in normalized),
        "summary": str(data.get("summary") or "").strip()[:4000],
        "strengths": [str(item)[:500] for item in (data.get("strengths") or [])][:5],
        "priorities": [str(item)[:500] for item in (data.get("priorities") or [])][:5],
        "disclaimer": (
            "Correção humana realizada por integrante autorizado da equipe de correção. Não corresponde à nota oficial do Inep."
            if human else
            "Estimativa gerada por inteligência artificial para apoiar a revisão. Pode conter erros e não corresponde à nota oficial do Inep nem substitui a leitura de um professor."
        ),
    }


class RequestAIEssayCorrectionService:
    def execute(self, user_id, submission_id):
        item = _submitted_essay(user_id, submission_id)
        correction = EssayCorrection.query.filter_by(submission_id=item.id, kind="ai").first()
        if correction and correction.status == "completed":
            return correction
        if not correction:
            correction = EssayCorrection(submission_id=item.id, kind="ai", status="processing")
            db.session.add(correction)
        else:
            correction.status = "processing"
        interaction = AIInteraction(
            user_id=user_id,
            purpose="essay_correction",
            prompt_excerpt=item.draft_text[:500],
            provider="configurable-http",
            model=current_app.config["AI_MODEL"],
            status="pending",
        )
        db.session.add(interaction)
        db.session.flush()
        rubric = "\n".join(f"{code}: {label}" for code, label in COMPETENCIES.items())
        prompt = f"""Você é um assistente pedagógico especializado na redação do ENEM. Analise o texto segundo as cinco competências oficiais, sem inventar citações e sem afirmar que a nota é oficial.

Tema: {item.prompt.theme}
Critérios:
{rubric}

Redação do estudante:
{item.draft_text}

Responda SOMENTE com JSON válido neste formato:
{{"competencies":[{{"code":"C1","score":0,"feedback":"..."}},{{"code":"C2","score":0,"feedback":"..."}},{{"code":"C3","score":0,"feedback":"..."}},{{"code":"C4","score":0,"feedback":"..."}},{{"code":"C5","score":0,"feedback":"..."}}],"summary":"...","strengths":["..."],"priorities":["..."]}}
As notas permitidas em cada competência são 0, 40, 80, 120, 160 ou 200. Seja específico, respeitoso e útil para a reescrita."""
        try:
            raw = AIProviderClient().respond(prompt, max_input_chars=16000, max_output_tokens=1800)
            correction.feedback = _validate_feedback(_extract_json(raw))
            correction.status = "completed"
            correction.completed_at = datetime.now(timezone.utc)
            interaction.response_excerpt = raw[:2000]
            interaction.status = "completed"
            db.session.commit()
            return correction
        except AppError:
            correction.status = "failed"
            interaction.status = "failed"
            db.session.commit()
            raise


class RequestHumanEssayCorrectionService:
    def execute(self, user_id, submission_id):
        item = _submitted_essay(user_id, submission_id)
        correction = EssayCorrection.query.filter_by(submission_id=item.id, kind="human").first()
        if correction:
            return correction
        correction = EssayCorrection(submission_id=item.id, kind="human", status="queued")
        db.session.add(correction)
        db.session.commit()
        return correction


class ListHumanEssayQueueService:
    def execute(self):
        return EssayCorrection.query.filter_by(kind="human").order_by(
            EssayCorrection.status.asc(), EssayCorrection.requested_at.asc()
        ).all()


class CompleteHumanEssayCorrectionService:
    def execute(self, reviewer_id, correction_id, data):
        correction = EssayCorrection.query.filter_by(id=correction_id, kind="human").first()
        if not correction:
            raise AppError("Pedido de correção não encontrado.", 404, "essay_correction_not_found")
        correction.feedback = _validate_feedback(data, human=True)
        correction.status = "completed"
        correction.reviewer_id = reviewer_id
        correction.completed_at = datetime.now(timezone.utc)
        db.session.commit()
        return correction
