from datetime import datetime, timedelta, timezone
from ..extensions import db
from ..models.entities import Performance, ReviewSchedule, Topic


DIFFICULTY_WEIGHT = {"easy": 0.8, "medium": 1.0, "hard": 1.25}


class PriorityEngine:
    """Fórmula transparente: 45% lacuna + 25% importância + 15% baixa evidência + 10% urgência + 5% revisão."""
    WEIGHTS = {"gap": .45, "importance": .25, "evidence": .15, "urgency": .10, "review": .05}

    def score(self, mastery, attempts, importance, days_to_exam, review_due=False):
        gap = 1 - max(0, min(1, mastery))
        evidence = max(0, 1 - min(attempts, 5) / 5)
        urgency = 1 if days_to_exam <= 30 else .7 if days_to_exam <= 90 else .4
        review = 1 if review_due else 0
        normalized_importance = max(0, min(1, importance / 2))
        parts = {"gap": gap, "importance": normalized_importance, "evidence": evidence, "urgency": urgency, "review": review}
        total = sum(parts[key] * self.WEIGHTS[key] for key in self.WEIGHTS)
        return round(total * 100, 2), parts


class UpdatePerformanceService:
    def execute(self, user_id, assessment):
        now = datetime.now(timezone.utc)
        for link in assessment.questions:
            if link.is_correct is None:
                continue
            question = link.question
            perf = Performance.query.filter_by(user_id=user_id, exam_id=assessment.exam_id, topic_id=question.topic_id).first()
            if not perf:
                perf = Performance(user_id=user_id, exam_id=assessment.exam_id, topic_id=question.topic_id, attempts=0, correct=0, weighted_score=0, mastery=0)
                db.session.add(perf)
            weight = DIFFICULTY_WEIGHT.get(question.difficulty, 1)
            previous_weighted = perf.weighted_score * perf.attempts
            perf.attempts += 1
            perf.correct += int(link.is_correct)
            perf.weighted_score = (previous_weighted + (weight if link.is_correct else 0)) / perf.attempts
            accuracy = perf.correct / perf.attempts
            confidence = min(1, perf.attempts / 5)
            perf.mastery = round(accuracy * confidence, 4)
            perf.last_result = link.is_correct
            perf.last_assessed_at = now
            self._schedule_review(user_id, question.topic_id, perf.mastery, now)
        db.session.flush()

    def _schedule_review(self, user_id, topic_id, mastery, now):
        review = ReviewSchedule.query.filter_by(user_id=user_id, topic_id=topic_id).first()
        if not review:
            review = ReviewSchedule(user_id=user_id, topic_id=topic_id, next_review_at=now, interval_days=1, last_score=0)
            db.session.add(review)
        if mastery >= .8:
            review.interval_days = min(30, max(3, review.interval_days * 2))
        elif mastery >= .55:
            review.interval_days = max(2, review.interval_days)
        else:
            review.interval_days = 1
        review.last_reviewed_at = now
        review.next_review_at = now + timedelta(days=review.interval_days)
        review.last_score = mastery

