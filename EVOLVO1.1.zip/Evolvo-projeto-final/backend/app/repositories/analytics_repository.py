from sqlalchemy import text
from ..extensions import db


class AnalyticsRepository:
    """SQL real e parametrizado para relatórios e indicadores acadêmicos."""

    def accuracy_by_subject(self, user_id, exam_id):
        sql = text("""
            SELECT s.id, s.name, COUNT(aq.id) AS answered,
                   COALESCE(SUM(CASE WHEN aq.is_correct = 1 THEN 1 ELSE 0 END), 0) AS correct,
                   ROUND(100.0 * COALESCE(SUM(CASE WHEN aq.is_correct = 1 THEN 1 ELSE 0 END), 0)
                         / NULLIF(COUNT(aq.id), 0), 1) AS accuracy
            FROM subjects s
            LEFT JOIN questions q ON q.subject_id = s.id
            LEFT JOIN assessment_questions aq ON aq.question_id = q.id AND aq.is_correct IS NOT NULL
              AND EXISTS (
                SELECT 1 FROM assessments a2
                WHERE a2.id = aq.assessment_id AND a2.user_id = :user_id
                  AND a2.exam_id = :exam_id AND a2.status = 'completed'
              )
            WHERE s.exam_id = :exam_id
            GROUP BY s.id, s.name
            ORDER BY accuracy ASC, s.name ASC
        """)
        return [dict(row._mapping) for row in db.session.execute(sql, {"user_id": user_id, "exam_id": exam_id})]

    def error_topics(self, user_id, exam_id, limit=8):
        sql = text("""
            SELECT t.id, t.name, s.name AS subject, COUNT(aq.id) AS answered,
                   SUM(CASE WHEN aq.is_correct = 0 THEN 1 ELSE 0 END) AS errors,
                   ROUND(100.0 * SUM(CASE WHEN aq.is_correct = 0 THEN 1 ELSE 0 END)
                         / NULLIF(COUNT(aq.id), 0), 1) AS error_rate,
                   t.importance
            FROM topics t
            JOIN subjects s ON s.id = t.subject_id
            JOIN questions q ON q.topic_id = t.id
            JOIN assessment_questions aq ON aq.question_id = q.id AND aq.is_correct IS NOT NULL
            JOIN assessments a ON a.id = aq.assessment_id
            WHERE a.user_id = :user_id AND a.exam_id = :exam_id AND a.status = 'completed'
            GROUP BY t.id, t.name, s.name, t.importance
            ORDER BY error_rate DESC, answered DESC
            LIMIT :limit
        """)
        return [dict(row._mapping) for row in db.session.execute(sql, {"user_id": user_id, "exam_id": exam_id, "limit": limit})]

    def evolution_by_day(self, user_id, exam_id, limit=30):
        sql = text("""
            SELECT DATE(a.completed_at) AS day, a.kind,
                   ROUND(AVG(a.score), 1) AS average_score,
                   SUM(a.correct_answers) AS correct,
                   SUM(a.total_questions) AS total
            FROM assessments a
            WHERE a.user_id = :user_id AND a.exam_id = :exam_id AND a.status = 'completed'
            GROUP BY DATE(a.completed_at), a.kind
            ORDER BY day DESC
            LIMIT :limit
        """)
        rows = [dict(row._mapping) for row in db.session.execute(sql, {"user_id": user_id, "exam_id": exam_id, "limit": limit})]
        return list(reversed(rows))

    def recent_history(self, user_id, exam_id, limit=6):
        sql = text("""
            SELECT id, kind, title, score, completed_at
            FROM assessments
            WHERE user_id = :user_id AND exam_id = :exam_id AND status = 'completed'
            ORDER BY completed_at DESC LIMIT :limit
        """)
        return [dict(row._mapping) for row in db.session.execute(sql, {"user_id": user_id, "exam_id": exam_id, "limit": limit})]

