from sqlalchemy import text

from ..extensions import db
from ..models.entities import Teacher


class TeacherRepository:
    """Consulta combinada do catálogo; parâmetros do usuário nunca são interpolados no SQL."""

    def search(self, name=None, subject_id=None, modality=None, sort="rating_desc"):
        filters = ["t.active = 1"]
        params = {}
        if name:
            filters.append("LOWER(t.name) LIKE :name")
            params["name"] = f"%{name.strip().lower()}%"
        if subject_id:
            filters.append("EXISTS (SELECT 1 FROM teacher_subjects ts WHERE ts.teacher_id = t.id AND ts.subject_id = :subject_id)")
            params["subject_id"] = subject_id
        if modality in {"online", "presential"}:
            filters.append("t.modality IN (:modality, 'both')")
            params["modality"] = modality
        elif modality == "both":
            filters.append("t.modality = 'both'")
        order = {
            "price_asc": "t.hourly_price ASC, t.name ASC",
            "rating_desc": "average_rating DESC, review_count DESC, t.name ASC",
            "name_asc": "t.name ASC",
        }.get(sort, "average_rating DESC, review_count DESC, t.name ASC")
        sql = text(f"""
            SELECT t.id,
                   COALESCE(AVG(r.rating), 0) AS average_rating,
                   COUNT(r.id) AS review_count
              FROM teachers t
              LEFT JOIN teacher_reviews r ON r.teacher_id = t.id
             WHERE {' AND '.join(filters)}
             GROUP BY t.id
             ORDER BY {order}
        """)
        rows = list(db.session.execute(sql, params))
        ids = [row.id for row in rows]
        teachers = {item.id: item for item in Teacher.query.filter(Teacher.id.in_(ids)).all()} if ids else {}
        return [(teachers[row.id], float(row.average_rating or 0), int(row.review_count)) for row in rows]

    def rating_summary(self, teacher_id):
        row = db.session.execute(text("""
            SELECT COALESCE(AVG(rating), 0) AS average_rating, COUNT(id) AS review_count
              FROM teacher_reviews WHERE teacher_id = :teacher_id
        """), {"teacher_id": teacher_id}).one()
        return float(row.average_rating or 0), int(row.review_count)
