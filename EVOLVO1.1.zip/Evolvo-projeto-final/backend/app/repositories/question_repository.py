from sqlalchemy import text
from ..extensions import db
from ..models.entities import Question


class QuestionRepository:
    """Consultas especializadas de seleção e detecção de duplicidade."""

    def select_for_user(self, user_id, exam_id, limit, kind="exercise", topic_ids=None, subject_ids=None, difficulty=None):
        topic_clause = ""
        subject_clause = ""
        params = {"user_id": user_id, "exam_id": exam_id, "limit": limit}
        difficulty_clause = ""
        if difficulty:
            difficulty_clause = "AND q.difficulty = :difficulty"
            params["difficulty"] = difficulty
        if topic_ids:
            placeholders = []
            for index, topic_id in enumerate(topic_ids):
                key = f"topic_{index}"
                params[key] = topic_id
                placeholders.append(f":{key}")
            topic_clause = f"AND q.topic_id IN ({','.join(placeholders)})"
        if subject_ids:
            placeholders = []
            for index, subject_id in enumerate(subject_ids):
                key = f"subject_{index}"
                params[key] = subject_id
                placeholders.append(f":{key}")
            subject_clause = f"AND q.subject_id IN ({','.join(placeholders)})"
        sql = text(f"""
            SELECT q.id, q.subject_id, q.difficulty, COUNT(a.id) AS previous_uses
            FROM questions q
            LEFT JOIN assessment_questions aq ON aq.question_id = q.id
            LEFT JOIN assessments a ON a.id = aq.assessment_id AND a.user_id = :user_id
            WHERE q.exam_id = :exam_id AND q.status = 'approved' {topic_clause} {subject_clause} {difficulty_clause}
            GROUP BY q.id, q.subject_id, q.difficulty, q.created_at
            ORDER BY previous_uses ASC,
              CASE WHEN COALESCE(CAST(q.media AS TEXT), '') LIKE '%http%' THEN 0 ELSE 1 END,
              CASE q.difficulty WHEN 'easy' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
              q.created_at ASC
        """)
        rows = list(db.session.execute(sql, params))
        if kind in {"diagnostic", "simulation"}:
            by_subject = {}
            for row in rows:
                by_subject.setdefault(row[1], []).append(row[0])
            ids = []
            subjects = sorted(by_subject)
            while len(ids) < limit and any(by_subject.values()):
                for subject_id in subjects:
                    if by_subject[subject_id] and len(ids) < limit:
                        ids.append(by_subject[subject_id].pop(0))
        else:
            ids = [row[0] for row in rows[:limit]]
        items = Question.query.filter(Question.id.in_(ids)).all() if ids else []
        return sorted(items, key=lambda item: ids.index(item.id))

    def search(self, exam_id, subject_id=None, difficulty=None, limit=20, visual_only=False):
        clauses = ["q.exam_id = :exam_id", "q.status = 'approved'"]
        params = {"exam_id": exam_id, "limit": max(1, limit)}
        if subject_id:
            clauses.append("q.subject_id = :subject_id")
            params["subject_id"] = subject_id
        if difficulty:
            clauses.append("q.difficulty = :difficulty")
            params["difficulty"] = difficulty
        if visual_only:
            clauses.append("COALESCE(CAST(q.media AS TEXT), '') LIKE '%http%'")
        rows = db.session.execute(text(f"""
            SELECT q.id FROM questions q
             WHERE {' AND '.join(clauses)}
             ORDER BY q.created_at DESC, q.id DESC
             LIMIT :limit
        """), params)
        ids = [row.id for row in rows]
        items = Question.query.filter(Question.id.in_(ids)).all() if ids else []
        return sorted(items, key=lambda item: ids.index(item.id))

    def duplicate_candidates(self, content_hash):
        return Question.query.filter_by(content_hash=content_hash).all()


class AdminQuestionRepository:
    def list_filtered(self, exam_id=None, status=None, page=1, per_page=20):
        query = Question.query
        if exam_id:
            query = query.filter_by(exam_id=exam_id)
        if status:
            query = query.filter_by(status=status)
        return query.order_by(Question.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)

