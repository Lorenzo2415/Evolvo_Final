from datetime import date, datetime


def iso(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


def exam_dict(exam):
    return {
        "id": exam.id, "slug": exam.slug, "name": exam.name, "type": exam.exam_type,
        "institution": exam.institution, "board": exam.board, "supportStatus": exam.support_status,
        "profile": ({
            "questionCount": exam.profile.question_count,
            "alternativeCount": exam.profile.alternative_count,
            "durationMinutes": exam.profile.duration_minutes,
            "structure": exam.profile.structure,
            "characteristics": exam.profile.characteristics,
        } if exam.profile else None),
    }


def question_dict(question, include_answer=False):
    payload = {
        "id": question.id,
        "statement": question.statement,
        "difficulty": question.difficulty,
        "format": question.format,
        "subject": question.subject.name,
        "topic": question.topic.name,
        "media": question.media or {"statement": [], "options": {}},
        "options": [{"id": option.id, "position": option.position, "text": option.text} for option in question.options],
        "source": {"type": question.author_type, "label": question.source_label or question.author_name},
    }
    if include_answer:
        correct = next((option for option in question.options if option.is_correct), None)
        payload.update({"correctOptionId": correct.id if correct else None, "explanation": question.explanation})
    return payload


def assessment_dict(assessment, include_review=False):
    return {
        "id": assessment.id,
        "kind": assessment.kind,
        "title": assessment.title,
        "status": assessment.status,
        "personalized": assessment.personalized,
        "exam": {"id": assessment.exam_id},
        "score": assessment.score,
        "correctAnswers": assessment.correct_answers,
        "totalQuestions": assessment.total_questions,
        "configuration": assessment.configuration,
        "startedAt": iso(assessment.started_at),
        "completedAt": iso(assessment.completed_at),
        "questions": [dict(question_dict(link.question, include_review), selectedOptionId=link.selected_option_id, isCorrect=link.is_correct) for link in assessment.questions],
    }

