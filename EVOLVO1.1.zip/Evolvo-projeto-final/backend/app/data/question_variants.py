from fractions import Fraction


CONTEXTS = [
    "Em uma situação de estudo, ",
    "Em um item contextualizado, ",
    "Durante a análise de um caso, ",
    "Em uma atividade interdisciplinar, ",
]


def _contextual_variants(area, topic, entries):
    questions = []
    for statement, options, correct, explanation in entries:
        for variant, prefix in enumerate(CONTEXTS):
            shift = variant % len(options)
            rotated = options[shift:] + options[:shift]
            questions.append((
                area,
                topic,
                "hard" if variant == 3 else "medium" if variant in {1, 2} else "easy",
                prefix + statement[0].lower() + statement[1:],
                rotated,
                (correct - shift) % len(options),
                explanation,
            ))
    return questions


PORTUGUESE = [
    ("o conectivo 'portanto' introduz uma ideia de", ["causa", "conclusão", "condição", "oposição", "tempo"], 1, "'Portanto' é um conectivo conclusivo."),
    ("em 'Ana encontrou Beatriz quando ela saía da escola', o pronome 'ela' cria", ["uma certeza matemática", "uma ambiguidade de referência", "uma rima", "uma definição", "uma enumeração"], 1, "O pronome pode retomar Ana ou Beatriz, gerando ambiguidade."),
    ("na frase 'a notícia caiu como uma bomba', a linguagem é predominantemente", ["denotativa", "conotativa", "técnica", "jurídica", "literal"], 1, "A expressão é figurada e produz sentido conotativo."),
    ("um texto que relata objetivamente um acontecimento recente pertence, em geral, ao gênero", ["receita", "notícia", "poema", "manual", "conto fantástico"], 1, "A notícia informa fatos recentes de maneira predominantemente objetiva."),
    ("o uso de verbos no imperativo em uma campanha publicitária busca", ["narrar o passado", "orientar ou persuadir o leitor", "definir um conceito", "marcar dúvida", "descrever uma paisagem"], 1, "O imperativo é recorrente em textos que orientam ou persuadem."),
    ("as formas 'nós vamos' e 'a gente vai' exemplificam", ["mudança de idioma", "variação linguística", "erro sem contexto", "linguagem matemática", "ausência de sujeito"], 1, "As duas formas circulam em registros e situações comunicativas diferentes."),
    ("dizer 'que pontualidade!' a alguém que chegou muito atrasado produz", ["ironia", "eufemismo", "comparação", "hipérbato", "pleonasmo"], 0, "O enunciado afirma o contrário do que a situação mostra, criando ironia."),
    ("em um artigo de opinião, a tese corresponde", ["ao título apenas", "à posição central defendida", "à lista de referências", "ao nome do autor", "ao último exemplo"], 1, "A tese é a ideia central que o texto procura sustentar com argumentos."),
    ("a substituição de um termo por um pronome pode contribuir para", ["a coesão textual", "a quebra obrigatória de sentido", "a mudança de idioma", "a ausência de tema", "a eliminação do leitor"], 0, "Pronomes podem retomar referentes e conectar partes do texto."),
    ("quando uma reportagem prioriza dados, fatos e objetividade, predomina a função", ["poética", "referencial", "fática", "metalinguística", "emotiva"], 1, "A função referencial concentra-se na transmissão de informações."),
    ("uma frase é coerente quando", ["usa apenas palavras longas", "mantém relações de sentido compatíveis", "não possui verbos", "repete todas as ideias", "evita qualquer conectivo"], 1, "Coerência depende da compatibilidade e progressão das ideias."),
    ("a metáfora ocorre quando", ["há uma comparação implícita", "se apresenta uma estatística", "se repete um som", "se enumera uma lista", "se corrige uma grafia"], 0, "A metáfora aproxima sentidos sem empregar conectivo comparativo explícito."),
    ("em um texto argumentativo, um exemplo serve principalmente para", ["substituir a tese", "sustentar ou ilustrar um argumento", "ocultar o tema", "eliminar a conclusão", "marcar apenas o tempo"], 1, "Exemplos tornam o argumento mais concreto e verificável."),
]


BIOLOGY = [
    ("a fotossíntese transforma energia luminosa em", ["energia química armazenada", "energia nuclear", "calor apenas", "movimento mecânico", "som"], 0, "A energia luminosa é convertida em energia química nas moléculas orgânicas."),
    ("a retirada de predadores de topo tende inicialmente a", ["aumentar suas presas", "eliminar produtores", "impedir a respiração", "reduzir a luz", "parar o ciclo da água"], 0, "Com menor predação, a população de presas tende a crescer."),
    ("o enriquecimento de um lago por nutrientes, seguido de proliferação de algas, caracteriza", ["eutrofização", "sublimação", "mutação", "destilação", "erosão eólica"], 0, "O excesso de nutrientes desencadeia a eutrofização."),
    ("no cruzamento Aa × aa, sendo A dominante, a chance de descendente aa é", ["0%", "25%", "50%", "75%", "100%"], 2, "Metade dos gametas do indivíduo Aa possui a e o outro genitor fornece apenas a."),
    ("vacinas protegem principalmente porque estimulam", ["memória imunológica", "perda de DNA", "produção de glicose", "paralisação celular", "ausência de anticorpos"], 0, "A vacinação prepara células de memória para respostas futuras."),
    ("a seleção natural favorece", ["características herdáveis vantajosas no ambiente", "todas as mutações igualmente", "apenas organismos maiores", "mudanças por vontade", "a ausência de variação"], 0, "Características herdáveis que aumentam sucesso reprodutivo tendem a se tornar mais frequentes."),
    ("o DNA tem como função central", ["armazenar informação genética", "produzir luz", "bombear sangue", "digerir proteínas fora da célula", "formar sais minerais"], 0, "A sequência do DNA armazena instruções genéticas."),
    ("a mitocôndria participa principalmente da", ["respiração celular", "fotossíntese em animais", "digestão no estômago", "coagulação", "produção de som"], 0, "A mitocôndria é central na produção de ATP pela respiração celular."),
    ("maior biodiversidade pode aumentar", ["a resiliência dos ecossistemas", "a uniformidade genética", "a ausência de relações ecológicas", "a extinção automática", "o fim da competição"], 0, "Diversidade amplia respostas possíveis a alterações ambientais."),
    ("os decompositores contribuem para", ["reciclar nutrientes", "interromper cadeias alimentares", "eliminar o solo", "bloquear a fotossíntese", "produzir rochas"], 0, "Fungos e bactérias devolvem nutrientes ao ambiente."),
    ("a membrana plasmática apresenta", ["permeabilidade seletiva", "impermeabilidade absoluta", "apenas material genético", "parede de metal", "ausência de lipídios"], 0, "A membrana controla a entrada e a saída de substâncias."),
    ("mutações podem contribuir para a evolução porque", ["geram variação genética", "sempre são benéficas", "eliminam a hereditariedade", "impedem reprodução", "não alteram sequências"], 0, "Mutações criam novas variantes sobre as quais a seleção pode atuar."),
    ("a transpiração vegetal participa do ciclo da água ao", ["liberar vapor para a atmosfera", "fixar nitrogênio em todas as plantas", "produzir rochas", "eliminar nuvens", "impedir evaporação"], 0, "A perda de água pelas folhas devolve vapor à atmosfera."),
]


GEOGRAPHY = [
    ("em uma escala 1:100.000, 1 cm no mapa corresponde a", ["100 m", "500 m", "1 km", "10 km", "100 km"], 2, "Cem mil centímetros equivalem a um quilômetro."),
    ("a urbanização sem infraestrutura suficiente tende a ampliar", ["segregação socioespacial", "igualdade fundiária automática", "fim das periferias", "redução total do trânsito", "acesso universal imediato"], 0, "O acesso desigual a serviços e solo urbano intensifica a segregação."),
    ("a globalização contemporânea intensifica", ["fluxos de capitais, mercadorias e informações", "isolamento absoluto", "fim das redes", "desaparecimento das cidades", "autossuficiência de todos os países"], 0, "Redes técnicas ampliam fluxos em escala mundial."),
    ("desemprego e falta de serviços podem atuar na migração como fatores de", ["atração", "expulsão", "latitude", "maré", "vegetação"], 1, "Condições desfavoráveis no lugar de origem funcionam como fatores de expulsão."),
    ("na transição demográfica, a queda da mortalidade antes da natalidade costuma provocar", ["crescimento populacional", "extinção imediata", "migração zero", "queda obrigatória da urbanização", "fim do envelhecimento"], 0, "A diferença temporária entre natalidade alta e mortalidade menor acelera o crescimento."),
    ("uma fonte renovável de energia é", ["carvão mineral", "petróleo", "solar", "gás natural", "urânio"], 2, "A energia solar se renova em escala humana."),
    ("a monocultura em grandes extensões pode favorecer", ["perda de biodiversidade", "diversificação automática", "fim da erosão", "recuperação imediata do solo", "redução de pragas em todos os casos"], 0, "A homogeneização da paisagem reduz habitats e diversidade."),
    ("uma bacia hidrográfica é delimitada principalmente por", ["divisores de água", "fronteiras políticas", "fusos horários", "linhas do Equador", "placas urbanas"], 0, "O relevo direciona o escoamento e define os divisores de água."),
    ("a latitude influencia o clima porque altera", ["a incidência de radiação solar", "a composição do núcleo terrestre", "o idioma", "a moeda", "a duração do ano"], 0, "O ângulo de incidência solar varia com a latitude."),
    ("a desconcentração industrial ocorre quando empresas", ["se deslocam para novas regiões", "abandonam toda tecnologia", "eliminam transporte", "retornam ao feudalismo", "deixam de produzir"], 0, "Custos, infraestrutura e incentivos podem deslocar unidades industriais."),
    ("conurbação é o processo de", ["integração física entre manchas urbanas", "separação de continentes", "formação de desertos", "redução da população rural", "divisão de oceanos"], 0, "O crescimento aproxima e conecta áreas urbanizadas de municípios vizinhos."),
    ("toda projeção cartográfica apresenta", ["algum tipo de distorção", "escala real em todos os pontos", "ausência de escolha técnica", "somente orientação sul", "nenhuma relação matemática"], 0, "Representar uma superfície curva em um plano implica distorções."),
    ("a retirada da vegetação de encostas pode aumentar", ["erosão e deslizamentos", "estabilidade absoluta", "infiltração infinita", "formação de geleiras", "redução de escoamento em todos os casos"], 0, "Raízes ajudam a estabilizar o solo e reduzir o escoamento superficial."),
]


HISTORY = [
    ("a divisão do trabalho nas fábricas do século XIX ampliou", ["especialização das tarefas", "produção artesanal exclusiva", "fim das máquinas", "isolamento dos mercados", "poder feudal"], 0, "A produção fabril fragmentou o processo em tarefas especializadas."),
    ("o Iluminismo criticou o absolutismo e defendeu", ["razão e direitos", "servidão hereditária", "censura permanente", "fim da ciência", "privilégios imutáveis"], 0, "Pensadores iluministas valorizaram razão, liberdade e limites ao poder."),
    ("a abolição de 1888 não foi acompanhada por", ["políticas amplas de integração social", "fim legal da escravidão", "mudança jurídica", "liberdade formal", "crise do sistema escravista"], 0, "A liberdade formal não veio acompanhada de reparação e inclusão suficientes."),
    ("o coronelismo na Primeira República relacionava-se ao", ["poder local e controle eleitoral", "voto secreto universal", "fim das oligarquias", "governo parlamentar britânico", "sufrágio feminino desde 1889"], 0, "Chefes locais influenciavam votos por dependência e coerção."),
    ("a legislação trabalhista do período Vargas buscou", ["regular relações de trabalho", "eliminar direitos", "proibir sindicatos em qualquer forma", "restaurar a escravidão", "acabar com salários"], 0, "O Estado consolidou normas trabalhistas e ampliou sua mediação."),
    ("a censura durante a ditadura militar brasileira restringiu", ["liberdade de expressão", "industrialização", "urbanização", "uso de moeda", "ensino de matemática"], 0, "Órgãos estatais controlaram imprensa e manifestações artísticas."),
    ("a Constituição brasileira de 1988 marcou", ["a ampliação de direitos democráticos", "o início do período colonial", "a volta do absolutismo", "o fim das eleições", "a proibição de participação social"], 0, "A Constituição consolidou direitos no processo de redemocratização."),
    ("o pacto colonial subordinava a colônia aos interesses", ["mercantilistas da metrópole", "de sindicatos industriais", "de organismos internacionais", "do sufrágio universal", "da internet"], 0, "A metrópole controlava comércio e exploração dentro da lógica mercantilista."),
    ("o imperialismo do século XIX buscou, entre outros objetivos,", ["matérias-primas e mercados", "fim do comércio", "autonomia plena das colônias", "redução territorial europeia", "abandono da indústria"], 0, "Potências industriais expandiram domínio econômico e político."),
    ("a Revolução Francesa difundiu princípios de", ["liberdade e igualdade jurídica", "servidão feudal", "direito divino", "imobilidade social", "censura religiosa obrigatória"], 0, "O movimento questionou privilégios e afirmou igualdade perante a lei."),
    ("a Guerra Fria foi marcada pela", ["bipolaridade entre Estados Unidos e União Soviética", "aliança política única mundial", "ausência de corrida tecnológica", "extinção de conflitos indiretos", "unificação imediata da Europa"], 0, "Duas superpotências lideraram blocos rivais."),
    ("na democracia ateniense antiga, a cidadania política era", ["restrita a parte da população", "universal", "aberta a todos os escravizados", "igual para mulheres e homens", "independente de origem"], 0, "Mulheres, estrangeiros e escravizados eram excluídos."),
    ("movimentos operários surgiram em resposta a", ["condições precárias de trabalho", "excesso de direitos", "fim das fábricas", "ausência de jornadas", "desaparecimento das cidades"], 0, "Trabalhadores organizaram reivindicações por salários, jornada e proteção."),
]


SOCIOLOGY = [
    ("socialização é o processo pelo qual indivíduos", ["aprendem normas e valores sociais", "deixam de conviver", "perdem toda identidade", "eliminam instituições", "nascem com cultura pronta"], 0, "A socialização ocorre nas relações com família, escola, mídia e outros grupos."),
    ("cidadania envolve", ["direitos e participação social", "apenas consumo", "somente deveres privados", "ausência de Estado", "privilégios hereditários"], 0, "Cidadania articula direitos civis, políticos e sociais."),
    ("desigualdade social é considerada estrutural quando", ["se reproduz por instituições e relações duradouras", "depende apenas de escolhas individuais", "desaparece sem políticas", "não afeta oportunidades", "é igual em todos os grupos"], 0, "Mecanismos sociais distribuem recursos e oportunidades de forma persistente."),
    ("etnocentrismo consiste em", ["julgar outras culturas pelos valores da própria", "compreender contextos diferentes", "evitar qualquer comparação", "defender direitos universais", "estudar línguas"], 0, "O etnocentrismo toma a própria cultura como medida superior."),
    ("relativismo cultural procura", ["compreender práticas em seu contexto", "hierarquizar povos", "eliminar diferenças", "negar toda análise", "impor um único costume"], 0, "A abordagem considera sentidos e condições do grupo estudado."),
    ("família, escola e Estado são exemplos de", ["instituições sociais", "fenômenos naturais", "genes", "recursos minerais", "fusos horários"], 0, "Instituições organizam práticas, papéis e normas coletivas."),
    ("movimentos sociais atuam ao", ["organizar demandas coletivas", "eliminar participação", "impedir direitos", "substituir toda lei", "isolar indivíduos"], 0, "A ação coletiva busca reconhecimento, direitos ou mudanças."),
    ("a divisão social do trabalho refere-se à", ["distribuição de funções na sociedade", "ausência de profissões", "igualdade automática de renda", "eliminação de especializações", "proibição de cooperação"], 0, "Sociedades distribuem atividades e posições entre grupos e indivíduos."),
    ("a mídia pode influenciar o debate público ao", ["dar visibilidade a determinados temas", "determinar mecanicamente toda opinião", "eliminar conflitos", "substituir eleições", "impedir qualquer interpretação"], 0, "A seleção e o destaque de assuntos ajudam a formar agendas públicas."),
    ("participação em conselhos e audiências públicas exemplifica", ["participação democrática", "censura", "poder hereditário", "isolamento", "justiça privada"], 0, "Esses espaços permitem acompanhamento e influência sobre decisões públicas."),
    ("direitos humanos são universais porque", ["se aplicam a todas as pessoas", "dependem de riqueza", "valem só em eleições", "excluem minorias", "são privilégios profissionais"], 0, "A universalidade afirma igual dignidade independentemente de condição."),
    ("preconceito difere de discriminação porque a discriminação envolve", ["ação que produz tratamento desigual", "apenas opinião íntima", "sempre uma lei", "somente diferença cultural", "ausência de consequência"], 0, "Discriminação transforma julgamentos em práticas de exclusão."),
    ("o trabalho mediado por plataformas pode gerar precarização quando há", ["instabilidade e falta de proteção", "garantia universal de renda", "autonomia total assegurada", "fim da avaliação", "jornada sempre reduzida"], 0, "Renda incerta e transferência de riscos ao trabalhador são sinais de precarização."),
]


def _number_options(correct, step, suffix=""):
    values = [correct - 2 * step, correct - step, correct, correct + step, correct + 2 * step]
    return [f"{value}{suffix}" for value in values], 2


def _fraction_options(favorable, total, shift):
    correct = Fraction(favorable, total)
    candidates = [
        correct,
        Fraction(total - favorable, total),
        Fraction(max(1, favorable - 1), total),
        Fraction(min(total - 1, favorable + 1), total),
        Fraction(favorable, total + 1),
        Fraction(1, total),
    ]
    unique = []
    for value in candidates:
        label = str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"
        if label not in unique:
            unique.append(label)
    filler = 2
    while len(unique) < 5:
        value = Fraction(filler, total + 2)
        label = str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"
        if label not in unique:
            unique.append(label)
        filler += 1
    options = unique[:5]
    correct_index = options.index(str(correct.numerator) if correct.denominator == 1 else f"{correct.numerator}/{correct.denominator}")
    shift %= 5
    options = options[shift:] + options[:shift]
    return options, (correct_index - shift) % 5


def generated_question_variants():
    questions = []

    for index in range(20):
        base = 200 + index * 50
        percent = [5, 10, 15, 20, 25][index % 5]
        final = base * (100 + percent) // 100
        options, correct = _number_options(final, max(5, base // 20))
        questions.append(("Matemática", "Porcentagem", "easy" if index < 8 else "medium", f"Uma quantidade de {base} unidades aumentou {percent}%. Qual é o novo total?", options, correct, f"O aumento é {percent}% de {base}; somando-o ao valor inicial, obtém-se {final}."))

    for index in range(20):
        fixed = 4 + index
        rate = 2 + index % 6
        correct_text = f"C={rate}x+{fixed}"
        options = [f"C={fixed}x+{rate}", correct_text, f"C={rate + fixed}x", f"C={rate}x-{fixed}", f"C={fixed}x-{rate}"]
        questions.append(("Matemática", "Funções", "medium", f"Um serviço cobra taxa fixa de R$ {fixed} e R$ {rate} por unidade utilizada. Qual expressão representa o custo C para x unidades?", options, 1, f"A parcela variável é {rate}x e a taxa fixa é {fixed}, portanto {correct_text}."))

    for index in range(15):
        total = 8 + index
        favorable = 2 + index % (total - 3)
        options, correct = _fraction_options(favorable, total, index)
        fraction = Fraction(favorable, total)
        questions.append(("Matemática", "Probabilidade", "medium", f"Uma roleta possui {total} setores iguais, dos quais {favorable} são azuis. Qual é a probabilidade de parar em um setor azul?", options, correct, f"São {favorable} casos favoráveis em {total} possíveis: {fraction.numerator}/{fraction.denominator}."))

    for index in range(30):
        power = 10 + index * 5
        hours = 2 + index % 8
        energy = power * hours
        options, correct = _number_options(energy, max(5, power // 2), " Wh")
        questions.append(("Ciências da Natureza", "Energia", "easy" if index < 12 else "medium", f"Um aparelho de {power} W permanece ligado por {hours} horas. Qual é o consumo de energia?", options, correct, f"Energia é potência vezes tempo: {power} W × {hours} h = {energy} Wh."))

    for index in range(25):
        speed = 30 + index * 2
        hours = 2 + index % 5
        distance = speed * hours
        options, correct = _number_options(distance, max(10, speed // 2), " km")
        questions.append(("Ciências da Natureza", "Movimento", "medium", f"Um veículo mantém velocidade média de {speed} km/h durante {hours} horas. Que distância percorre?", options, correct, f"Distância é velocidade vezes tempo: {speed} × {hours} = {distance} km."))

    questions.extend(_contextual_variants("Linguagens", "Interpretação", PORTUGUESE))
    questions.extend(_contextual_variants("Ciências da Natureza", "Ecologia", BIOLOGY))
    questions.extend(_contextual_variants("Ciências Humanas", "Cartografia", GEOGRAPHY))
    questions.extend(_contextual_variants("Ciências Humanas", "Industrialização", HISTORY))
    questions.extend(_contextual_variants("Ciências Humanas", "Cidadania", SOCIOLOGY))
    return questions
