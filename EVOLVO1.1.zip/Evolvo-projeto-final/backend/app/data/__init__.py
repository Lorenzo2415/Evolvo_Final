"""Dados autorais usados pelo ambiente demonstrativo do Evolvo."""
