from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash
from ..extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class TimestampMixin:
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)


class User(TimestampMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="student")
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    goals = db.relationship("UserGoal", back_populates="user", cascade="all, delete-orphan")
    subject_preferences = db.relationship("SubjectPreference", back_populates="user", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class UserConsent(TimestampMixin, db.Model):
    __tablename__ = "user_consents"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    consent_type = db.Column(db.String(50), nullable=False)
    version = db.Column(db.String(20), nullable=False)
    accepted = db.Column(db.Boolean, nullable=False)
    decided_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "consent_type", "version"),)


class Exam(TimestampMixin, db.Model):
    __tablename__ = "exams"
    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(80), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    exam_type = db.Column(db.String(30), nullable=False)
    institution = db.Column(db.String(150))
    board = db.Column(db.String(100))
    support_status = db.Column(db.String(30), nullable=False, default="limited")
    profile = db.relationship("ExamProfile", back_populates="exam", uselist=False, cascade="all, delete-orphan")


class ExamProfile(TimestampMixin, db.Model):
    __tablename__ = "exam_profiles"
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id", ondelete="CASCADE"), unique=True, nullable=False)
    edition = db.Column(db.String(60))
    modality = db.Column(db.String(100))
    syllabus = db.Column(db.JSON, nullable=False, default=dict)
    structure = db.Column(db.JSON, nullable=False, default=dict)
    question_count = db.Column(db.Integer, nullable=False)
    alternative_count = db.Column(db.Integer, nullable=False, default=5)
    duration_minutes = db.Column(db.Integer, nullable=False)
    difficulty_levels = db.Column(db.JSON, nullable=False, default=list)
    characteristics = db.Column(db.JSON, nullable=False, default=list)
    references = db.Column(db.JSON, nullable=False, default=list)
    exam = db.relationship("Exam", back_populates="profile")


class Subject(TimestampMixin, db.Model):
    __tablename__ = "subjects"
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    area = db.Column(db.String(100), nullable=False)
    weight = db.Column(db.Float, nullable=False, default=1.0)
    topics = db.relationship("Topic", back_populates="subject", cascade="all, delete-orphan")
    __table_args__ = (db.UniqueConstraint("exam_id", "name"),)


class SubjectPreference(TimestampMixin, db.Model):
    __tablename__ = "subject_preferences"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True)
    priority = db.Column(db.Integer, nullable=False, default=1)
    user = db.relationship("User", back_populates="subject_preferences")
    subject = db.relationship("Subject")
    __table_args__ = (db.UniqueConstraint("user_id", "subject_id"), db.CheckConstraint("priority >= 1 AND priority <= 3"))


class Topic(TimestampMixin, db.Model):
    __tablename__ = "topics"
    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    importance = db.Column(db.Float, nullable=False, default=1.0)
    subject = db.relationship("Subject", back_populates="topics")
    __table_args__ = (db.UniqueConstraint("subject_id", "name"),)


class Question(TimestampMixin, db.Model):
    __tablename__ = "questions"
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_id = db.Column(db.Integer, db.ForeignKey("topics.id", ondelete="CASCADE"), nullable=False, index=True)
    statement = db.Column(db.Text, nullable=False)
    difficulty = db.Column(db.String(20), nullable=False, index=True)
    format = db.Column(db.String(20), nullable=False, default="multiple_choice")
    explanation = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="approved", index=True)
    author_type = db.Column(db.String(30), nullable=False, default="authorial")
    author_name = db.Column(db.String(120), nullable=False)
    source_label = db.Column(db.String(200))
    source_url = db.Column(db.String(500))
    license_note = db.Column(db.String(300))
    original_identifier = db.Column(db.String(100))
    media = db.Column(db.JSON, nullable=False, default=dict)
    content_hash = db.Column(db.String(64), unique=True, nullable=False)
    options = db.relationship("QuestionOption", back_populates="question", cascade="all, delete-orphan", order_by="QuestionOption.position")
    subject = db.relationship("Subject")
    topic = db.relationship("Topic")


class QuestionOption(db.Model):
    __tablename__ = "question_options"
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True)
    position = db.Column(db.Integer, nullable=False)
    text = db.Column(db.Text, nullable=False)
    is_correct = db.Column(db.Boolean, nullable=False, default=False)
    question = db.relationship("Question", back_populates="options")
    __table_args__ = (db.UniqueConstraint("question_id", "position"),)


class UserGoal(TimestampMixin, db.Model):
    __tablename__ = "user_goals"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id"), nullable=False)
    exam_date = db.Column(db.Date, nullable=False)
    daily_minutes = db.Column(db.Integer, nullable=False)
    study_days = db.Column(db.JSON, nullable=False, default=list)
    preferences = db.Column(db.JSON, nullable=False, default=dict)
    active = db.Column(db.Boolean, nullable=False, default=True)
    user = db.relationship("User", back_populates="goals")
    exam = db.relationship("Exam")


class Assessment(TimestampMixin, db.Model):
    __tablename__ = "assessments"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id"), nullable=False, index=True)
    kind = db.Column(db.String(20), nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="in_progress")
    personalized = db.Column(db.Boolean, nullable=False, default=True)
    started_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    completed_at = db.Column(db.DateTime(timezone=True))
    score = db.Column(db.Float)
    total_questions = db.Column(db.Integer, nullable=False)
    correct_answers = db.Column(db.Integer, nullable=False, default=0)
    configuration = db.Column(db.JSON, nullable=False, default=dict)
    questions = db.relationship("AssessmentQuestion", back_populates="assessment", cascade="all, delete-orphan", order_by="AssessmentQuestion.position")


class AssessmentQuestion(db.Model):
    __tablename__ = "assessment_questions"
    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("assessments.id", ondelete="CASCADE"), nullable=False, index=True)
    question_id = db.Column(db.Integer, db.ForeignKey("questions.id"), nullable=False)
    position = db.Column(db.Integer, nullable=False)
    selected_option_id = db.Column(db.Integer, db.ForeignKey("question_options.id"))
    is_correct = db.Column(db.Boolean)
    answered_at = db.Column(db.DateTime(timezone=True))
    assessment = db.relationship("Assessment", back_populates="questions")
    question = db.relationship("Question")
    selected_option = db.relationship("QuestionOption", foreign_keys=[selected_option_id])
    __table_args__ = (db.UniqueConstraint("assessment_id", "question_id"),)


class EssayPrompt(TimestampMixin, db.Model):
    __tablename__ = "essay_prompts"
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(180), nullable=False)
    theme = db.Column(db.Text, nullable=False)
    instructions = db.Column(db.Text, nullable=False)
    support_texts = db.Column(db.JSON, nullable=False, default=list)
    source_label = db.Column(db.String(200), nullable=False, default="Proposta autoral Evolvo")
    status = db.Column(db.String(20), nullable=False, default="approved", index=True)
    exam = db.relationship("Exam")


class EssaySubmission(TimestampMixin, db.Model):
    __tablename__ = "essay_submissions"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    prompt_id = db.Column(db.Integer, db.ForeignKey("essay_prompts.id", ondelete="CASCADE"), nullable=False, index=True)
    draft_text = db.Column(db.Text, nullable=False, default="")
    status = db.Column(db.String(20), nullable=False, default="draft", index=True)
    word_count = db.Column(db.Integer, nullable=False, default=0)
    analysis = db.Column(db.JSON, nullable=False, default=dict)
    submitted_at = db.Column(db.DateTime(timezone=True))
    prompt = db.relationship("EssayPrompt")
    user = db.relationship("User")
    corrections = db.relationship("EssayCorrection", back_populates="submission", cascade="all, delete-orphan", order_by="EssayCorrection.created_at")


class EssayCorrection(TimestampMixin, db.Model):
    __tablename__ = "essay_corrections"
    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey("essay_submissions.id", ondelete="CASCADE"), nullable=False, index=True)
    kind = db.Column(db.String(20), nullable=False, index=True)
    status = db.Column(db.String(20), nullable=False, default="queued", index=True)
    feedback = db.Column(db.JSON, nullable=False, default=dict)
    reviewer_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), index=True)
    requested_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    completed_at = db.Column(db.DateTime(timezone=True))
    submission = db.relationship("EssaySubmission", back_populates="corrections")
    reviewer = db.relationship("User", foreign_keys=[reviewer_id])
    __table_args__ = (
        db.UniqueConstraint("submission_id", "kind"),
        db.CheckConstraint("kind IN ('ai', 'human')"),
    )


class StudyPlan(TimestampMixin, db.Model):
    __tablename__ = "study_plans"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    goal_id = db.Column(db.Integer, db.ForeignKey("user_goals.id"), nullable=False)
    version = db.Column(db.Integer, nullable=False, default=1)
    status = db.Column(db.String(20), nullable=False, default="active")
    rationale = db.Column(db.JSON, nullable=False, default=dict)
    tasks = db.relationship("StudyTask", back_populates="plan", cascade="all, delete-orphan")


class StudyTask(TimestampMixin, db.Model):
    __tablename__ = "study_tasks"
    id = db.Column(db.Integer, primary_key=True)
    plan_id = db.Column(db.Integer, db.ForeignKey("study_plans.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_id = db.Column(db.Integer, db.ForeignKey("topics.id"), nullable=False)
    scheduled_date = db.Column(db.Date, nullable=False, index=True)
    title = db.Column(db.String(160), nullable=False)
    activity_type = db.Column(db.String(30), nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    priority_score = db.Column(db.Float, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="pending")
    started_at = db.Column(db.DateTime(timezone=True))
    completed_at = db.Column(db.DateTime(timezone=True))
    plan = db.relationship("StudyPlan", back_populates="tasks")
    topic = db.relationship("Topic")


class Performance(TimestampMixin, db.Model):
    __tablename__ = "performances"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exams.id"), nullable=False)
    topic_id = db.Column(db.Integer, db.ForeignKey("topics.id"), nullable=False, index=True)
    attempts = db.Column(db.Integer, nullable=False, default=0)
    correct = db.Column(db.Integer, nullable=False, default=0)
    weighted_score = db.Column(db.Float, nullable=False, default=0)
    mastery = db.Column(db.Float, nullable=False, default=0)
    last_result = db.Column(db.Boolean)
    last_assessed_at = db.Column(db.DateTime(timezone=True))
    __table_args__ = (db.UniqueConstraint("user_id", "exam_id", "topic_id"),)


class ReviewSchedule(TimestampMixin, db.Model):
    __tablename__ = "review_schedules"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_id = db.Column(db.Integer, db.ForeignKey("topics.id"), nullable=False)
    last_reviewed_at = db.Column(db.DateTime(timezone=True))
    next_review_at = db.Column(db.DateTime(timezone=True), nullable=False, index=True)
    interval_days = db.Column(db.Integer, nullable=False, default=1)
    last_score = db.Column(db.Float, nullable=False, default=0)
    __table_args__ = (db.UniqueConstraint("user_id", "topic_id"),)


class AIInteraction(TimestampMixin, db.Model):
    __tablename__ = "ai_interactions"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    purpose = db.Column(db.String(40), nullable=False)
    prompt_excerpt = db.Column(db.String(500), nullable=False)
    response_excerpt = db.Column(db.Text)
    provider = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    status = db.Column(db.String(20), nullable=False)


teacher_subjects = db.Table(
    "teacher_subjects",
    db.Column("teacher_id", db.Integer, db.ForeignKey("teachers.id", ondelete="CASCADE"), primary_key=True),
    db.Column("subject_id", db.Integer, db.ForeignKey("subjects.id", ondelete="CASCADE"), primary_key=True),
)


class Teacher(TimestampMixin, db.Model):
    __tablename__ = "teachers"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), unique=True, index=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    biography = db.Column(db.Text, nullable=False)
    avatar_url = db.Column(db.String(500))
    hourly_price = db.Column(db.Float, nullable=False, index=True)
    modality = db.Column(db.String(20), nullable=False, index=True)
    city = db.Column(db.String(120), index=True)
    contact = db.Column(db.String(200))
    is_test_data = db.Column(db.Boolean, nullable=False, default=True)
    active = db.Column(db.Boolean, nullable=False, default=True)
    subjects = db.relationship("Subject", secondary=teacher_subjects, lazy="selectin")
    reviews = db.relationship("TeacherReview", back_populates="teacher", cascade="all, delete-orphan")
    user = db.relationship("User", foreign_keys=[user_id])
    contact_requests = db.relationship("TeacherContactRequest", back_populates="teacher", cascade="all, delete-orphan")


class TeacherReview(TimestampMixin, db.Model):
    __tablename__ = "teacher_reviews"
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(800))
    teacher = db.relationship("Teacher", back_populates="reviews")
    user = db.relationship("User")
    __table_args__ = (
        db.UniqueConstraint("teacher_id", "user_id"),
        db.CheckConstraint("rating >= 1 AND rating <= 5"),
    )


class TeacherContactRequest(TimestampMixin, db.Model):
    __tablename__ = "teacher_contact_requests"
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id", ondelete="SET NULL"), index=True)
    message = db.Column(db.String(1000), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="new", index=True)
    teacher = db.relationship("Teacher", back_populates="contact_requests")
    student = db.relationship("User", foreign_keys=[student_id])
    subject = db.relationship("Subject")
    __table_args__ = (db.CheckConstraint("status IN ('new', 'contacted', 'closed')"),)


class TeacherPartnerApplication(TimestampMixin, db.Model):
    __tablename__ = "teacher_partner_applications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    biography = db.Column(db.Text, nullable=False)
    hourly_price = db.Column(db.Float, nullable=False)
    modality = db.Column(db.String(20), nullable=False)
    city = db.Column(db.String(120))
    contact = db.Column(db.String(200), nullable=False)
    subject_ids = db.Column(db.JSON, nullable=False, default=list)
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    reviewed_by = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), index=True)
    reviewed_at = db.Column(db.DateTime(timezone=True))
    user = db.relationship("User", foreign_keys=[user_id])
    reviewer = db.relationship("User", foreign_keys=[reviewed_by])
    __table_args__ = (db.CheckConstraint("status IN ('pending', 'approved', 'rejected')"),)

