import os
os.environ.setdefault("DISABLE_SQLALCHEMY_CEXT_RUNTIME", "1")
from datetime import timedelta
from pathlib import Path
from flask import Flask, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from .extensions import db, migrate, jwt
from .errors import AppError


def create_app(test_config=None):
    load_dotenv()
    app = Flask(__name__, instance_relative_config=True)
    default_db = "sqlite:///" + str(Path(app.instance_path) / "evolvo.sqlite3")
    app.config.from_mapping(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
        JWT_SECRET_KEY=os.getenv("JWT_SECRET_KEY", "dev-jwt-change-me-with-32-characters"),
        JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=8),
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", default_db),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JSON_SORT_KEYS=False,
        AI_PROVIDER_URL=os.getenv("AI_PROVIDER_URL", "https://api.openai.com/v1/responses"),
        AI_API_KEY=os.getenv("AI_API_KEY", ""),
        AI_MODEL=os.getenv("AI_MODEL", "gpt-5-mini"),
    )
    if test_config:
        app.config.update(test_config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    configured_origins = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173,http://127.0.0.1:5173")
    CORS(app, resources={r"/api/*": {"origins": [item.strip() for item in configured_origins.split(",") if item.strip()]}})

    from .models import entities  # noqa: F401
    from .routes.api import api
    app.register_blueprint(api, url_prefix="/api")

    @app.errorhandler(AppError)
    def handle_app_error(error):
        return jsonify({"error": error.code, "message": error.message}), error.status

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "not_found", "message": "Recurso não encontrado."}), 404

    @app.errorhandler(Exception)
    def unhandled(error):
        db.session.rollback()
        if app.testing:
            raise error
        app.logger.exception(error)
        return jsonify({"error": "internal_error", "message": "Não foi possível concluir a operação."}), 500

    return app

