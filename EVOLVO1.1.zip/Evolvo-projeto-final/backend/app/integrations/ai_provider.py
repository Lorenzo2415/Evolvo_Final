import requests
from flask import current_app
from ..errors import AppError


class AIProviderClient:
    def respond(self, prompt, max_input_chars=4000, max_output_tokens=600):
        api_key = current_app.config.get("AI_API_KEY")
        if not api_key:
            raise AppError("Correção por IA indisponível: configure AI_API_KEY no backend.", 503, "ai_not_configured")
        if len(prompt) > max_input_chars:
            raise AppError("O conteúdo excede o limite aceito para esta análise.", 422, "prompt_too_long")
        try:
            response = requests.post(
                current_app.config["AI_PROVIDER_URL"],
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": current_app.config["AI_MODEL"], "input": prompt, "max_output_tokens": max_output_tokens},
                timeout=60,
            )
            response.raise_for_status()
            data = response.json()
            if data.get("output_text"):
                return data["output_text"]
            chunks = [part.get("text", "") for item in data.get("output", []) for part in item.get("content", []) if part.get("type") == "output_text"]
            return "\n".join(chunks).strip()
        except requests.HTTPError as exc:
            try:
                provider_error = exc.response.json().get("error", {})
            except (TypeError, ValueError):
                provider_error = {}
            code = provider_error.get("code")
            if code in {"insufficient_quota", "credit_balance_exhausted"}:
                raise AppError(
                    "A correção por IA está temporariamente sem créditos. O responsável pela plataforma precisa regularizar o saldo da API.",
                    503,
                    "ai_credits_exhausted",
                ) from exc
            if exc.response.status_code == 401:
                raise AppError("A credencial da IA é inválida ou foi revogada.", 503, "ai_invalid_key") from exc
            raise AppError("A OpenAI não conseguiu concluir a correção neste momento.", 502, "ai_provider_error") from exc
        except requests.RequestException as exc:
            raise AppError("A OpenAI não respondeu. Tente novamente em instantes.", 502, "ai_provider_error") from exc

