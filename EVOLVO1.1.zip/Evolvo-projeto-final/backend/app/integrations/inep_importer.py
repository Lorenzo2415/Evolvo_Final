"""Adaptador para conjuntos autorizados de provas/gabaritos do INEP.

Não baixa nem presume licença. Recebe registros já obtidos de uma fonte cujo uso foi
verificado pelo operador e sempre cria rascunhos para revisão humana.
"""
import csv
import json
from pathlib import Path
from ..errors import AppError
from ..services.question_admin_services import ImportQuestionsService


class INEPQuestionImporter:
    REQUIRED = {"original_identifier", "statement", "explanation", "difficulty", "options", "correct_index"}

    def load(self, file_path, context):
        path = Path(file_path)
        if not context.get("sourceUrl") or not context.get("licenseNote"):
            raise AppError("Informe a URL da fonte e a condição de uso antes da importação.", 422, "source_evidence_required")
        if path.suffix.lower() == ".json":
            records = json.loads(path.read_text(encoding="utf-8"))
        elif path.suffix.lower() == ".csv":
            with path.open(encoding="utf-8-sig", newline="") as handle:
                records = list(csv.DictReader(handle))
                for record in records:
                    record["options"] = json.loads(record["options"])
                    record["correct_index"] = int(record["correct_index"])
        else:
            raise AppError("Use arquivo CSV ou JSON.", 422, "unsupported_import_format")
        items = [self._map(record, context) for record in records]
        return ImportQuestionsService().execute(items)

    def _map(self, record, context):
        missing = self.REQUIRED.difference(record)
        if missing:
            raise AppError(f"Registro oficial incompleto: {', '.join(sorted(missing))}.", 422, "invalid_official_record")
        options = [{"text": text, "isCorrect": index == int(record["correct_index"])} for index, text in enumerate(record["options"])]
        return {
            "examId": context["examId"], "subjectId": context["subjectId"], "topicId": context["topicId"],
            "statement": record["statement"], "explanation": record["explanation"], "difficulty": record["difficulty"],
            "format": record.get("format", "multiple_choice"), "options": options, "status": "draft",
            "authorType": "official", "authorName": context.get("institution", "INEP"),
            "sourceLabel": context.get("sourceLabel", "Prova pública do INEP"), "sourceUrl": context["sourceUrl"],
            "licenseNote": context["licenseNote"], "originalIdentifier": record["original_identifier"],
        }

