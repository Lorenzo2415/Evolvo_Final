class AppError(Exception):
    def __init__(self, message: str, status: int = 400, code: str = "application_error"):
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code

