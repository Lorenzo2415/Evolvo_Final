from flask import jsonify, request
from flask_jwt_extended import create_access_token, get_jwt, get_jwt_identity
from ..errors import AppError
from ..utils.serializers import assessment_dict, exam_dict, question_dict
from ..services.auth_services import AuthenticateUserService, GetConsentStatusService, GetCurrentUserService, RecordConsentService, RegisterUserService, user_payload
from ..services.catalog_services import ListExamsService, ListExamSubjectsService
from ..services.goal_services import ConfigureGoalService, GetGoalService
from ..services.assessment_services import (
    AnalyzeDifficultiesService, FinishDiagnosticService, FinishExerciseListService,
    FinishSimulationService, GenerateExerciseListService, GenerateReviewService,
    GenerateSimulationService, GetCommentedResolutionService, StartDiagnosticService,
)
from ..services.plan_services import GenerateDailyRoutineService, GenerateStudyPlanService, GetStudyPlanService, ReplanStudiesService, UpdateStudyTaskService
from ..services.intelligence_services import GenerateEvolutionReportService, GetDashboardService, RecommendNextStudyService, RefreshPerformanceProfileService
from ..services.rubric_services import GetSubjectPreferencesService, SaveSubjectPreferencesService, SearchQuestionsService, SimulationHistoryService, UpdateProfileService
from ..services.teacher_services import (
    ApplyTeacherPartnershipService, CreateTeacherContactRequestService, DeleteTeacherReviewService,
    GetTeacherPartnershipService, GetTeacherProfileService, ListTeacherContactRequestsService,
    ListTeacherPartnershipsService, ReviewTeacherPartnershipService, ReviewTeacherService,
    SearchTeachersService, UpdateTeacherContactRequestService,
)
from ..services.essay_services import (
    CompleteHumanEssayCorrectionService, ListEssayPromptsService, ListEssaySubmissionsService,
    ListHumanEssayQueueService, RequestAIEssayCorrectionService, RequestHumanEssayCorrectionService,
    SaveEssayDraftService, StartEssayService, SubmitEssayService,
)


def current_user_id():
    return int(get_jwt_identity())


def task_dict(task):
    return {"id": task.id, "title": task.title, "topicId": task.topic_id, "topic": task.topic.name, "subjectId": task.topic.subject_id, "subject": task.topic.subject.name, "scheduledDate": task.scheduled_date.isoformat(), "activityType": task.activity_type, "durationMinutes": task.duration_minutes, "priorityScore": task.priority_score, "reason": task.reason, "status": task.status}


def essay_prompt_dict(item):
    return {"id": item.id, "title": item.title, "theme": item.theme, "instructions": item.instructions, "supportTexts": item.support_texts, "sourceLabel": item.source_label}


def essay_correction_dict(item):
    return {
        "id": item.id,
        "kind": item.kind,
        "status": item.status,
        "feedback": item.feedback or {},
        "reviewerName": item.reviewer.name if item.reviewer and item.status == "completed" else None,
        "requestedAt": item.requested_at.isoformat(),
        "completedAt": item.completed_at.isoformat() if item.completed_at else None,
    }


def essay_submission_dict(item):
    return {"id": item.id, "promptId": item.prompt_id, "prompt": essay_prompt_dict(item.prompt), "draftText": item.draft_text, "status": item.status, "wordCount": item.word_count, "characterCount": len(item.draft_text.strip()), "analysis": item.analysis, "corrections": [essay_correction_dict(correction) for correction in item.corrections], "submittedAt": item.submitted_at.isoformat() if item.submitted_at else None, "updatedAt": item.updated_at.isoformat()}


class AuthController:
    @staticmethod
    def register():
        return jsonify(RegisterUserService().execute(request.get_json() or {})), 201

    @staticmethod
    def login():
        return jsonify(AuthenticateUserService().execute(request.get_json() or {}))

    @staticmethod
    def me():
        user = GetCurrentUserService().execute(current_user_id())
        return jsonify(user_payload(user))

    @staticmethod
    def consent():
        return jsonify(RecordConsentService().execute(current_user_id(), request.get_json() or {}))

    @staticmethod
    def consent_status():
        return jsonify(GetConsentStatusService().execute(current_user_id()))

    @staticmethod
    def update_profile():
        user = UpdateProfileService().execute(current_user_id(), request.get_json() or {})
        return jsonify({"id": user.id, "name": user.name, "email": user.email, "role": user.role})


class ExamController:
    @staticmethod
    def list():
        return jsonify([exam_dict(exam) for exam in ListExamsService().execute()])

    @staticmethod
    def subjects(exam_id):
        return jsonify(ListExamSubjectsService().execute(exam_id))


class GoalController:
    @staticmethod
    def get():
        goal = GetGoalService().execute(current_user_id())
        if not goal:
            return jsonify(None)
        return jsonify({"id": goal.id, "exam": exam_dict(goal.exam), "examDate": goal.exam_date.isoformat(), "dailyMinutes": goal.daily_minutes, "studyDays": goal.study_days, "preferences": goal.preferences})

    @staticmethod
    def configure():
        goal = ConfigureGoalService().execute(current_user_id(), request.get_json() or {})
        return jsonify({"id": goal.id, "examId": goal.exam_id, "examDate": goal.exam_date.isoformat(), "dailyMinutes": goal.daily_minutes, "studyDays": goal.study_days}), 201


class DiagnosticController:
    @staticmethod
    def start():
        item = StartDiagnosticService().execute(current_user_id(), request.get_json() or {})
        return jsonify(assessment_dict(item)), 201

    @staticmethod
    def finish(assessment_id):
        payload = request.get_json() or {}
        item = FinishDiagnosticService().execute(current_user_id(), assessment_id, payload.get("answers", []))
        return jsonify(assessment_dict(item, True))

    @staticmethod
    def analysis(assessment_id):
        return jsonify(AnalyzeDifficultiesService().execute(current_user_id(), assessment_id))


class PlanController:
    @staticmethod
    def generate():
        plan = GenerateStudyPlanService().execute(current_user_id())
        return jsonify({"id": plan.id, "version": plan.version, "status": plan.status, "rationale": plan.rationale, "tasks": [task_dict(task) for task in plan.tasks]}), 201

    @staticmethod
    def get():
        plan = GetStudyPlanService().execute(current_user_id())
        if not plan:
            return jsonify(None)
        return jsonify({"id": plan.id, "version": plan.version, "status": plan.status, "rationale": plan.rationale, "tasks": [task_dict(task) for task in sorted(plan.tasks, key=lambda item: item.scheduled_date)]})

    @staticmethod
    def routine():
        tasks = GenerateDailyRoutineService().execute(current_user_id(), request.args.get("date"))
        return jsonify([task_dict(task) for task in tasks])

    @staticmethod
    def update_task(task_id):
        task = UpdateStudyTaskService().execute(current_user_id(), task_id, (request.get_json() or {}).get("status"))
        return jsonify(task_dict(task))

    @staticmethod
    def replan():
        plan = ReplanStudiesService().execute(current_user_id())
        return jsonify({"id": plan.id, "version": plan.version, "status": plan.status, "tasks": [task_dict(task) for task in plan.tasks]}), 201


class ExerciseController:
    @staticmethod
    def generate():
        item = GenerateExerciseListService().execute(current_user_id(), request.get_json() or {})
        return jsonify(assessment_dict(item)), 201

    @staticmethod
    def finish(assessment_id):
        payload = request.get_json() or {}
        item = FinishExerciseListService().execute(current_user_id(), assessment_id, payload.get("answers", []), payload.get("timing"))
        return jsonify(assessment_dict(item, True))

    @staticmethod
    def resolution(assessment_id):
        return jsonify(assessment_dict(GetCommentedResolutionService().execute(current_user_id(), assessment_id), True))

    @staticmethod
    def review():
        item = GenerateReviewService().execute(current_user_id(), request.get_json() or {})
        return jsonify(assessment_dict(item)), 201


class EssayController:
    @staticmethod
    def prompts():
        return jsonify([essay_prompt_dict(item) for item in ListEssayPromptsService().execute(current_user_id())])

    @staticmethod
    def submissions():
        return jsonify([essay_submission_dict(item) for item in ListEssaySubmissionsService().execute(current_user_id())])

    @staticmethod
    def start():
        item = StartEssayService().execute(current_user_id(), (request.get_json() or {}).get("promptId"))
        return jsonify(essay_submission_dict(item)), 201

    @staticmethod
    def save(submission_id):
        item = SaveEssayDraftService().execute(current_user_id(), submission_id, (request.get_json() or {}).get("draftText", ""))
        return jsonify(essay_submission_dict(item))

    @staticmethod
    def submit(submission_id):
        item = SubmitEssayService().execute(current_user_id(), submission_id, (request.get_json() or {}).get("draftText", ""))
        return jsonify(essay_submission_dict(item))

    @staticmethod
    def ai_correction(submission_id):
        correction = RequestAIEssayCorrectionService().execute(current_user_id(), submission_id)
        return jsonify(essay_correction_dict(correction)), 201

    @staticmethod
    def human_correction(submission_id):
        correction = RequestHumanEssayCorrectionService().execute(current_user_id(), submission_id)
        return jsonify(essay_correction_dict(correction)), 201


class EssayReviewerController:
    @staticmethod
    def _require_reviewer():
        if get_jwt().get("role") not in {"admin", "reviewer", "teacher"}:
            raise AppError("Acesso restrito à equipe de correção.", 403, "reviewer_required")

    @classmethod
    def queue(cls):
        cls._require_reviewer()
        payload = []
        for correction in ListHumanEssayQueueService().execute():
            submission = correction.submission
            payload.append({
                **essay_correction_dict(correction),
                "submission": {
                    "id": submission.id,
                    "studentName": submission.user.name,
                    "promptTitle": submission.prompt.title,
                    "theme": submission.prompt.theme,
                    "text": submission.draft_text,
                    "wordCount": submission.word_count,
                    "characterCount": len(submission.draft_text.strip()),
                },
            })
        return jsonify(payload)

    @classmethod
    def complete(cls, correction_id):
        cls._require_reviewer()
        correction = CompleteHumanEssayCorrectionService().execute(current_user_id(), correction_id, request.get_json() or {})
        return jsonify(essay_correction_dict(correction))

class SimulationController:
    @staticmethod
    def generate():
        item = GenerateSimulationService().execute(current_user_id(), request.get_json() or {})
        return jsonify(assessment_dict(item)), 201

    @staticmethod
    def finish(assessment_id):
        payload = request.get_json() or {}
        item = FinishSimulationService().execute(current_user_id(), assessment_id, payload.get("answers", []), payload.get("timing"))
        return jsonify(assessment_dict(item, True))

    @staticmethod
    def history():
        return jsonify([assessment_dict(item) for item in SimulationHistoryService().execute(current_user_id())])


class QuestionCatalogController:
    @staticmethod
    def search():
        return jsonify([question_dict(item) for item in SearchQuestionsService().execute(current_user_id(), request.args)])


def preference_dict(item):
    subject, priority = item
    return {"subjectId": subject.id, "name": subject.name, "area": subject.area, "selected": priority is not None, "priority": priority}


class PreferenceController:
    @staticmethod
    def get():
        return jsonify([preference_dict(item) for item in GetSubjectPreferencesService().execute(current_user_id())])

    @staticmethod
    def save():
        return jsonify([preference_dict(item) for item in SaveSubjectPreferencesService().execute(current_user_id(), request.get_json() or {})])


def teacher_dict(teacher, average, count, include_reviews=False, viewer_id=None):
    payload = {"id": teacher.id, "name": teacher.name, "biography": teacher.biography, "avatarUrl": teacher.avatar_url, "hourlyPrice": teacher.hourly_price, "modality": teacher.modality, "city": teacher.city, "contact": teacher.contact, "isTestData": teacher.is_test_data, "averageRating": round(average, 1), "reviewCount": count, "subjects": [{"id": item.id, "name": item.name} for item in teacher.subjects]}
    if include_reviews:
        payload["reviews"] = [{"id": item.id, "rating": item.rating, "comment": item.comment, "student": item.user.name, "updatedAt": item.updated_at.isoformat(), "isMine": item.user_id == viewer_id} for item in sorted(teacher.reviews, key=lambda row: row.updated_at, reverse=True)]
    return payload


class TeacherController:
    @staticmethod
    def search():
        return jsonify([teacher_dict(*item) for item in SearchTeachersService().execute(request.args)])

    @staticmethod
    def get(teacher_id):
        teacher, summary = GetTeacherProfileService().execute(teacher_id)
        return jsonify(teacher_dict(teacher, *summary, include_reviews=True, viewer_id=current_user_id()))

    @staticmethod
    def review(teacher_id):
        review, summary = ReviewTeacherService().execute(current_user_id(), teacher_id, request.get_json() or {})
        return jsonify({"id": review.id, "rating": review.rating, "comment": review.comment, "averageRating": round(summary[0], 1), "reviewCount": summary[1]}), 201

    @staticmethod
    def delete_review(teacher_id):
        summary = DeleteTeacherReviewService().execute(current_user_id(), teacher_id)
        return jsonify({"averageRating": round(summary[0], 1), "reviewCount": summary[1]})

    @staticmethod
    def request_contact(teacher_id):
        item = CreateTeacherContactRequestService().execute(current_user_id(), teacher_id, request.get_json() or {})
        return jsonify(teacher_contact_request_dict(item)), 201


def teacher_contact_request_dict(item):
    return {
        "id": item.id, "teacherId": item.teacher_id,
        "student": {"id": item.student.id, "name": item.student.name, "email": item.student.email},
        "subject": {"id": item.subject.id, "name": item.subject.name} if item.subject else None,
        "message": item.message, "status": item.status,
        "createdAt": item.created_at.isoformat(), "updatedAt": item.updated_at.isoformat(),
    }


class TeacherAreaController:
    @staticmethod
    def contacts():
        return jsonify([teacher_contact_request_dict(item) for item in ListTeacherContactRequestsService().execute(current_user_id())])

    @staticmethod
    def update_contact(request_id):
        item = UpdateTeacherContactRequestService().execute(
            current_user_id(), request_id, (request.get_json() or {}).get("status")
        )
        return jsonify(teacher_contact_request_dict(item))


def teacher_partnership_dict(item):
    return {
        "id": item.id, "userId": item.user_id, "name": item.user.name,
        "email": item.user.email, "biography": item.biography,
        "hourlyPrice": item.hourly_price, "modality": item.modality,
        "city": item.city, "contact": item.contact, "subjectIds": item.subject_ids,
        "status": item.status, "createdAt": item.created_at.isoformat(),
        "reviewedAt": item.reviewed_at.isoformat() if item.reviewed_at else None,
    }


class TeacherPartnershipController:
    @staticmethod
    def get():
        item = GetTeacherPartnershipService().execute(current_user_id())
        return jsonify(teacher_partnership_dict(item) if item else None)

    @staticmethod
    def apply():
        item = ApplyTeacherPartnershipService().execute(current_user_id(), request.get_json() or {})
        payload = teacher_partnership_dict(item)
        payload["accessToken"] = create_access_token(identity=str(item.user_id), additional_claims={"role": "teacher"})
        return jsonify(payload), 201

    @staticmethod
    def list():
        if get_jwt().get("role") != "admin":
            raise AppError("Acesso restrito à administração.", 403, "admin_required")
        return jsonify([teacher_partnership_dict(item) for item in ListTeacherPartnershipsService().execute()])

    @staticmethod
    def review(application_id):
        if get_jwt().get("role") != "admin":
            raise AppError("Acesso restrito à administração.", 403, "admin_required")
        item = ReviewTeacherPartnershipService().execute(
            current_user_id(), application_id, (request.get_json() or {}).get("status")
        )
        return jsonify(teacher_partnership_dict(item))


class IntelligenceController:
    @staticmethod
    def refresh_performance():
        items = RefreshPerformanceProfileService().execute(current_user_id())
        return jsonify([{"topicId": item.topic_id, "attempts": item.attempts, "correct": item.correct, "mastery": item.mastery} for item in items])

    @staticmethod
    def report():
        return jsonify(GenerateEvolutionReportService().execute(current_user_id()))

    @staticmethod
    def recommendation():
        return jsonify(RecommendNextStudyService().execute(current_user_id()))

class DashboardController:
    @staticmethod
    def get():
        result = GetDashboardService().execute(current_user_id())
        return jsonify({
            "user": {"name": result["userName"]},
            "goal": result["goal"],
            "metrics": result["metrics"],
            "todayTasks": [task_dict(task) for task in result["todayTasks"]],
            "priorities": result["priorities"],
            "evolution": result["evolution"],
            "recent": result["recent"],
        })

