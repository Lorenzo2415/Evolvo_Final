from flask import jsonify, request
from flask_jwt_extended import get_jwt
from ..errors import AppError
from ..utils.serializers import question_dict
from ..services.question_admin_services import (
    CheckDuplicateQuestionService, CreateQuestionService, GenerateQuestionDraftService,
    ImportQuestionsService, ListAdminQuestionsService, ReviewQuestionService, UpdateQuestionService,
)
from .api_controllers import current_user_id


def require_admin():
    if get_jwt().get("role") != "admin":
        raise AppError("Acesso restrito à administração.", 403, "admin_required")


class QuestionAdminController:
    @staticmethod
    def list():
        require_admin()
        result = ListAdminQuestionsService().execute(request.args.get("examId", type=int), request.args.get("status"), request.args.get("page", 1, type=int))
        return jsonify({"items": [question_dict(item, True) | {"status": item.status, "authorType": item.author_type} for item in result.items], "page": result.page, "pages": result.pages, "total": result.total})

    @staticmethod
    def create():
        require_admin()
        item = CreateQuestionService().execute(request.get_json() or {})
        return jsonify(question_dict(item, True) | {"status": item.status}), 201

    @staticmethod
    def review(question_id):
        require_admin()
        item = ReviewQuestionService().execute(question_id, (request.get_json() or {}).get("status"))
        return jsonify({"id": item.id, "status": item.status})

    @staticmethod
    def update(question_id):
        require_admin()
        item = UpdateQuestionService().execute(question_id, request.get_json() or {})
        return jsonify(question_dict(item, True) | {"status": item.status})

    @staticmethod
    def import_batch():
        require_admin()
        items = ImportQuestionsService().execute((request.get_json() or {}).get("items"))
        return jsonify({"created": len(items), "ids": [item.id for item in items]}), 201

    @staticmethod
    def duplicates():
        require_admin()
        return jsonify(CheckDuplicateQuestionService().execute(request.args.get("statement", "")))

    @staticmethod
    def generate_draft():
        require_admin()
        item = GenerateQuestionDraftService().execute(current_user_id(), request.get_json() or {})
        return jsonify(question_dict(item, True) | {"status": item.status}), 201

