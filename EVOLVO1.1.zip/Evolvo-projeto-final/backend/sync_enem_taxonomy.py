"""Cadastra a matriz de conteúdos do ENEM e reclassifica questões oficiais por matéria e assunto."""
from app import create_app
from app.extensions import db
from app.models.entities import Assessment, Exam, Question, Subject, Topic, User
from app.services.intelligence_services import RefreshPerformanceProfileService
from app.services.plan_services import AdaptActivePlanService
from app.services.question_taxonomy import ENEM_TAXONOMY, infer_subject, infer_topic


def sync():
    exam = Exam.query.filter_by(slug="enem").first()
    if not exam:
        raise RuntimeError("ENEM não cadastrado.")
    subjects = {}
    topics = {}
    for subject_name, (area, topic_names) in ENEM_TAXONOMY.items():
        subject = Subject.query.filter_by(exam_id=exam.id, name=subject_name).first()
        if not subject:
            subject = Subject(exam_id=exam.id, name=subject_name, area=area, weight=1.0)
            db.session.add(subject)
            db.session.flush()
        else:
            subject.area = area
        subjects[subject_name] = subject
        for topic_name in topic_names:
            topic = Topic.query.filter_by(subject_id=subject.id, name=topic_name).first()
            if not topic:
                topic = Topic(subject_id=subject.id, name=topic_name, importance=1.0)
                db.session.add(topic)
                db.session.flush()
            topics[(subject_name, topic_name)] = topic

    changed = 0
    official = Question.query.filter(Question.exam_id == exam.id, Question.author_type == "official").all()
    for question in official:
        subject_name = infer_subject(question.subject.name, question.statement)
        topic_name = infer_topic(subject_name, question.statement)
        subject = subjects[subject_name]
        topic = topics[(subject_name, topic_name)]
        if question.subject_id != subject.id or question.topic_id != topic.id:
            question.subject_id = subject.id
            question.topic_id = topic.id
            changed += 1
    db.session.commit()
    users = User.query.join(Assessment, Assessment.user_id == User.id).filter(Assessment.status == "completed").distinct().all()
    for user in users:
        RefreshPerformanceProfileService().execute(user.id)
        AdaptActivePlanService().execute(user.id)
    db.session.commit()
    print(f"Taxonomia ENEM sincronizada: {len(subjects)} matérias, {len(topics)} submatérias e {changed} questões reclassificadas; {len(users)} perfis recalculados.")


if __name__ == "__main__":
    with create_app().app_context():
        sync()
