from app.models.entities import QuestionOption, TeacherReview


def correct_answers(app, assessment):
    with app.app_context():
        return [{"questionId": item["id"], "optionId": QuestionOption.query.filter_by(question_id=item["id"], is_correct=True).first().id} for item in assessment["questions"]]


def test_update_profile_persists_and_rejects_duplicate(client, auth):
    updated = client.put("/api/auth/me", headers=auth, json={"name": "Estudante Atualizado", "email": "atualizado@example.com"})
    assert updated.status_code == 200
    assert updated.get_json()["name"] == "Estudante Atualizado"
    assert client.get("/api/auth/me", headers=auth).get_json()["email"] == "atualizado@example.com"
    duplicate = client.put("/api/auth/me", headers=auth, json={"name": "Outro", "email": "admin@evolvo.local"})
    assert duplicate.status_code == 409


def test_subject_preferences_are_saved_and_recovered(client, auth):
    available = client.get("/api/preferences/subjects", headers=auth)
    assert available.status_code == 200
    first_two = available.get_json()[:2]
    saved = client.put("/api/preferences/subjects", headers=auth, json={"subjects": [
        {"subjectId": first_two[0]["subjectId"], "priority": 3},
        {"subjectId": first_two[1]["subjectId"], "priority": 2},
    ]})
    assert saved.status_code == 200
    selected = [item for item in client.get("/api/preferences/subjects", headers=auth).get_json() if item["selected"]]
    assert {(item["subjectId"], item["priority"]) for item in selected} == {(first_two[0]["subjectId"], 3), (first_two[1]["subjectId"], 2)}


def test_question_search_combines_subject_and_difficulty(client, auth):
    goal = client.get("/api/goal", headers=auth).get_json()
    subjects = client.get(f"/api/exams/{goal['exam']['id']}/subjects", headers=auth).get_json()
    mathematics = next(item for item in subjects if item["name"] == "Matemática")
    response = client.get(f"/api/questions?subjectId={mathematics['id']}&difficulty=medium&limit=10", headers=auth)
    assert response.status_code == 200
    assert response.get_json()
    assert all(item["subject"] == "Matemática" and item["difficulty"] == "medium" for item in response.get_json())
    assert all("correctOptionId" not in item for item in response.get_json())


def test_personalized_simulation_filters_and_history(client, app, auth):
    goal = client.get("/api/goal", headers=auth).get_json()
    subjects = client.get(f"/api/exams/{goal['exam']['id']}/subjects", headers=auth).get_json()
    mathematics = next(item for item in subjects if item["name"] == "Matemática")
    created = client.post("/api/simulations", headers=auth, json={"questionCount": 5, "subjectIds": [mathematics["id"]], "difficulty": "medium"})
    assert created.status_code == 201, created.get_json()
    assessment = created.get_json()
    assert all(item["subject"] == "Matemática" and item["difficulty"] == "medium" for item in assessment["questions"])
    finished = client.post(f"/api/simulations/{assessment['id']}/finish", headers=auth, json={"answers": correct_answers(app, assessment)})
    assert finished.status_code == 200
    history = client.get("/api/simulations/history", headers=auth)
    assert history.status_code == 200
    assert history.get_json()[0]["id"] == assessment["id"]
    assert history.get_json()[0]["score"] == 100


def test_teacher_search_combines_filters_and_price_order(client, auth):
    goal = client.get("/api/goal", headers=auth).get_json()
    subjects = client.get(f"/api/exams/{goal['exam']['id']}/subjects", headers=auth).get_json()
    geography = next(item for item in subjects if item["name"] == "Geografia")
    response = client.get(f"/api/teachers?subjectId={geography['id']}&modality=online&sort=price_asc", headers=auth)
    assert response.status_code == 200, response.get_json()
    items = response.get_json()
    assert items and all(any(subject["name"] == "Geografia" for subject in item["subjects"]) for item in items)
    assert all(item["modality"] in {"online", "both"} for item in items)
    assert [item["hourlyPrice"] for item in items] == sorted(item["hourlyPrice"] for item in items)


def test_teacher_search_by_name_and_rating_order(client, auth):
    named = client.get("/api/teachers?name=ana", headers=auth)
    assert named.status_code == 200
    assert [item["name"] for item in named.get_json()] == ["Ana Martins"]
    ranked = client.get("/api/teachers?sort=rating_desc", headers=auth).get_json()
    assert ranked[0]["averageRating"] >= ranked[-1]["averageRating"]


def test_teacher_profile_and_review_are_persisted_as_one_editable_review(client, app, auth):
    teacher = client.get("/api/teachers?name=Carla", headers=auth).get_json()[0]
    detail = client.get(f"/api/teachers/{teacher['id']}", headers=auth)
    assert detail.status_code == 200
    assert detail.get_json()["biography"] and detail.get_json()["subjects"]
    first = client.post(f"/api/teachers/{teacher['id']}/reviews", headers=auth, json={"rating": 3, "comment": "Boa aula"})
    second = client.post(f"/api/teachers/{teacher['id']}/reviews", headers=auth, json={"rating": 5, "comment": "Avaliação atualizada"})
    assert first.status_code == second.status_code == 201
    with app.app_context():
        assert TeacherReview.query.filter_by(teacher_id=teacher["id"]).count() == 1
        assert TeacherReview.query.filter_by(teacher_id=teacher["id"]).first().rating == 5
    refreshed = client.get(f"/api/teachers/{teacher['id']}", headers=auth).get_json()
    assert refreshed["averageRating"] == 5
    assert refreshed["reviewCount"] == 1


def test_teacher_review_validates_rating_and_authentication(client, auth):
    teacher_id = client.get("/api/teachers", headers=auth).get_json()[0]["id"]
    assert client.post(f"/api/teachers/{teacher_id}/reviews", headers=auth, json={"rating": 6}).status_code == 422
    assert client.post(f"/api/teachers/{teacher_id}/reviews", json={"rating": 5}).status_code == 401


def test_teacher_review_crud_delete_uses_authenticated_owner(client, app, auth):
    teacher_id = client.get("/api/teachers?name=Carla", headers=auth).get_json()[0]["id"]
    assert client.post(f"/api/teachers/{teacher_id}/reviews", headers=auth, json={"rating": 4}).status_code == 201
    deleted = client.delete(f"/api/teachers/{teacher_id}/reviews", headers=auth)
    assert deleted.status_code == 200
    with app.app_context():
        assert TeacherReview.query.filter_by(teacher_id=teacher_id).count() == 0
