import pytest
from app import create_app
from app.extensions import db
from seed import seed


@pytest.fixture()
def app(tmp_path):
    database = tmp_path / "test.sqlite3"
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": f"sqlite:///{database}", "JWT_SECRET_KEY": "test-secret-key-that-is-long-enough-for-hs256", "SECRET_KEY": "test-secret-key-that-is-long-enough", "AI_API_KEY": ""})
    with app.app_context():
        seed()
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, email="demo@evolvo.local", password="Demo123!"):
    response = client.post("/api/auth/login", json={"email": email, "password": password})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.get_json()['accessToken']}"}


@pytest.fixture()
def auth(client):
    return login(client)


@pytest.fixture()
def admin_auth(client):
    return login(client, "admin@evolvo.local", "Admin123!")

