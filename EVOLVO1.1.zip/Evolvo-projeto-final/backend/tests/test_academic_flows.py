from datetime import date, timedelta

from app.models.entities import QuestionOption


def answers_for(app, assessment):
    with app.app_context():
        answers = []
        for question in assessment["questions"]:
            correct = QuestionOption.query.filter_by(question_id=question["id"], is_correct=True).first()
            answers.append({"questionId": question["id"], "optionId": correct.id})
        return answers


def complete(client, app, auth, create_path, finish_path, count=5):
    created = client.post(create_path, headers=auth, json={"questionCount": count})
    assert created.status_code == 201, created.get_json()
    assessment = created.get_json()
    response = client.post(finish_path.format(id=assessment["id"]), headers=auth, json={"answers": answers_for(app, assessment)})
    assert response.status_code == 200, response.get_json()
    return response.get_json()


def test_diagnostic_analysis_plan_and_task(client, app, auth):
    finished = complete(client, app, auth, "/api/diagnostics", "/api/diagnostics/{id}/finish", 8)
    assert finished["score"] == 100
    analysis = client.get(f"/api/diagnostics/{finished['id']}/analysis", headers=auth)
    assert analysis.status_code == 200
    assert analysis.get_json()["subjects"]
    plan_response = client.post("/api/study-plans/generate", headers=auth)
    assert plan_response.status_code == 201
    plan = plan_response.get_json()
    assert len(plan["tasks"]) >= 10
    assert any("ampliar as evidências" in task["reason"] for task in plan["tasks"])
    assert all("desempenho de 0%" not in task["reason"] for task in plan["tasks"])
    task_id = plan["tasks"][0]["id"]
    manual_completion = client.patch(f"/api/tasks/{task_id}", headers=auth, json={"status": "completed"})
    assert manual_completion.status_code == 409
    assert manual_completion.get_json()["error"] == "activity_required"

    created = client.post("/api/exercise-lists", headers=auth, json={"questionCount": 15, "taskId": task_id})
    assert created.status_code == 201, created.get_json()
    assessment = created.get_json()
    assert assessment["configuration"]["taskId"] == task_id
    in_progress = client.get("/api/study-plans", headers=auth).get_json()
    assert next(task for task in in_progress["tasks"] if task["id"] == task_id)["status"] == "in_progress"

    completed = client.post(
        f"/api/exercise-lists/{assessment['id']}/finish",
        headers=auth,
        json={"answers": answers_for(app, assessment)},
    )
    assert completed.status_code == 200, completed.get_json()
    updated_plan = client.get("/api/study-plans", headers=auth).get_json()
    assert next(task for task in updated_plan["tasks"] if task["id"] == task_id)["status"] == "completed"
    replanned = client.post("/api/study-plans/replan", headers=auth)
    assert replanned.status_code == 201
    assert replanned.get_json()["version"] == 2


def test_exercise_resolution_simulation_and_report(client, app, auth):
    exercise = complete(client, app, auth, "/api/exercise-lists", "/api/exercise-lists/{id}/finish", 5)
    resolution = client.get(f"/api/exercise-lists/{exercise['id']}/resolution", headers=auth)
    assert resolution.status_code == 200
    assert all(item["explanation"] for item in resolution.get_json()["questions"])
    simulation = complete(client, app, auth, "/api/simulations", "/api/simulations/{id}/finish", 10)
    assert simulation["personalized"] is True
    report = client.get("/api/reports/evolution", headers=auth)
    assert report.status_code == 200
    assert report.get_json()["totalAnswered"] == 15


def test_simulation_accepts_100_questions_and_persists_timing(client, app, auth):
    created = client.post("/api/simulations", headers=auth, json={"questionCount": 100})
    assert created.status_code == 201, created.get_json()
    assessment = created.get_json()
    assert len(assessment["questions"]) == 100
    question_times = {str(question["id"]): index + 10 for index, question in enumerate(assessment["questions"])}
    finished = client.post(
        f"/api/simulations/{assessment['id']}/finish",
        headers=auth,
        json={
            "answers": answers_for(app, assessment),
            "timing": {"totalSeconds": sum(question_times.values()), "questionSeconds": question_times},
        },
    )
    assert finished.status_code == 200, finished.get_json()
    timing = finished.get_json()["configuration"]["timing"]
    assert timing["totalSeconds"] == sum(question_times.values())
    assert len(timing["questionSeconds"]) == 100


def test_simulation_supports_official_day_blueprints(client, auth):
    day_one = client.post("/api/simulations", headers=auth, json={"blueprint": "day1", "questionCount": 30})
    assert day_one.status_code == 201, day_one.get_json()
    payload = day_one.get_json()
    assert len(payload["questions"]) == 90
    assert payload["configuration"]["blueprint"] == "day1"
    assert payload["configuration"]["includesEssay"] is False
    assert {item["subject"] for item in payload["questions"]}.issubset({"Língua Portuguesa", "Geografia", "História", "Sociologia"})


def test_essay_draft_analysis_and_submission_are_persisted(client, auth):
    prompts = client.get("/api/essay-prompts", headers=auth)
    assert prompts.status_code == 200
    prompt_id = prompts.get_json()[0]["id"]
    started = client.post("/api/essays", headers=auth, json={"promptId": prompt_id})
    assert started.status_code == 201
    submission_id = started.get_json()["id"]
    draft = "\n\n".join([
        "Em primeiro lugar, a sociedade brasileira precisa discutir o problema e suas causas históricas.",
        "Além disso, a escola pode promover formação crítica para que os estudantes reconheçam informações confiáveis.",
        "Contudo, o Estado também deve ampliar políticas públicas e fiscalizar ações que prejudiquem a cidadania.",
        "Portanto, o governo e a escola devem criar programas de formação, a fim de garantir participação social responsável. " * 8,
    ])
    saved = client.put(f"/api/essays/{submission_id}", headers=auth, json={"draftText": draft})
    assert saved.status_code == 200
    assert saved.get_json()["analysis"]["paragraphCount"] == 4
    assert saved.get_json()["characterCount"] >= 500
    assert saved.get_json()["wordCount"] >= 100
    submitted = client.post(f"/api/essays/{submission_id}/submit", headers=auth, json={"draftText": draft})
    assert submitted.status_code == 200
    assert submitted.get_json()["status"] == "submitted"
    assert "não substitui" in submitted.get_json()["analysis"]["disclaimer"]


def test_human_essay_correction_queue_and_feedback(client, auth, admin_auth):
    prompt_id = client.get("/api/essay-prompts", headers=auth).get_json()[0]["id"]
    submission_id = client.post("/api/essays", headers=auth, json={"promptId": prompt_id}).get_json()["id"]
    draft = "\n\n".join([
        "A sociedade brasileira enfrenta um desafio que exige análise responsável e participação coletiva.",
        "Em primeiro lugar, a escola deve promover debates e ampliar o acesso a informações confiáveis para que os jovens desenvolvam pensamento crítico.",
        "Além disso, o Estado precisa garantir políticas públicas permanentes e fiscalizar sua aplicação em todo o território nacional.",
        "Portanto, o governo e as instituições de ensino devem criar programas educativos, por meio de campanhas e formação continuada, a fim de reduzir o problema e fortalecer a cidadania. " * 4,
    ])
    submitted = client.post(f"/api/essays/{submission_id}/submit", headers=auth, json={"draftText": draft})
    assert submitted.status_code == 200

    requested = client.post(f"/api/essays/{submission_id}/corrections/human", headers=auth)
    assert requested.status_code == 201
    assert requested.get_json()["status"] == "queued"
    assert client.get("/api/reviewer/essay-corrections", headers=auth).status_code == 403

    queue = client.get("/api/reviewer/essay-corrections", headers=admin_auth)
    assert queue.status_code == 200
    item = next(row for row in queue.get_json() if row["submission"]["id"] == submission_id)
    payload = {
        "competencies": [
            {"code": f"C{index}", "score": 160, "feedback": f"Comentário pedagógico detalhado para a competência {index}."}
            for index in range(1, 6)
        ],
        "summary": "O texto apresenta uma estrutura consistente e pode aprofundar a relação entre repertório e tese.",
        "strengths": ["Estrutura dissertativo-argumentativa clara."],
        "priorities": ["Aprofundar a análise dos argumentos."],
    }
    completed = client.put(f"/api/reviewer/essay-corrections/{item['id']}", headers=admin_auth, json=payload)
    assert completed.status_code == 200
    assert completed.get_json()["feedback"]["totalScore"] == 800

    essays = client.get("/api/essays", headers=auth).get_json()
    correction = next(row for row in essays if row["id"] == submission_id)["corrections"][0]
    assert correction["status"] == "completed"
    assert correction["reviewerName"] == "Administrador Evolvo"


def test_teacher_partnership_activation_immediately_unlocks_essay_review(client, auth):
    subject_id = client.get("/api/goal", headers=auth).get_json()["exam"]["id"]
    subjects = client.get(f"/api/exams/{subject_id}/subjects", headers=auth).get_json()
    application = client.post("/api/teacher-partnership", headers=auth, json={
        "biography": "Professor com experiência em preparação para vestibulares e acompanhamento individual de estudantes.",
        "hourlyPrice": 80,
        "modality": "online",
        "city": "São Paulo",
        "contact": "professor@exemplo.com",
        "subjectIds": [subjects[0]["id"]],
    })
    assert application.status_code == 201, application.get_json()
    assert application.get_json()["status"] == "approved"
    assert application.get_json()["accessToken"]
    teacher_auth = {"Authorization": f"Bearer {application.get_json()['accessToken']}"}
    assert client.get("/api/reviewer/essay-corrections", headers=teacher_auth).status_code == 200


def test_student_contact_reaches_only_the_selected_teacher(client, auth):
    registered = client.post("/api/auth/register", json={
        "name": "Professora Parceira",
        "email": "professora-parceira@example.com",
        "password": "Segura123!",
        "acceptTerms": True,
    })
    teacher_headers = {"Authorization": f"Bearer {registered.get_json()['accessToken']}"}
    exam_id = client.get("/api/goal", headers=auth).get_json()["exam"]["id"]
    subject = client.get(f"/api/exams/{exam_id}/subjects", headers=auth).get_json()[0]
    partnership = client.post("/api/teacher-partnership", headers=teacher_headers, json={
        "biography": "Professora com experiência em acompanhamento individual, revisão e preparação para vestibulares.",
        "hourlyPrice": 75,
        "modality": "online",
        "city": "São Paulo",
        "contact": "professora-parceira@example.com",
        "subjectIds": [subject["id"]],
    })
    assert partnership.status_code == 201, partnership.get_json()
    teacher_headers = {"Authorization": f"Bearer {partnership.get_json()['accessToken']}"}
    teacher = next(row for row in client.get("/api/teachers", headers=auth).get_json() if row["name"] == "Professora Parceira")

    sent = client.post(f"/api/teachers/{teacher['id']}/contact-requests", headers=auth, json={
        "subjectId": subject["id"],
        "message": "Gostaria de reforço nesta matéria e prefiro conversar sobre aulas online.",
    })
    assert sent.status_code == 201, sent.get_json()
    assert sent.get_json()["status"] == "new"

    received = client.get("/api/teacher-area/contact-requests", headers=teacher_headers)
    assert received.status_code == 200, received.get_json()
    request_item = received.get_json()[0]
    assert request_item["student"]["email"] == "demo@evolvo.local"
    assert request_item["subject"]["id"] == subject["id"]
    updated = client.patch(
        f"/api/teacher-area/contact-requests/{request_item['id']}",
        headers=teacher_headers,
        json={"status": "contacted"},
    )
    assert updated.status_code == 200
    assert updated.get_json()["status"] == "contacted"


def test_ai_essay_correction_fails_transparently_without_key(client, auth):
    prompt_id = client.get("/api/essay-prompts", headers=auth).get_json()[0]["id"]
    submission_id = client.post("/api/essays", headers=auth, json={"promptId": prompt_id}).get_json()["id"]
    draft = "Portanto, o governo deve promover educação para que a sociedade enfrente o problema. " * 25
    assert client.post(f"/api/essays/{submission_id}/submit", headers=auth, json={"draftText": draft}).status_code == 200
    response = client.post(f"/api/essays/{submission_id}/corrections/ai", headers=auth)
    assert response.status_code == 503
    assert response.get_json()["error"] == "ai_not_configured"


def test_performance_refresh_and_recommendation(client, app, auth):
    complete(client, app, auth, "/api/diagnostics", "/api/diagnostics/{id}/finish", 5)
    assert client.post("/api/performance/refresh", headers=auth).status_code == 200
    assert client.post("/api/study-plans/generate", headers=auth).status_code == 201
    recommendation = client.get("/api/recommendations/next", headers=auth)
    assert recommendation.status_code == 200
    assert recommendation.get_json()["reason"]


def test_assessment_filters_stay_inside_active_exam_and_subjects(client, auth):
    goal = client.get("/api/goal", headers=auth).get_json()
    exam_id = goal["exam"]["id"]
    subjects = client.get(f"/api/exams/{exam_id}/subjects", headers=auth).get_json()
    mathematics = next(item for item in subjects if item["name"] == "Matemática")

    focused = client.post("/api/diagnostics", headers=auth, json={
        "questionCount": 5,
        "subjectIds": [mathematics["id"]],
        "examId": 9999,
    })
    assert focused.status_code == 201, focused.get_json()
    payload = focused.get_json()
    assert payload["exam"]["id"] == exam_id
    assert {question["subject"] for question in payload["questions"]} == {"Matemática"}


def test_assessment_rejects_subject_from_another_exam(client, auth):
    response = client.post("/api/exercise-lists", headers=auth, json={"questionCount": 5, "subjectIds": [9999]})
    assert response.status_code == 422
    assert response.get_json()["error"] == "invalid_subjects"


def test_each_enem_subject_has_capacity_for_fifty_questions(client, auth):
    goal = client.get("/api/goal", headers=auth).get_json()
    subjects = client.get(f"/api/exams/{goal['exam']['id']}/subjects", headers=auth).get_json()
    assert {item["name"] for item in subjects} == {
        "Artes", "Biologia", "Educação Física", "Filosofia", "Física", "Geografia", "História",
        "Literatura", "Língua Espanhola", "Língua Inglesa", "Língua Portuguesa", "Matemática", "Química", "Sociologia"
    }
    available = [item for item in subjects if item["approvedQuestionCount"]]
    assert all(item["approvedQuestionCount"] >= 50 for item in available)
    assert all(item["topics"] for item in subjects)


def test_diagnostic_all_subjects_is_balanced(client, auth):
    response = client.post("/api/diagnostics", headers=auth, json={"questionCount": 8, "subjectIds": []})
    assert response.status_code == 201, response.get_json()
    counts = {}
    for question in response.get_json()["questions"]:
        counts[question["subject"]] = counts.get(question["subject"], 0) + 1
    assert len(counts) == 7
    assert max(counts.values()) - min(counts.values()) <= 1


def test_plan_requires_completed_diagnostic(client):
    registered = client.post("/api/auth/register", json={
        "name": "Sem Diagnóstico",
        "email": "sem-diagnostico@example.com",
        "password": "Segura123!",
        "acceptTerms": True,
    }).get_json()
    headers = {"Authorization": f"Bearer {registered['accessToken']}"}
    exam = next(item for item in client.get("/api/exams").get_json() if item["supportStatus"] == "full")
    configured = client.put("/api/goal", headers=headers, json={
        "examId": exam["id"],
        "examDate": (date.today() + timedelta(days=180)).isoformat(),
        "dailyMinutes": 60,
        "studyDays": [0, 1, 2, 3, 4],
    })
    assert configured.status_code == 201

    response = client.post("/api/study-plans/generate", headers=headers)
    assert response.status_code == 409
    assert response.get_json()["error"] == "diagnostic_required"


def test_new_account_starts_without_invented_history(client):
    registered = client.post("/api/auth/register", json={
        "name": "Conta Nova",
        "email": "conta-nova@example.com",
        "password": "Segura123!",
        "acceptTerms": True,
    })
    assert registered.status_code == 201
    headers = {"Authorization": f"Bearer {registered.get_json()['accessToken']}"}
    dashboard = client.get("/api/dashboard", headers=headers).get_json()
    assert dashboard["goal"] is None
    assert dashboard["todayTasks"] == []
    assert dashboard["recent"] == []
    assert dashboard["metrics"]["answered"] == 0
    assert dashboard["metrics"]["planProgress"] == 0


def test_goal_change_archives_previous_plan(client, app, auth):
    complete(client, app, auth, "/api/diagnostics", "/api/diagnostics/{id}/finish", 5)
    generated = client.post("/api/study-plans/generate", headers=auth)
    assert generated.status_code == 201

    goal = client.get("/api/goal", headers=auth).get_json()
    changed = client.put("/api/goal", headers=auth, json={
        "examId": goal["exam"]["id"],
        "examDate": (date.today() + timedelta(days=240)).isoformat(),
        "dailyMinutes": 90,
        "studyDays": [0, 2, 4],
    })
    assert changed.status_code == 201
    assert client.get("/api/study-plans", headers=auth).get_json() is None
    dashboard = client.get("/api/dashboard", headers=auth).get_json()
    assert dashboard["metrics"]["planProgress"] == 0
    assert dashboard["todayTasks"] == []
    assert client.post("/api/study-plans/replan", headers=auth).status_code == 409

