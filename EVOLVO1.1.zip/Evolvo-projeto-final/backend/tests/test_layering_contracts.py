"""Guardas arquiteturais para impedir regressões na separação em camadas."""

import ast
from pathlib import Path


CONTROLLERS = Path(__file__).parents[1] / "app" / "controllers"


def test_controllers_do_not_access_persistence_directly():
    forbidden_modules = {"extensions", "models", "repositories"}
    violations = []

    for path in sorted(CONTROLLERS.glob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                parts = set((node.module or "").split("."))
                if parts & forbidden_modules:
                    violations.append(f"{path.name}:{node.lineno} importa {node.module}")
            if isinstance(node, ast.Attribute) and node.attr == "query":
                violations.append(f"{path.name}:{node.lineno} usa consulta direta")
            if (
                isinstance(node, ast.Attribute)
                and node.attr == "session"
                and isinstance(node.value, ast.Name)
                and node.value.id == "db"
            ):
                violations.append(f"{path.name}:{node.lineno} usa db.session")

    assert not violations, "Controllers devem delegar persistência a Services/Repositories: " + "; ".join(violations)


def test_each_api_operation_is_bound_to_a_controller_class():
    route_file = Path(__file__).parents[1] / "app" / "routes" / "api.py"
    tree = ast.parse(route_file.read_text(encoding="utf-8"), filename=str(route_file))
    violations = []

    for call in (node for node in ast.walk(tree) if isinstance(node, ast.Call)):
        if not (isinstance(call.func, ast.Attribute) and call.func.attr == "add_url_rule"):
            continue
        path_arg = call.args[0].value if call.args and isinstance(call.args[0], ast.Constant) else "rota"
        view_keyword = next((item for item in call.keywords if item.arg == "view_func"), None)
        if not view_keyword or path_arg == "/health":
            continue
        source = ast.unparse(view_keyword.value)
        if "Controller." not in source:
            violations.append(f"{path_arg}: {source}")

    assert not violations, "Rotas de negócio sem Controller de classe: " + "; ".join(violations)
