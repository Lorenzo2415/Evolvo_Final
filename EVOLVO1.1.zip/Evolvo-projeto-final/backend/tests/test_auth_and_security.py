from .conftest import login


def test_health_and_exam_catalog(client):
    assert client.get("/api/health").get_json()["status"] == "ok"
    exams = client.get("/api/exams").get_json()
    assert exams[0]["slug"] == "enem"
    assert any(item["supportStatus"] == "limited" for item in exams)


def test_limited_exam_cannot_become_active_goal(client, auth):
    exams = client.get("/api/exams").get_json()
    limited = next(item for item in exams if item["supportStatus"] == "limited")
    response = client.put("/api/goal", headers=auth, json={
        "examId": limited["id"],
        "examDate": "2030-11-01",
        "dailyMinutes": 60,
        "studyDays": [0,1,2,3,4],
    })
    assert response.status_code == 409
    assert response.get_json()["error"] == "exam_not_supported"


def test_register_login_and_unique_email(client):
    payload = {"name": "Ana Teste", "email": "ana@example.com", "password": "Segura123!", "acceptTerms": True}
    response = client.post("/api/auth/register", json=payload)
    assert response.status_code == 201
    assert response.get_json()["user"]["email"] == "ana@example.com"
    assert response.get_json()["user"]["onboardingComplete"] is False
    headers = {"Authorization": f"Bearer {response.get_json()['accessToken']}"}
    for consent_type in ("terms", "privacy_notice", "academic_processing", "age_responsibility"):
        consent = client.post("/api/consents", headers=headers, json={"type": consent_type, "version": "2.1", "accepted": True})
        assert consent.status_code == 200
    assert client.get("/api/consents", headers=headers).get_json()["complete"] is True
    assert client.get("/api/auth/me", headers=headers).get_json()["onboardingComplete"] is True
    assert client.post("/api/auth/register", json=payload).status_code == 409
    assert client.post("/api/auth/login", json={"email": payload["email"], "password": "errada"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": payload["email"], "password": payload["password"]}).status_code == 200


def test_student_cannot_access_admin(client, auth):
    assert client.get("/api/admin/questions", headers=auth).status_code == 403


def test_admin_can_review_question(client, admin_auth):
    items = client.get("/api/admin/questions", headers=admin_auth).get_json()
    question_id = items["items"][0]["id"]
    response = client.patch(f"/api/admin/questions/{question_id}/review", headers=admin_auth, json={"status": "draft"})
    assert response.status_code == 200
    assert response.get_json()["status"] == "draft"


def test_user_data_isolated(client, app, auth):
    second = client.post("/api/auth/register", json={"name":"Outro Aluno","email":"outro@example.com","password":"Segura123!","acceptTerms":True})
    other = {"Authorization": f"Bearer {second.get_json()['accessToken']}"}
    diagnostic = client.post("/api/diagnostics", headers=auth, json={"questionCount": 5}).get_json()
    assert client.get(f"/api/diagnostics/{diagnostic['id']}/analysis", headers=other).status_code in {404,409}

