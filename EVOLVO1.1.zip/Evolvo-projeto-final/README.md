# Evolvo 2.0

> Descubra onde melhorar. Treine com direção.

O Evolvo é uma plataforma de **apoio adaptativo** para quem já estuda para o ENEM em escola, cursinho, com professores ou por conta própria. A partir de respostas reais, ele identifica lacunas, recomenda treinos e revisões e mostra a evolução do estudante. O produto complementa o ensino; não pretende substituir aulas, materiais didáticos ou orientação docente.

Este repositório contém duas aplicações separadas: uma API Flask e uma SPA React.

O suporte funcional completo nesta entrega é do **ENEM**. A FUVEST aparece somente como item de catálogo com suporte limitado, sem questões genéricas apresentadas como equivalentes ao exame.

## Público e problema

O produto atende estudantes do ensino médio e candidatos ao ENEM que já têm acesso a conteúdo, mas precisam descobrir quais pontos fracos merecem mais treino, em qual ordem e por quê. O motor de personalização funciona sem IA generativa e considera lacuna, importância curricular, evidência acumulada, urgência e revisão.

## Tecnologias

- Frontend: React 19, TypeScript, Vite, Tailwind CSS, TanStack Query, React Router, Recharts e Lucide.
- Backend: Python, Flask, Flask-SQLAlchemy, Flask-Migrate, Flask-JWT-Extended e pytest.
- Banco: PostgreSQL em produção; SQLite no desenvolvimento e nos testes.
- IA: cliente HTTP substituível, configurado somente no backend.

## Arquitetura

O frontend roda em `localhost:5173` e consome a API HTTP em `localhost:5000/api`. O backend segue o fluxo:

```text
Route → Controller (classe) → Service (caso de uso) → Model/Repository → Banco
```

Controllers interpretam HTTP. Services concentram validação e regra de negócio. Models representam o domínio. Repositories contêm seleção especializada e SQL parametrizado para desempenho por disciplina, tópicos com maior erro, evolução por período e histórico recente.

## Endpoints principais

Todos os endpoints privados recebem `Authorization: Bearer <token>`.

| Recurso | Endpoints |
|---|---|
| Conta | `POST /api/auth/register`, `POST /api/auth/login`, `GET/PUT /api/auth/me` |
| Consentimentos | `GET/POST /api/consents` com decisões versionadas e persistidas por usuário |
| Objetivo e preferências | `GET/PUT /api/goal`, `GET/PUT /api/preferences/subjects` |
| Questões e exercícios | `GET /api/questions`, `POST /api/exercise-lists`, `POST /api/exercise-lists/:id/finish`, `GET /api/exercise-lists/:id/resolution` |
| Simulados | `POST /api/simulations` com formatos personalizado, Dia 1, Dia 2 ou 180 questões; `POST /api/simulations/:id/finish`, `GET /api/simulations/history` |
| Redação | `GET /api/essay-prompts`, `GET/POST /api/essays`, `PUT /api/essays/:id`, `POST /api/essays/:id/submit`, correções em `/api/essays/:id/corrections/{ai,human}` |
| Equipe de correção | `GET /api/reviewer/essay-corrections`, `PUT /api/reviewer/essay-corrections/:id` para perfis `admin`, `reviewer` ou `teacher` |
| Desempenho | `GET /api/reports/evolution`, `GET /api/recommendations/next` |
| Professores | `GET /api/teachers`, `GET /api/teachers/:id`, `POST/DELETE /api/teachers/:id/reviews`, `POST /api/teachers/:id/contact-requests` |
| Área do professor | `GET /api/teacher-area/contact-requests`, `PATCH /api/teacher-area/contact-requests/:id` |
| Parceria docente | `GET/POST /api/teacher-partnership`; análise administrativa em `GET/PATCH /api/admin/teacher-partnerships` |

## Estrutura

```text
evolvo/
├── backend/
│   ├── app/{controllers,integrations,models,repositories,routes,services,utils}
│   ├── migrations/
│   ├── tests/
│   ├── seed.py
│   └── run.py
├── frontend/src/{components,contexts,layouts,pages,services,styles,types}
├── docs/
│   ├── diagrams/class-diagram.md
│   └── flowcharts/{teacher-search,teacher-review}.md
├── .env.example
└── README.md
```

## Instalação local

### Inicialização simplificada no VS Code (Windows)

Abra a pasta `Evolvo-projeto-final` no VS Code, abra o arquivo
`iniciar_evolvo.py` localizado na raiz e clique em **Run Python File** (a
setinha no canto superior direito). O inicializador cria o ambiente virtual,
instala dependências quando necessário, aplica as migrations, inicia backend e
frontend e abre `http://localhost:5173` automaticamente.

Na primeira execução é necessário ter Python e Node.js LTS instalados e a
preparação pode levar alguns minutos. Nas execuções seguintes a abertura é
direta. Mantenha a execução aberta enquanto estiver usando o Evolvo e pressione
`Ctrl+C` para encerrar os dois servidores.

### Backend

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
flask --app run.py db upgrade
python demo_flow.py  # opcional: cria histórico para a apresentação
python run.py
```

Esta entrega já inclui `backend/instance/evolvo.sqlite3`, pronto para uso com o catálogo completo e as contas demonstrativas. O `seed.py` existe apenas para recriar um banco do zero e adiciona 390 questões autorais; não o execute sobre o banco entregue se quiser preservar os 3.006 itens. Para acrescentar questões ausentes sem apagar usuários ou históricos, execute `python sync_question_bank.py`. O sincronizador idempotente `python sync_enem_api.py` importa questões oficiais de 2009–2023 da API ENEM, incluindo imagens, gráficos e anexos de alternativas, mantendo ano, identificador, fonte e licença. Depois da importação, `python sync_enem_taxonomy.py` garante as 14 matérias e 130 submatérias e reclassifica o acervo por conteúdo, sem usar o ano da prova como assunto. Execute `python sync_essay_prompts.py` para acrescentar propostas de redação sem apagar rascunhos. A variável `ENEM_IMPORT_YEARS=2022,2023` limita os anos. Conta de demonstração: `demo@evolvo.local` / `Demo123!`. Administração: `admin@evolvo.local` / `Admin123!`. Troque essas senhas fora do ambiente local.

Após atualizar uma instalação existente, execute `flask --app run.py db upgrade` e `python sync_demo_catalog.py`. O segundo comando é idempotente e adiciona somente os professores fictícios ausentes, sem apagar usuários ou históricos.

### Frontend

```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```

Abra `http://localhost:5173`.

## Banco e migrations

Defina `DATABASE_URL=postgresql+psycopg://usuario:senha@host:5432/evolvo` em produção. Para criar uma alteração:

```powershell
flask --app run.py db migrate -m "descrição"
flask --app run.py db upgrade
```

As entidades principais incluem conta e consentimento, prova e matriz acadêmica, questões, atividades, desempenho, plano, redação e professores. O diagrama completo e conferido está em [`docs/diagrams/class-diagram.md`](docs/diagrams/class-diagram.md). `Assessment.kind` diferencia diagnóstico, lista, revisão e simulado sem duplicar estruturas equivalentes. `Assessment.configuration` preserva quantidade, matérias, estratégia e tempo usados na seleção para que uma atividade possa ser retomada de forma coerente.

## Personalização

A pontuação de prioridade varia de 0 a 100:

```text
prioridade = 0,45 × lacuna
           + 0,25 × importância
           + 0,15 × baixa evidência
           + 0,10 × urgência
           + 0,05 × revisão vencida
```

O domínio cresce conforme acertos consistentes e quantidade de evidências. Uma única resposta nunca marca o assunto como dominado. A revisão espaçada começa em um dia, aumenta com domínio consistente e retorna a um dia após dificuldade.

## Testes e build

```powershell
cd backend
.\.venv\Scripts\python.exe -m pytest

cd ..\frontend
npm run typecheck
npm run build
```

Resultado verificado em 23/10/2026: **34 testes de backend aprovados**, TypeScript aprovado, **build de produção do frontend concluído** e auditoria npm de produção sem vulnerabilidades conhecidas. A suíte cobre 25 fluxos funcionais, isolamento de contas, filtros combinados, CRUD de avaliações, contato voluntário entre estudante e professor, autorização, simulado de 100 questões, redação, ativação docente imediata, persistência de histórico e contratos arquiteturais que proíbem acesso direto ao banco nos Controllers. As rotas do frontend usam carregamento sob demanda para reduzir o pacote inicial.

Também foram verificados: migration inicial aplicada em banco vazio, breakpoints desktop e móvel no navegador e auditoria das dependências de produção do frontend sem vulnerabilidades conhecidas.

## Dados de demonstração

- 390 questões autorais no seed e sincronização adicional de questões oficiais do ENEM; o banco local validado contém 3.006 itens aprovados, incluindo 1.016 com imagens ou gráficos, todos com origem, gabarito e rastreabilidade.
- 16 disciplinas/áreas e 196 assuntos cadastrados; as 14 disciplinas do ENEM têm taxonomia própria, e as áreas agregadoras são usadas somente para organização.
- ENEM com perfil, estrutura, características e suporte completo para os fluxos demonstrativos.
- FUVEST visível como suporte limitado, sem conteúdo inadequado reutilizado.
- Quatro professores fictícios identificados como dados de demonstração, com matérias, modalidade e preço.
- Nenhum dado pessoal real e nenhuma questão identificada falsamente como oficial.

## Integração de IA

Defina `AI_API_KEY`, `AI_PROVIDER_URL` e `AI_MODEL` no backend. O `AIProviderClient` usa timeout de 60 segundos, não expõe a chave ao frontend e atende a estimativa de redação pelas cinco competências. Sem credencial, com credencial inválida ou sem créditos, a correção por IA devolve um erro 503 específico e amigável, sem inventar uma nota; diagnóstico, plano, exercícios, correção humana e desempenho continuam funcionando.

Na redação, o estudante escolhe explicitamente um tema ou uma redação salva antes de abrir o editor, acompanha o mínimo de 500 caracteres e pode solicitar uma estimativa por IA e uma correção humana para o mesmo texto. Pedidos humanos entram numa fila persistida, visível a perfis `admin`, `reviewer` ou professores parceiros ativos; a devolutiva registra notas válidas de 0 a 200 por competência, total, comentários e prioridades de reescrita. As duas modalidades deixam explícito que o resultado não é uma nota oficial do Inep.

Questões geradas por IA entram obrigatoriamente com `status=draft`. A área administrativa exige papel `admin`, identifica a origem, detecta duplicidade por hash e oferece cadastro, edição, importação em lote, geração assistida, aprovação e rejeição. A geração usa `POST /admin/questions/generate-draft`, incorpora nome, banca e características do `ExamProfile` ao contexto e nunca publica automaticamente.

## Experiência de estudo

- Diagnóstico e exercícios permitem escolher 15, 20, 30 ou 50 questões.
- O aluno pode selecionar uma, várias ou **Todas as matérias e áreas** do exame ativo.
- Diagnósticos usam distribuição balanceada; exercícios priorizam dificuldades dentro do recorte escolhido.
- O simulado permite 30, 50 ou 100 questões e possui cronômetro total, mapa de questões, marcação para revisão, correção somente após a entrega e médias de tempo geral e por matéria.
- Plano e rotina têm experiências distintas: o plano é o mapa cronológico completo; a rotina mostra o recorte do dia. Uma sessão do plano só é concluída automaticamente depois que sua atividade vinculada é entregue.
- Cadastro e login identificam explicitamente uma sessão demonstrativa existente. Contas novas começam sem objetivo, resultados ou plano pré-preenchidos e permanecem isoladas no banco SQL.
- Depois do cadastro, a conta passa por uma etapa obrigatória e acessível de Termos de Uso, Aviso de Privacidade, tratamento acadêmico necessário e confirmação de idade/responsável. Cada aceite da versão 2.1 fica registrado separadamente no SQLite antes da entrada no aplicativo. O documento cobre controlador, categorias de dados, finalidade, compartilhamento, segurança, retenção, direitos, menores e regras de uso, e identifica os campos que precisam de preenchimento e revisão jurídica antes de operação comercial.
- Configurações incluem temas claro, escuro e sistema, tamanho de texto, redução de movimento, padrões de atividade, privacidade e conta.
- Meu perfil permite alterar nome/e-mail e persistir matérias prioritárias usadas no plano.
- Banco de questões combina matéria e dificuldade sem expor o gabarito antes da resolução.
- Professores oferece busca, filtros simultâneos, ordenação, perfil completo, avaliação editável e solicitação privada de contato pelo estudante.
- Usuários podem ativar imediatamente um perfil de professor, publicá-lo na rede e acessar uma área própria com alunos interessados e correções de redação, sem fila administrativa nesta versão acadêmica.

## Funcionalidades Implementadas

Foram validados **25 fluxos completos**; a lista abaixo destaca os 20 exigidos, sem contar tela, rota ou etapa isolada como funcionalidade.

1. Cadastrar estudante.
2. Autenticar estudante.
3. Atualizar perfil.
4. Definir objetivo educacional.
5. Personalizar matérias de estudo.
6. Realizar diagnóstico configurável e obter análise de dificuldades.
7. Gerar plano adaptativo após o diagnóstico.
8. Consultar rotina diária personalizada e replanejar sessões pendentes.
9. Pesquisar o banco de questões com filtros combinados.
10. Resolver e corrigir uma lista de exercícios com explicações.
11. Gerar revisão orientada pelos assuntos escolhidos.
12. Realizar simulado configurável com cronômetro e marcação.
13. Consultar o histórico persistido de simulados.
14. Analisar desempenho e evolução por matéria.
15. Obter recomendação da próxima prioridade de estudo.
16. Pesquisar e filtrar professores com critérios combinados.
17. Consultar perfil completo de professor.
18. Criar, editar e excluir a própria avaliação de professor.
19. Escrever, salvar e enviar uma redação.
20. Solicitar e receber correção humana de redação.

Outros fluxos validados: consentimentos de privacidade; correção por IA com falha segura sem credencial; moderação/importação de questões por administrador; e solicitação de contato que chega somente ao professor escolhido, com acompanhamento de situação.

Também foi validado o fluxo completo de parceria docente: cadastro profissional, ativação imediata da permissão, publicação do perfil e acesso direto à fila de redações.

## Diagramas e fluxos

- [Diagrama de classes](docs/diagrams/class-diagram.md)
- [Pesquisa de professores — recuperação](docs/flowcharts/teacher-search.md)
- [Avaliação de professor — entrada](docs/flowcharts/teacher-review.md)

## Limites conhecidos

- O banco combina questões autorais com questões oficiais importadas da API ENEM e renderiza anexos visuais no catálogo, diagnóstico, prática livre, modo simulado e correção.
- Concursos diferentes não são misturados ao ENEM. Novas bancas exigem cadastro próprio da prova e uma fonte autorizada ou credenciada, preservando a fidelidade acadêmica.
- A correção de redação por IA somente responde quando `AI_API_KEY` é válida.
- O catálogo de professores não possui pagamentos, agenda ou verificação documental. O contato não é público: o estudante compartilha voluntariamente nome, e-mail e mensagem apenas com o professor escolhido.

