const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

export class ApiError extends Error { status:number; constructor(message:string,status:number){ super(message); this.status=status } }

export async function api<T>(path:string, options:RequestInit = {}):Promise<T>{
  const token = localStorage.getItem('evolvo_token')
  let response:Response
  try {
    response = await fetch(`${API_URL}${path}`, { ...options, headers: { 'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`} : {}), ...options.headers } })
  } catch {
    throw new ApiError('Não foi possível conectar ao servidor do Evolvo. Confirme se a API Flask está em execução e tente novamente.', 0)
  }
  const payload = await response.json().catch(()=>({message:'Resposta inválida do servidor.'}))
  if(!response.ok) throw new ApiError(payload.message || 'Não foi possível concluir a operação.', response.status)
  return payload as T
}

