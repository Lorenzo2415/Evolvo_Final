import {
  createContext,
  useCallback,
  useContext,
  useLayoutEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

export type ThemePreference = 'light' | 'dark' | 'system'
export type FontSizePreference = 'small' | 'medium' | 'large'

export type Preferences = {
  theme: ThemePreference
  fontSize: FontSizePreference
  reducedMotion: boolean
  defaultQuestionCount: number
  showQuestionSource: boolean
}

type PreferencesValue = {
  preferences: Preferences
  resolvedTheme: 'light' | 'dark'
  updatePreferences: (patch: Partial<Preferences>) => void
  resetPreferences: () => void
}

const STORAGE_KEY = 'evolvo_preferences_v1'

export const defaultPreferences: Preferences = {
  theme: 'system',
  fontSize: 'medium',
  reducedMotion: false,
  defaultQuestionCount: 20,
  showQuestionSource: true,
}

const PreferencesContext = createContext<PreferencesValue | null>(null)

function readPreferences(): Preferences {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') as Partial<Preferences>
    const theme = ['light', 'dark', 'system'].includes(String(stored.theme))
      ? stored.theme as ThemePreference
      : defaultPreferences.theme
    const fontSize = ['small', 'medium', 'large'].includes(String(stored.fontSize))
      ? stored.fontSize as FontSizePreference
      : defaultPreferences.fontSize
    const questionCount = Number(stored.defaultQuestionCount)

    return {
      theme,
      fontSize,
      reducedMotion: typeof stored.reducedMotion === 'boolean' ? stored.reducedMotion : defaultPreferences.reducedMotion,
      defaultQuestionCount: [15, 20, 30, 50].includes(questionCount) ? questionCount : defaultPreferences.defaultQuestionCount,
      showQuestionSource: typeof stored.showQuestionSource === 'boolean' ? stored.showQuestionSource : defaultPreferences.showQuestionSource,
    }
  } catch {
    return defaultPreferences
  }
}

function systemTheme(): 'light' | 'dark' {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences>(readPreferences)
  const [systemPreference, setSystemPreference] = useState<'light' | 'dark'>(systemTheme)
  const resolvedTheme = preferences.theme === 'system' ? systemPreference : preferences.theme

  useLayoutEffect(() => {
    const query = window.matchMedia('(prefers-color-scheme: dark)')
    const onChange = (event: MediaQueryListEvent) => setSystemPreference(event.matches ? 'dark' : 'light')
    query.addEventListener('change', onChange)
    return () => query.removeEventListener('change', onChange)
  }, [])

  useLayoutEffect(() => {
    const root = document.documentElement
    root.classList.toggle('dark', resolvedTheme === 'dark')
    root.classList.toggle('light', resolvedTheme === 'light')
    root.classList.toggle('reduce-motion', preferences.reducedMotion)
    root.dataset.theme = resolvedTheme
    root.dataset.fontSize = preferences.fontSize
    root.style.colorScheme = resolvedTheme
  }, [preferences.fontSize, preferences.reducedMotion, resolvedTheme])

  const updatePreferences = useCallback((patch: Partial<Preferences>) => {
    setPreferences(current => {
      const next = { ...current, ...patch }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
      return next
    })
  }, [])

  const resetPreferences = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY)
    setPreferences(defaultPreferences)
  }, [])

  const value = useMemo(() => ({
    preferences,
    resolvedTheme,
    updatePreferences,
    resetPreferences,
  }), [preferences, resetPreferences, resolvedTheme, updatePreferences])

  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>
}

export function usePreferences() {
  const context = useContext(PreferencesContext)
  if (!context) throw new Error('PreferencesProvider ausente')
  return context
}
