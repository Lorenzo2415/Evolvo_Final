import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { api, ApiError } from '../services/api'

type User = { id:number; name:string; email:string; role:string; onboardingComplete:boolean }
type AuthValue = {
  user:User|null
  loading:boolean
  connectionError:string|null
  retrySession:()=>Promise<void>
  login:(email:string,password:string)=>Promise<void>
  register:(name:string,email:string,password:string)=>Promise<void>
  completeOnboarding:()=>Promise<void>
  logout:()=>void
}

const AuthContext = createContext<AuthValue|null>(null)

export function AuthProvider({children}:{children:ReactNode}) {
  const [user,setUser] = useState<User|null>(null)
  const [loading,setLoading] = useState(true)
  const [connectionError,setConnectionError] = useState<string|null>(null)

  async function loadSession() {
    const token = localStorage.getItem('evolvo_token')
    if (!token) {
      setUser(null)
      setConnectionError(null)
      setLoading(false)
      return
    }

    setLoading(true)
    setConnectionError(null)
    try {
      setUser(await api<User>('/auth/me'))
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        localStorage.removeItem('evolvo_token')
        setUser(null)
      } else {
        setConnectionError(error instanceof Error ? error.message : 'O servidor do Evolvo não respondeu.')
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { void loadSession() }, [])

  async function authenticate(path:string,body:object) {
    const data = await api<{user:User;accessToken:string}>(path,{method:'POST',body:JSON.stringify(body)})
    localStorage.setItem('evolvo_token',data.accessToken)
    setConnectionError(null)
    setUser(data.user)
  }

  function logout() {
    localStorage.removeItem('evolvo_token')
    setConnectionError(null)
    setUser(null)
  }

  async function completeOnboarding(){
    for(const type of ['terms','privacy_notice','academic_processing','age_responsibility']){
      await api('/consents',{method:'POST',body:JSON.stringify({type,version:'2.1',accepted:true})})
    }
    await loadSession()
  }

  return <AuthContext.Provider value={{
    user,
    loading,
    connectionError,
    retrySession:loadSession,
    login:(email,password)=>authenticate('/auth/login',{email,password}),
    register:(name,email,password)=>authenticate('/auth/register',{name,email,password}),
    completeOnboarding,
    logout,
  }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('AuthProvider ausente')
  return ctx
}
