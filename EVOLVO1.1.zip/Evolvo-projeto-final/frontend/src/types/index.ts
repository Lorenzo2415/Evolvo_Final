export type Exam = { id:number; slug:string; name:string; type:string; institution:string; supportStatus:'full'|'limited'; profile?:{questionCount:number; durationMinutes:number; characteristics:string[]} }
export type Subject = { id:number; name:string; area:string; approvedQuestionCount:number; topics:{id:number;name:string;importance:number}[] }
export type Option = { id:number; position:number; text:string }
export type QuestionMedia = {statement:string[];options:Record<string,string[]>}
export type Question = { id:number; statement:string; difficulty:string; format:string; subject:string; topic:string; media?:QuestionMedia; options:Option[]; selectedOptionId?:number; isCorrect?:boolean|null; correctOptionId?:number; explanation?:string; source:{type:string;label:string} }
export type Assessment = { id:number; kind:string; title:string; status:string; personalized:boolean; exam?:{id:number}; configuration?:{requestedQuestionCount:number;subjectIds:number[];allSubjects:boolean;selectionStrategy:string;difficulty?:string;taskId?:number;timing?:{totalSeconds:number;questionSeconds:Record<string,number>}}; score?:number; correctAnswers:number; totalQuestions:number; startedAt?:string; completedAt?:string; questions:Question[] }
export type Task = { id:number; title:string; topicId:number; topic:string; subjectId:number; subject:string; scheduledDate:string; activityType:string; durationMinutes:number; priorityScore:number; reason:string; status:string }

