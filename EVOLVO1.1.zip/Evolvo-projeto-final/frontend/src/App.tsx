import { lazy, Suspense, type ReactNode } from 'react'
import { Navigate, Route, Routes, useSearchParams } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext'
import AppLayout from './layouts/AppLayout'
import { ErrorState, Loading } from './components/ui'

const Landing = lazy(()=>import('./pages/Landing'))
const Auth = lazy(()=>import('./pages/Auth'))
const Dashboard = lazy(()=>import('./pages/Dashboard'))
const GoalPage = lazy(()=>import('./pages/GoalPage'))
const AssessmentPage = lazy(()=>import('./pages/AssessmentPage'))
const PlanPage = lazy(()=>import('./pages/PlanPage'))
const PerformancePage = lazy(()=>import('./pages/PerformancePage'))
const SettingsPage = lazy(()=>import('./pages/SettingsPage'))
const AdminQuestionsPage = lazy(()=>import('./pages/AdminQuestionsPage'))
const QuestionsPage = lazy(()=>import('./pages/QuestionsPage'))
const SimulationHistoryPage = lazy(()=>import('./pages/SimulationHistoryPage'))
const TeachersPage = lazy(()=>import('./pages/TeachersPage'))
const EssayPage = lazy(()=>import('./pages/EssayPage'))
const EssayReviewPage = lazy(()=>import('./pages/EssayReviewPage'))
const TeacherPartnershipPage = lazy(()=>import('./pages/TeacherPartnershipPage'))
const LegalConsentPage = lazy(()=>import('./pages/LegalConsentPage'))

function Protected({children}:{children:ReactNode}) {
  const {user,loading,connectionError,retrySession} = useAuth()
  if (loading) return <div className="p-10"><Loading/></div>
  if (connectionError) return <div className="grid min-h-screen place-items-center bg-slate-50 p-5"><div className="w-full max-w-xl"><ErrorState message={connectionError} retry={()=>void retrySession()}/><p className="mt-4 text-center text-sm text-slate-500">Sua sessão foi preservada. Assim que a API voltar, tente novamente.</p></div></div>
  if (!user) return <Navigate to="/entrar" replace/>
  if (!user.onboardingComplete) return <Navigate to="/consentimento" replace/>
  return <AppLayout>{children}</AppLayout>
}

function ExerciseModes() {
  const [params] = useSearchParams()
  const kind = params.get('modo') === 'simulado' ? 'simulation' : 'exercise'
  return <AssessmentPage key={kind} kind={kind}/>
}

export default function App() {
  return <Suspense fallback={<div className="p-10"><Loading/></div>}><Routes>
    <Route path="/" element={<Landing/>}/>
    <Route path="/entrar" element={<Auth mode="login"/>}/>
    <Route path="/cadastro" element={<Auth mode="register"/>}/>
    <Route path="/consentimento" element={<LegalConsentPage/>}/>
    <Route path="/app" element={<Protected><Dashboard/></Protected>}/>
    <Route path="/app/diagnostico" element={<Protected><AssessmentPage key="diagnostic" kind="diagnostic"/></Protected>}/>
    <Route path="/app/plano" element={<Protected><PlanPage/></Protected>}/>
    <Route path="/app/rotina" element={<Protected><PlanPage routine/></Protected>}/>
    <Route path="/app/exercicios" element={<Protected><ExerciseModes/></Protected>}/>
    <Route path="/app/redacao" element={<Protected><EssayPage/></Protected>}/>
    <Route path="/app/simulados" element={<Navigate to="/app/exercicios?modo=simulado" replace/>}/>
    <Route path="/app/simulados/historico" element={<Protected><SimulationHistoryPage/></Protected>}/>
    <Route path="/app/questoes" element={<Protected><QuestionsPage/></Protected>}/>
    <Route path="/app/professores" element={<Protected><TeachersPage/></Protected>}/>
    <Route path="/app/professores/parceria" element={<Protected><TeacherPartnershipPage/></Protected>}/>
    <Route path="/app/professor" element={<Protected><EssayReviewPage/></Protected>}/>
    <Route path="/app/perfil" element={<Navigate to="/app/configuracoes" replace/>}/>
    <Route path="/app/desempenho" element={<Protected><PerformancePage/></Protected>}/>
    <Route path="/app/objetivo" element={<Protected><GoalPage/></Protected>}/>
    <Route path="/app/configuracoes" element={<Protected><SettingsPage/></Protected>}/>
    <Route path="/app/admin/questoes" element={<Protected><AdminQuestionsPage/></Protected>}/>
    <Route path="/app/admin/redacoes" element={<Navigate to="/app/professor" replace/>}/>
    <Route path="*" element={<Navigate to="/"/>}/>
  </Routes></Suspense>
}
