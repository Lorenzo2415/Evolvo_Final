import type { ReactNode } from 'react'
import { AlertCircle, CheckCircle2, LoaderCircle } from 'lucide-react'

export function PageHeader({eyebrow,title,description,action}:{eyebrow?:string;title:string;description?:string;action?:ReactNode}){
 return <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div>{eyebrow&&<div className="eyebrow mb-2">{eyebrow}</div>}<h1 className="display text-3xl text-navy sm:text-4xl">{title}</h1>{description&&<p className="mt-2 max-w-2xl text-slate-600">{description}</p>}</div>{action}</div>
}
export function Loading(){return <div className="grid gap-4 sm:grid-cols-3" aria-label="Carregando"><div className="skeleton h-36 rounded-2xl"/><div className="skeleton h-36 rounded-2xl"/><div className="skeleton h-36 rounded-2xl"/></div>}
export function ErrorState({message,retry}:{message:string;retry?:()=>void}){return <div className="card border-red-200 bg-red-50 text-red-800"><AlertCircle className="mb-2"/><p>{message}</p>{retry&&<button className="btn-secondary mt-4" onClick={retry}>Tentar novamente</button>}</div>}
export function EmptyState({title,description,action}:{title:string;description:string;action?:ReactNode}){return <div className="card py-12 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-mist text-blue"><CheckCircle2/></div><h2 className="text-lg font-bold">{title}</h2><p className="mx-auto mt-2 max-w-lg text-slate-600">{description}</p>{action&&<div className="mt-5">{action}</div>}</div>}
export function BusyButton({busy,children,...props}:{busy:boolean;children:ReactNode}&React.ButtonHTMLAttributes<HTMLButtonElement>){return <button {...props} disabled={busy||props.disabled}>{busy?<LoaderCircle className="animate-spin" size={18}/>:null}{children}</button>}

