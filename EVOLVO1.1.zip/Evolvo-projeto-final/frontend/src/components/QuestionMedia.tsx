import type { QuestionMedia as Media } from '../types'

export default function QuestionMedia({media,position}:{media?:Media;position?:number}) {
  const urls = position == null ? media?.statement : media?.options?.[String(position)]
  if (!urls?.length) return null
  return <div className="my-5 grid gap-3 sm:grid-cols-2">
    {urls.map((url,index)=><figure className="question-media-surface overflow-hidden rounded-2xl border border-slate-200 bg-white p-3" key={`${url}-${index}`}>
      <img className="mx-auto max-h-[420px] w-auto max-w-full object-contain" src={url} loading="lazy" alt={position == null ? `Imagem de apoio da questão ${index+1}` : `Imagem da alternativa ${String.fromCharCode(64+position)}`}/>
    </figure>)}
  </div>
}
