import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ArrowRight, BookOpen, CircleHelp, Filter } from 'lucide-react'
import { Link } from 'react-router-dom'
import { EmptyState, ErrorState, Loading, PageHeader } from '../components/ui'
import { api } from '../services/api'
import type { Question, Subject } from '../types'
import QuestionMedia from '../components/QuestionMedia'

type Goal = { exam:{id:number;name:string} }

export default function QuestionsPage(){
  const [subjectId,setSubjectId]=useState('')
  const [difficulty,setDifficulty]=useState('')
  const [visual,setVisual]=useState('')
  const goal=useQuery({queryKey:['goal'],queryFn:()=>api<Goal|null>('/goal')})
  const subjects=useQuery({queryKey:['question-subjects',goal.data?.exam.id],queryFn:()=>api<Subject[]>(`/exams/${goal.data!.exam.id}/subjects`),enabled:Boolean(goal.data)})
  const query=new URLSearchParams({limit:'50'}); if(subjectId)query.set('subjectId',subjectId);if(difficulty)query.set('difficulty',difficulty);if(visual)query.set('visual','true')
  const questions=useQuery({queryKey:['question-search',subjectId,difficulty,visual],queryFn:()=>api<Question[]>(`/questions?${query}`),enabled:Boolean(goal.data)})
  if(goal.isLoading||subjects.isLoading)return <Loading/>
  if(goal.error)return <ErrorState message={goal.error.message} retry={()=>goal.refetch()}/>
  if(!goal.data)return <EmptyState title="Defina seu objetivo" description="Escolha uma prova antes de pesquisar o banco de questões."/>
  return <><PageHeader eyebrow="Catálogo de questões" title="Explorar questões" description={`Veja quais questões estão disponíveis para ${goal.data.exam.name} e filtre por matéria ou dificuldade.`}/>
    <section className="mb-5 flex flex-col justify-between gap-4 rounded-2xl border border-blue/25 bg-blue/5 p-5 sm:flex-row sm:items-center"><div className="flex gap-3"><CircleHelp className="shrink-0 text-blue"/><div><h2 className="font-bold text-navy">Para que serve esta tela?</h2><p className="mt-1 max-w-2xl text-sm leading-relaxed text-slate-600">É uma consulta ao catálogo: você pode conhecer e filtrar as questões, mas elas não contam como atividade nem alteram seu desempenho. Para responder, receber correção e registrar progresso, use Exercícios.</p></div></div><Link className="btn-primary shrink-0" to="/app/exercicios">Começar exercício <ArrowRight size={17}/></Link></section>
    <section className="card p-5"><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-[1fr_1fr_1fr_auto]">
      <label className="text-sm font-semibold">Matéria<select className="field mt-2" value={subjectId} onChange={e=>setSubjectId(e.target.value)}><option value="">Todas as matérias</option>{subjects.data?.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
      <label className="text-sm font-semibold">Dificuldade<select className="field mt-2" value={difficulty} onChange={e=>setDifficulty(e.target.value)}><option value="">Todas</option><option value="easy">Fácil</option><option value="medium">Média</option><option value="hard">Difícil</option></select></label>
      <label className="text-sm font-semibold">Formato<select className="field mt-2" value={visual} onChange={e=>setVisual(e.target.value)}><option value="">Texto e imagem</option><option value="visual">Com imagem ou gráfico</option></select></label>
      <div className="flex items-end"><span className="btn-secondary w-full"><Filter size={17}/>{questions.data?.length||0} exibidas</span></div>
    </div></section>
    {questions.isLoading?<Loading/>:questions.error?<div className="mt-6"><ErrorState message={questions.error.message} retry={()=>questions.refetch()}/></div>:questions.data?.length?<div className="mt-6 grid gap-4 lg:grid-cols-2">{questions.data.map(q=><article key={q.id} className="card p-6"><div className="flex justify-between gap-3 text-xs font-bold uppercase tracking-wide text-slate-500"><span>{q.subject} · {q.topic}</span><span>{q.difficulty==='easy'?'Fácil':q.difficulty==='medium'?'Média':'Difícil'}</span></div><h2 className="mt-4 whitespace-pre-line font-semibold leading-relaxed text-navy">{q.statement}</h2><QuestionMedia media={q.media}/><ol className="mt-4 space-y-2">{q.options.map(o=><li className="rounded-xl bg-slate-50 px-3 py-2 text-sm" key={o.id}>{String.fromCharCode(64+o.position)}. {o.text}<QuestionMedia media={q.media} position={o.position}/></li>)}</ol><p className="mt-4 flex items-center gap-2 text-xs text-slate-500"><BookOpen size={14}/>{q.source.label} · {q.source.type==='authorial'?'Questão autoral':'Questão oficial'}</p></article>)}</div>:<div className="mt-6"><EmptyState title="Nenhuma questão encontrada" description="Ajuste a matéria ou a dificuldade para ampliar a pesquisa."/></div>}
  </>
}
