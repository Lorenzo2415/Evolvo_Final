import { useState, type ReactNode } from 'react'
import {
  Accessibility,
  BookOpenCheck,
  Check,
  Eye,
  EyeOff,
  Laptop,
  LogOut,
  Moon,
  RefreshCcw,
  ShieldCheck,
  Sparkles,
  Sun,
  UserRound,
} from 'lucide-react'
import { PageHeader } from '../components/ui'
import { useAuth } from '../contexts/AuthContext'
import {
  usePreferences,
  type FontSizePreference,
  type ThemePreference,
} from '../contexts/PreferencesContext'
import { api } from '../services/api'
import ProfilePage from './ProfilePage'

type ConsentChoice = 'accepted' | 'declined' | null

const themeOptions: { value: ThemePreference; label: string; icon: typeof Sun }[] = [
  { value: 'light', label: 'Claro', icon: Sun },
  { value: 'dark', label: 'Escuro', icon: Moon },
  { value: 'system', label: 'Sistema', icon: Laptop },
]

const fontOptions: { value: FontSizePreference; label: string; preview: string }[] = [
  { value: 'small', label: 'Pequena', preview: 'Aa' },
  { value: 'medium', label: 'Padrão', preview: 'Aa' },
  { value: 'large', label: 'Grande', preview: 'Aa' },
]

export default function SettingsPage() {
  const { user, logout } = useAuth()
  const { preferences, resolvedTheme, updatePreferences, resetPreferences } = usePreferences()
  const [consentChoice, setConsentChoice] = useState<ConsentChoice>(null)
  const [consentStatus, setConsentStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')
  const [consentMessage, setConsentMessage] = useState('')

  async function saveConsent() {
    if (consentChoice === null) return
    setConsentStatus('saving')
    setConsentMessage('')
    try {
      await api('/consents', {
        method: 'POST',
        body: JSON.stringify({
          type: 'anonymous_academic_improvement',
          version: '1.0',
          accepted: consentChoice === 'accepted',
        }),
      })
      setConsentStatus('saved')
      setConsentMessage(consentChoice === 'accepted'
        ? 'Autorização registrada com segurança na sua conta.'
        : 'Preferência de não participar registrada na sua conta.')
    } catch (error) {
      setConsentStatus('error')
      setConsentMessage(error instanceof Error ? error.message : 'Não foi possível registrar sua escolha.')
    }
  }

  return <>
    <PageHeader
      eyebrow="Preferências"
      title="Configurações"
      description="Ajuste o Evolvo ao seu jeito de estudar. Preferências visuais ficam neste navegador; consentimentos são registrados na sua conta."
      action={<button className="btn-secondary" type="button" onClick={resetPreferences}><RefreshCcw size={17}/> Restaurar padrões</button>}
    />

    <div className="settings-grid">
      <section className="lg:col-span-2" aria-labelledby="profile-settings-heading">
        <div className="mb-4">
          <h2 id="profile-settings-heading" className="text-xl font-bold text-navy">Perfil</h2>
          <p className="mt-1 text-sm text-slate-600">Mantenha seus dados pessoais atualizados.</p>
        </div>
        <ProfilePage embedded section="profile"/>
      </section>
      <section className="settings-section lg:col-span-2" aria-labelledby="appearance-heading">
        <SectionHeading icon={<Sparkles/>} title="Aparência" description="Escolha como o Evolvo deve aparecer para você." id="appearance-heading"/>
        <div className="mt-6 grid gap-5 xl:grid-cols-[1fr_.85fr]">
          <fieldset>
            <legend className="setting-label">Tema</legend>
            <div className="mt-3 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Tema da interface">
              {themeOptions.map(({ value, label, icon: Icon }) => {
                const selected = preferences.theme === value
                return <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  className={`preference-tile ${selected ? 'preference-tile-active' : ''}`}
                  onClick={() => updatePreferences({ theme: value })}
                >
                  <Icon size={20}/><span>{label}</span>
                  {selected && <Check className="absolute right-2 top-2" size={14}/>} 
                </button>
              })}
            </div>
            <p className="setting-help">Tema aplicado agora: <strong>{resolvedTheme === 'dark' ? 'escuro' : 'claro'}</strong>.</p>
          </fieldset>

          <div className="theme-preview" aria-hidden="true">
            <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-blue"/><span className="h-2 w-24 rounded-full bg-slate-200"/></div>
            <div className="mt-4 grid grid-cols-[.7fr_1fr] gap-3"><div className="h-20 rounded-xl bg-navy"/><div className="space-y-2 rounded-xl border border-slate-200 p-3"><div className="h-2 w-3/4 rounded-full bg-blue"/><div className="h-2 rounded-full bg-slate-200"/><div className="h-2 w-2/3 rounded-full bg-slate-200"/></div></div>
          </div>
        </div>
      </section>

      <section className="settings-section" aria-labelledby="study-heading">
        <SectionHeading icon={<BookOpenCheck/>} title="Estudos" description="Defina os padrões das novas atividades." id="study-heading"/>
        <div className="mt-6 space-y-6">
          <label className="block">
            <span className="setting-label">Quantidade padrão de questões</span>
            <select
              className="field mt-2"
              value={preferences.defaultQuestionCount}
              onChange={event => updatePreferences({ defaultQuestionCount: Number(event.target.value) })}
            >
              {[15, 20, 30, 50].map(value => <option key={value} value={value}>{value} questões</option>)}
            </select>
            <span className="setting-help">Você ainda poderá alterar esse número antes de começar.</span>
          </label>
          <SettingSwitch
            checked={preferences.showQuestionSource}
            onChange={checked => updatePreferences({ showQuestionSource: checked })}
            icon={preferences.showQuestionSource ? <Eye size={18}/> : <EyeOff size={18}/>}
            title="Exibir origem das questões"
            description="Mostra banco, autoria e fonte quando essas informações estiverem disponíveis."
          />
        </div>
      </section>

      <section className="settings-section" aria-labelledby="accessibility-heading">
        <SectionHeading icon={<Accessibility/>} title="Acessibilidade" description="Conforto visual e menos distrações." id="accessibility-heading"/>
        <div className="mt-6 space-y-6">
          <fieldset>
            <legend className="setting-label">Tamanho do texto</legend>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {fontOptions.map(({ value, label, preview }, index) => <button
                key={value}
                type="button"
                aria-pressed={preferences.fontSize === value}
                className={`font-choice ${preferences.fontSize === value ? 'font-choice-active' : ''}`}
                onClick={() => updatePreferences({ fontSize: value })}
              ><span className={index === 0 ? 'text-sm' : index === 2 ? 'text-xl' : 'text-base'}>{preview}</span><small>{label}</small></button>)}
            </div>
          </fieldset>
          <SettingSwitch
            checked={preferences.reducedMotion}
            onChange={checked => updatePreferences({ reducedMotion: checked })}
            icon={<Accessibility size={18}/>}
            title="Reduzir animações"
            description="Minimiza transições e movimentos em toda a interface."
          />
        </div>
      </section>

      <section className="lg:col-span-2" aria-labelledby="subjects-heading">
        <div className="mb-4">
          <h2 id="subjects-heading" className="text-xl font-bold text-navy">Matérias prioritárias</h2>
          <p className="mt-1 text-sm text-slate-600">Escolha onde o plano e as recomendações devem concentrar mais atenção.</p>
        </div>
        <ProfilePage embedded section="priorities"/>
      </section>

      <section className="settings-section" aria-labelledby="account-heading">
        <SectionHeading icon={<UserRound/>} title="Conta" description="Dados da sessão atual e acesso." id="account-heading"/>
        <div className="mt-6 flex items-center gap-4 rounded-2xl bg-mist p-4">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-navy font-bold text-white">{user?.name?.charAt(0).toUpperCase() || 'E'}</div>
          <div className="min-w-0"><p className="truncate font-bold">{user?.name}</p><p className="truncate text-sm text-slate-600">{user?.email}</p><span className="mt-1 inline-block rounded-full bg-white px-2 py-0.5 text-xs font-semibold capitalize text-slate-600">{user?.role === 'admin' ? 'Administrador' : 'Estudante'}</span></div>
        </div>
        <button type="button" className="btn-secondary mt-5 w-full text-danger" onClick={logout}><LogOut size={18}/> Sair da conta</button>
      </section>

      <section className="settings-section" aria-labelledby="privacy-heading">
        <SectionHeading icon={<ShieldCheck/>} title="Privacidade" description="Você decide sobre usos opcionais dos seus dados." id="privacy-heading"/>
        <div className="mt-6 rounded-2xl border border-slate-200 p-4">
          <p className="font-semibold">Melhorias com dados acadêmicos anonimizados</p>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">Esta autorização é opcional e não afeta seu acesso. Escolha abaixo para registrar uma nova decisão no servidor.</p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <button type="button" aria-pressed={consentChoice === 'accepted'} className={`choice-button ${consentChoice === 'accepted' ? 'choice-button-active' : ''}`} onClick={() => { setConsentChoice('accepted'); setConsentStatus('idle') }}>Autorizar</button>
            <button type="button" aria-pressed={consentChoice === 'declined'} className={`choice-button ${consentChoice === 'declined' ? 'choice-button-active' : ''}`} onClick={() => { setConsentChoice('declined'); setConsentStatus('idle') }}>Não autorizar</button>
          </div>
          <button type="button" className="btn-primary mt-4 w-full sm:w-auto" disabled={consentChoice === null || consentStatus === 'saving'} onClick={() => void saveConsent()}>{consentStatus === 'saving' ? 'Registrando…' : 'Registrar escolha'}</button>
          {consentMessage && <p role="status" className={`mt-3 text-sm font-medium ${consentStatus === 'error' ? 'text-danger' : 'text-mint'}`}>{consentMessage}</p>}
        </div>
      </section>
    </div>
  </>
}

function SectionHeading({ icon, title, description, id }: { icon: ReactNode; title: string; description: string; id: string }) {
  return <div className="flex items-start gap-3"><span className="section-icon">{icon}</span><div><h2 id={id} className="text-lg font-bold text-navy">{title}</h2><p className="mt-1 text-sm text-slate-600">{description}</p></div></div>
}

function SettingSwitch({ checked, onChange, icon, title, description }: { checked: boolean; onChange: (checked: boolean) => void; icon: ReactNode; title: string; description: string }) {
  return <div className="flex items-center gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-mist text-blue">{icon}</span><label className="flex min-w-0 flex-1 cursor-pointer items-center justify-between gap-4"><span><span className="block text-sm font-semibold">{title}</span><span className="mt-0.5 block text-xs leading-relaxed text-slate-500">{description}</span></span><input className="peer sr-only" type="checkbox" checked={checked} onChange={event => onChange(event.target.checked)}/><span aria-hidden="true" className="toggle-track"><span className="toggle-thumb"/></span></label></div>
}

