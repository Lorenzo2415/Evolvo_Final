import { FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { ArrowRight, BadgeCheck, BookOpenCheck, CheckCircle2, GraduationCap, MonitorSmartphone, Sparkles, UsersRound } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { BusyButton, Loading, PageHeader } from '../components/ui'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../services/api'
import type { Subject } from '../types'

type Goal={exam:{id:number}}
type Exam={id:number;supportStatus:string}
type Application={id:number;name:string;email:string;biography:string;hourlyPrice:number;modality:string;city:string|null;contact:string;subjectIds:number[];status:'approved';createdAt:string;accessToken?:string}

export default function TeacherPartnershipPage(){
  const {retrySession}=useAuth();const navigate=useNavigate()
  const status=useQuery({queryKey:['teacher-partnership'],queryFn:()=>api<Application|null>('/teacher-partnership')})
  const goal=useQuery({queryKey:['goal'],queryFn:()=>api<Goal|null>('/goal')})
  const exams=useQuery({queryKey:['exams'],queryFn:()=>api<Exam[]>('/exams')})
  const examId=goal.data?.exam.id||exams.data?.find(item=>item.supportStatus==='full')?.id
  const subjects=useQuery({queryKey:['partner-subjects',examId],queryFn:()=>api<Subject[]>(`/exams/${examId}/subjects`),enabled:Boolean(examId)})
  const apply=useMutation({mutationFn:(body:object)=>api<Application>('/teacher-partnership',{method:'POST',body:JSON.stringify(body)}),onSuccess:async data=>{if(data.accessToken)localStorage.setItem('evolvo_token',data.accessToken);await retrySession();navigate('/app/professor')}})
  function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();const form=new FormData(event.currentTarget);apply.mutate({biography:form.get('biography'),hourlyPrice:Number(form.get('hourlyPrice')),modality:form.get('modality'),city:form.get('city'),contact:form.get('contact'),subjectIds:form.getAll('subjectIds').map(Number)})}
  if(status.isLoading)return <Loading/>
  if(status.data)return <><PageHeader eyebrow="Perfil docente" title="Você já faz parte da rede" description="Seu perfil está publicado e a área de correções está liberada."/><div className="card overflow-hidden !p-0"><div className="bg-gradient-to-r from-navy to-blue p-7 text-white"><BadgeCheck size={38}/><h2 className="mt-4 text-2xl font-bold">Perfil de professor ativo</h2><p className="mt-2 max-w-2xl text-blue-100">Estudantes podem encontrar seu perfil e você já pode acessar as redações encaminhadas para correção.</p></div><div className="flex flex-wrap gap-3 p-6"><Link className="btn-primary" to="/app/professor">Abrir área do professor <ArrowRight size={17}/></Link><Link className="btn-secondary" to="/app/professores">Ver rede de professores</Link></div></div></>
  return <><PageHeader eyebrow="Ensine no Evolvo" title="Transforme sua experiência em apoio real" description="Monte seu perfil em poucos minutos e comece agora. Não há fila de aprovação nesta versão acadêmica."/>
    <section className="mb-6 grid gap-3 md:grid-cols-3"><Benefit icon={<UsersRound/>} title="Seja encontrado" text="Apareça na busca por matéria e modalidade."/><Benefit icon={<BookOpenCheck/>} title="Corrija redações" text="Acesse textos enviados pelos estudantes."/><Benefit icon={<MonitorSmartphone/>} title="Atenda do seu jeito" text="Informe formato, cidade e valor da aula."/></section>
    <form className="card overflow-hidden !p-0" onSubmit={submit}>
      <div className="border-b border-slate-200 bg-mist px-5 py-4 sm:px-7"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-blue text-white"><GraduationCap size={20}/></span><div><h2 className="font-bold text-navy">Crie seu perfil profissional</h2><p className="text-sm text-slate-500">Essas informações ficarão visíveis para os estudantes.</p></div></div></div>
      <div className="space-y-6 p-5 sm:p-7"><div className="grid gap-5 lg:grid-cols-2"><label className="text-sm font-semibold lg:col-span-2">Como você ensina?<textarea className="field mt-2 min-h-32 font-normal" name="biography" minLength={40} required placeholder="Conte sua experiência, sua formação e como costuma ajudar estudantes a aprender."/><span className="mt-1 block text-xs font-normal text-slate-500">Mínimo de 40 caracteres. Seja direto e acolhedor.</span></label><label className="text-sm font-semibold">Valor por hora<input className="field mt-2 font-normal" name="hourlyPrice" type="number" min="1" step="0.01" required placeholder="Ex.: 75"/></label><label className="text-sm font-semibold">Modalidade<select className="field mt-2 font-normal" name="modality" defaultValue="online"><option value="online">Online</option><option value="presential">Presencial</option><option value="both">Online e presencial</option></select></label><label className="text-sm font-semibold">Cidade<input className="field mt-2 font-normal" name="city" placeholder="Opcional para atendimento online"/></label><label className="text-sm font-semibold">Contato profissional<input className="field mt-2 font-normal" name="contact" required placeholder="E-mail, telefone ou perfil profissional"/></label></div>
        <fieldset><legend className="font-bold text-navy">O que você ensina?</legend><p className="mt-1 text-sm text-slate-500">Marque uma ou mais matérias.</p><div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{subjects.data?.map(subject=><label className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-200 p-3 text-sm font-semibold transition hover:border-blue hover:bg-blue/5" key={subject.id}><input className="size-4 accent-blue" type="checkbox" name="subjectIds" value={subject.id}/>{subject.name}</label>)}</div></fieldset>
        <div className="rounded-xl border border-blue/20 bg-blue/5 p-4"><div className="flex gap-3"><Sparkles className="shrink-0 text-blue" size={20}/><div><strong className="text-sm text-navy">Ativação imediata</strong><p className="mt-1 text-xs leading-relaxed text-slate-600">Ao finalizar, seu perfil entra na rede e a área do professor é liberada. Você poderá atualizar as informações depois.</p></div></div></div>
        {apply.error&&<p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-danger">{apply.error.message}</p>}<BusyButton busy={apply.isPending} className="btn-primary w-full sm:w-auto" type="submit"><CheckCircle2 size={18}/>Ativar meu perfil de professor</BusyButton>
      </div>
    </form>
  </>
}

function Benefit({icon,title,text}:{icon:ReactNode;title:string;text:string}){return <article className="card flex items-start gap-3 p-4"><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-blue/10 text-blue">{icon}</span><div><h2 className="font-bold text-navy">{title}</h2><p className="mt-1 text-xs leading-relaxed text-slate-500">{text}</p></div></article>}
