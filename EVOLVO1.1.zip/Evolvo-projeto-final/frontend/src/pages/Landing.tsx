import {
  ArrowRight,
  BarChart3,
  BrainCircuit,
  CalendarCheck,
  Check,
  ChevronRight,
  ClipboardCheck,
  Dumbbell,
  Route,
  School,
  SearchCheck,
  ShieldCheck,
  Target,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Logo } from '../layouts/AppLayout'

const journey = [
  {
    icon: Target,
    title: 'Conte onde quer chegar',
    text: 'Defina a prova, a data e o tempo que você pode dedicar além das aulas.',
  },
  {
    icon: ClipboardCheck,
    title: 'Descubra suas lacunas',
    text: 'Responda questões alinhadas à prova para revelar assuntos que precisam de atenção.',
  },
  {
    icon: CalendarCheck,
    title: 'Treine com direção',
    text: 'Receba práticas e revisões focadas nos pontos em que você mais pode evoluir.',
  },
  {
    icon: Route,
    title: 'Acompanhe a evolução',
    text: 'Cada resposta atualiza seu histórico e torna as próximas recomendações mais úteis.',
  },
]

const benefits = [
  {
    icon: BrainCircuit,
    title: 'Clareza sobre o que falta',
    text: 'A plataforma não presume o que você sabe. As prioridades nascem das suas respostas e do seu objetivo.',
  },
  {
    icon: CalendarCheck,
    title: 'Treino que cabe na rotina',
    text: 'As atividades consideram sua disponibilidade e convivem com escola, cursinho, professor ou estudo próprio.',
  },
  {
    icon: BarChart3,
    title: 'Evolução que você consegue ver',
    text: 'Relatórios usam atividades concluídas para mostrar avanços, dificuldades e assuntos que ainda pedem revisão.',
  },
]

export default function Landing() {
  const { user } = useAuth()

  return (
    <div className="min-h-screen bg-white text-ink dark:bg-[#0b1220] dark:text-[#e7effa]">
      <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-white/90 backdrop-blur dark:border-slate-700 dark:bg-[#0b1220]/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <Logo />
          <nav aria-label="Navegação principal" className="hidden items-center gap-7 text-sm font-medium md:flex">
            <a className="transition hover:text-blue" href="#como-funciona">Como funciona</a>
            <a className="transition hover:text-blue" href="#como-complementa">Como complementa</a>
            <a className="transition hover:text-blue" href="#o-que-voce-recebe">O que você recebe</a>
            <Link className="transition hover:text-blue" to={user ? '/app/configuracoes' : '/entrar'}>{user ? 'Minha conta' : 'Entrar'}</Link>
            <Link className="btn-primary !py-2.5" to={user ? '/app' : '/cadastro'}>{user ? 'Abrir painel' : 'Criar conta'}</Link>
          </nav>
          <Link className="btn-secondary !px-3 !py-2 md:hidden" to={user ? '/app' : '/entrar'}>{user ? 'Painel' : 'Entrar'}</Link>
        </div>
      </header>

      <main>
        <section className="hero-grid overflow-hidden bg-navy text-white">
          <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-16 lg:grid-cols-[1.02fr_.98fr] lg:py-24">
            <div>
              <p className="mb-5 text-xs font-bold uppercase tracking-[.22em] text-blue-200">Apoio inteligente para sua preparação</p>
              <h1 className="display max-w-3xl text-5xl leading-[1.03] sm:text-6xl">Transforme seus pontos fracos em treino direcionado.</h1>
              <p className="mt-6 max-w-2xl text-lg leading-relaxed text-blue-100">
                O Evolvo complementa sua escola, seu cursinho ou seu estudo individual. Ele identifica lacunas, recomenda o que praticar e mostra sua evolução com base no que você realmente respondeu.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Link className="btn bg-white text-navy hover:bg-blue-50" to={user ? '/app' : '/cadastro'}>{user ? 'Abrir meu painel' : 'Descobrir meus pontos fracos'} <ArrowRight size={18} /></Link>
                <a className="btn border border-white/25 text-white hover:bg-white/10" href="#como-funciona">Ver como funciona</a>
              </div>
              <div className="mt-6 flex items-start gap-2 text-sm text-blue-200">
                <ShieldCheck className="mt-0.5 shrink-0" size={17} />
                <span>Sem promessas mágicas: o Evolvo apoia sua preparação e não substitui professores, escola ou cursinho.</span>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -left-14 top-10 h-44 w-44 rounded-full bg-blue/25 blur-3xl" />
              <div className="relative rounded-[28px] border border-white/15 bg-white/10 p-3 shadow-2xl backdrop-blur">
                <div className="rounded-2xl bg-white p-6 text-ink sm:p-7">
                  <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
                    <div>
                      <p className="eyebrow">Seu caminho no Evolvo</p>
                      <h2 className="mt-2 text-xl font-bold text-navy">Primeiro suas respostas. Depois, o foco.</h2>
                    </div>
                    <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-mist text-blue"><Route size={22} /></div>
                  </div>

                  <ol className="mt-5 space-y-3">
                    {[
                      ['1', 'Objetivo', 'Escolha a prova e informe sua disponibilidade.'],
                      ['2', 'Diagnóstico', 'Mapeie seus conhecimentos sem resultado inventado.'],
                      ['3', 'Treino direcionado', 'Pratique os assuntos que mais precisam de reforço.'],
                    ].map(([number, title, text], index) => (
                      <li className="flex gap-4" key={number}>
                        <div className="flex flex-col items-center">
                          <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-sm font-bold ${index === 0 ? 'bg-blue text-white' : 'bg-mist text-blue'}`}>{number}</span>
                          {index < 2 && <span className="my-1 h-7 w-px bg-slate-200" />}
                        </div>
                        <div className="pb-2 pt-1">
                          <strong className="text-sm text-navy">{title}</strong>
                          <p className="mt-1 text-sm leading-relaxed text-slate-500">{text}</p>
                        </div>
                      </li>
                    ))}
                  </ol>

                  <div className="mt-5 rounded-xl border border-dashed border-blue/30 bg-blue-50 p-4 text-sm leading-relaxed text-slate-600">
                    Use o que aprende nas aulas e materiais que já acompanha. O Evolvo ajuda a decidir onde praticar mais.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-b border-slate-200 bg-slate-50">
          <div className="mx-auto grid max-w-7xl gap-5 px-5 py-6 text-sm font-semibold text-slate-600 sm:grid-cols-3">
            {['Complementa escola, cursinho e professor', 'Recomendações com motivo explicado', 'Histórico baseado em respostas reais'].map(item => (
              <div className="flex items-center gap-2" key={item}><Check className="text-mint" size={19} /><span>{item}</span></div>
            ))}
          </div>
        </section>

        <section id="como-funciona" className="mx-auto max-w-7xl px-5 py-20 sm:py-24">
          <div className="grid gap-10 lg:grid-cols-[.75fr_1.25fr]">
            <div>
              <p className="eyebrow">Como funciona</p>
              <h2 className="display mt-3 text-4xl leading-tight text-navy">Você já tem conteúdo. O Evolvo ajuda a encontrar onde insistir.</h2>
              <p className="mt-5 max-w-lg leading-relaxed text-slate-600">Cada etapa reúne evidências para orientar seu treino. Quanto mais você pratica, mais contexto o sistema tem para indicar lacunas, revisões e prioridades.</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {journey.map(({ icon: Icon, title, text }, index) => (
                <article className="card group relative overflow-hidden p-6" key={title}>
                  <span className="absolute right-5 top-4 text-5xl font-bold text-slate-100">0{index + 1}</span>
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-mist text-blue"><Icon size={22} /></div>
                  <h3 className="mt-6 font-bold text-navy">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="como-complementa" className="bg-navy text-white">
          <div className="mx-auto max-w-7xl px-5 py-20 sm:py-24">
            <div className="max-w-3xl">
              <p className="text-xs font-bold uppercase tracking-[.2em] text-blue-200">Um apoio, não um substituto</p>
              <h2 className="display mt-3 text-4xl leading-tight">Cada parte da preparação tem um papel.</h2>
              <p className="mt-5 leading-relaxed text-blue-100">O Evolvo entra entre o conteúdo que você aprende e a prática que precisa fazer. Ele dá direção ao treino sem tentar ocupar o lugar de quem ensina.</p>
            </div>
            <div className="mt-10 grid gap-5 md:grid-cols-3">
              {[
                { icon: School, step: 'Aprenda', title: 'Escola, cursinho e professores', text: 'Apresentam conteúdo, aprofundam conceitos, tiram dúvidas e oferecem orientação humana.' },
                { icon: SearchCheck, step: 'Identifique', title: 'Evolvo', text: 'Analisa seu desempenho, aponta lacunas e transforma resultados em prioridades explicadas.' },
                { icon: Dumbbell, step: 'Treine', title: 'Sua prática', text: 'Você exercita os pontos fracos, revisa com intenção e acompanha se a dificuldade está diminuindo.' },
              ].map(({ icon: Icon, step, title, text }) => (
                <article className="rounded-2xl border border-white/15 bg-white/10 p-6" key={step}>
                  <div className="flex items-center justify-between gap-4">
                    <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-blue-200"><Icon size={22} /></div>
                    <span className="text-xs font-bold uppercase tracking-[.18em] text-blue-200">{step}</span>
                  </div>
                  <h3 className="mt-6 text-lg font-bold">{title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-blue-100">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="o-que-voce-recebe" className="bg-mist">
          <div className="mx-auto max-w-7xl px-5 py-20 sm:py-24">
            <div className="mx-auto max-w-3xl text-center">
              <p className="eyebrow">Depois do diagnóstico</p>
              <h2 className="display mt-3 text-4xl text-navy">Menos dúvida sobre o que treinar depois</h2>
              <p className="mt-4 leading-relaxed text-slate-600">As recomendações partem do seu histórico e podem ser rastreadas até atividades realizadas. Você entende o motivo de cada prioridade.</p>
            </div>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              {benefits.map(({ icon: Icon, title, text }) => (
                <article className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm" key={title}>
                  <Icon className="text-blue" />
                  <h3 className="mt-6 text-lg font-bold text-navy">{title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-600">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-5 py-20 sm:py-24">
          <div className="overflow-hidden rounded-[28px] bg-navy px-6 py-10 text-white sm:px-10 lg:flex lg:items-center lg:justify-between lg:gap-10">
            <div className="max-w-2xl">
              <p className="text-xs font-bold uppercase tracking-[.2em] text-blue-200">Seu próximo passo</p>
              <h2 className="display mt-3 text-3xl sm:text-4xl">Descubra onde seu próximo esforço pode render mais.</h2>
              <p className="mt-4 text-blue-100">Informe seu objetivo e faça um diagnóstico para começar a treinar com mais direção.</p>
            </div>
            <Link className="btn mt-7 shrink-0 bg-white text-navy hover:bg-blue-50 lg:mt-0" to={user ? '/app' : '/cadastro'}>{user ? 'Continuar estudando' : 'Começar agora'} <ChevronRight size={18} /></Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 px-5 py-8">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-3 text-sm text-slate-500 sm:flex-row">
          <span>© 2026 Evolvo. Apoio inteligente para sua preparação.</span>
          <span>Ferramenta complementar: não substitui escola, cursinho ou orientação docente.</span>
        </div>
      </footer>
    </div>
  )
}
