import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlarmClock,
  ArrowLeft,
  ArrowRight,
  BarChart3,
  BookOpenCheck,
  Check,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  Flag,
  RotateCcw,
  Sparkles,
  Target,
} from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'
import { BusyButton, EmptyState, ErrorState, Loading, PageHeader } from '../components/ui'
import { usePreferences } from '../contexts/PreferencesContext'
import { api } from '../services/api'
import type { Assessment, Exam, Subject } from '../types'
import QuestionMedia from '../components/QuestionMedia'

type Kind = 'diagnostic'|'exercise'|'simulation'|'review'
type Goal = { exam:Exam }

const config:Record<Kind,{
  eyebrow:string
  title:string
  description:string
  create:string
  finish:(id:number)=>string
  counts:number[]
  estimate:number
}> = {
  diagnostic: {
    eyebrow:'Mapeamento inicial',
    title:'Diagnóstico',
    description:'Escolha o tamanho e as matérias ou áreas. O resultado identifica lacunas sem presumir o que você já sabe.',
    create:'/diagnostics',
    finish:id=>`/diagnostics/${id}/finish`,
    counts:[15,20,30,50],
    estimate:2,
  },
  exercise: {
    eyebrow:'Prática direcionada',
    title:'Exercícios adaptativos',
    description:'Treine uma ou várias matérias ou áreas. Dentro da seleção, o Evolvo prioriza assuntos com menor domínio.',
    create:'/exercise-lists',
    finish:id=>`/exercise-lists/${id}/finish`,
    counts:[15,20,30,50],
    estimate:2,
  },
  simulation: {
    eyebrow:'Ambiente de prova',
    title:'Simulado',
    description:'Escolha um treino cronometrado, o recorte objetivo do Dia 1 ou Dia 2, ou as 180 questões da prova completa.',
    create:'/simulations',
    finish:id=>`/simulations/${id}/finish`,
    counts:[30,50,90,100,180],
    estimate:3,
  },
  review: {
    eyebrow:'Revisão programada',
    title:'Revisão personalizada',
    description:'Retome assuntos no intervalo sugerido pelo seu histórico.',
    create:'/reviews',
    finish:id=>`/exercise-lists/${id}/finish`,
    counts:[5,10],
    estimate:2,
  },
}

function formatTime(seconds:number) {
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor(seconds / 60).toString().padStart(2,'0')
  const remainder = (seconds % 60).toString().padStart(2,'0')
  return hours ? `${hours}:${String(Math.floor(seconds / 60) % 60).padStart(2,'0')}:${remainder}` : `${minutes}:${remainder}`
}

export default function AssessmentPage({kind}:{kind:Kind}) {
  const c = config[kind]
  const qc = useQueryClient()
  const [searchParams] = useSearchParams()
  const { preferences } = usePreferences()
  const planTaskId = Number(searchParams.get('taskId')) || undefined
  const planTopicId = Number(searchParams.get('topicId')) || undefined
  const planSubjectId = Number(searchParams.get('subjectId')) || undefined
  const requestedFromPlan = Number(searchParams.get('count'))
  const [item,setItem] = useState<Assessment|null>(null)
  const [answers,setAnswers] = useState<Record<number,number>>({})
  const [questionCount,setQuestionCount] = useState(() => c.counts.includes(requestedFromPlan)
    ? requestedFromPlan
    : c.counts.includes(preferences.defaultQuestionCount) ? preferences.defaultQuestionCount
    : [...c.counts].reverse().find(count => count <= preferences.defaultQuestionCount) || c.counts[0])
  const [allSubjects,setAllSubjects] = useState(!planSubjectId)
  const [subjectIds,setSubjectIds] = useState<number[]>(planSubjectId ? [planSubjectId] : [])
  const [difficulty,setDifficulty] = useState('')
  const [simulationBlueprint,setSimulationBlueprint] = useState<'custom'|'day1'|'day2'|'full'>('custom')
  const [currentIndex,setCurrentIndex] = useState(0)
  const [marked,setMarked] = useState<number[]>([])
  const [elapsedSeconds,setElapsedSeconds] = useState(0)
  const [questionTimes,setQuestionTimes] = useState<Record<number,number>>({})

  const goal = useQuery({queryKey:['goal'],queryFn:()=>api<Goal|null>('/goal')})
  const subjects = useQuery({
    queryKey:['assessment-subjects',goal.data?.exam.id],
    queryFn:()=>api<Subject[]>(`/exams/${goal.data!.exam.id}/subjects`),
    enabled:Boolean(goal.data?.exam.id),
  })

  useEffect(() => {
    if (!item || item.status === 'completed' || kind !== 'simulation') return
    const questionId = item.questions[currentIndex]?.id
    const timer = window.setInterval(() => {
      setElapsedSeconds(value => value + 1)
      if (questionId) setQuestionTimes(current => ({...current,[questionId]:(current[questionId] || 0) + 1}))
    }, 1000)
    return () => window.clearInterval(timer)
  }, [item,kind,currentIndex])

  const create = useMutation({
    mutationFn:()=>api<Assessment>(c.create,{
      method:'POST',
      body:JSON.stringify({
        questionCount,
        subjectIds:allSubjects ? [] : subjectIds,
        ...(kind === 'simulation' && difficulty ? {difficulty} : {}),
        ...(kind === 'simulation' ? {blueprint:simulationBlueprint} : {}),
        ...(kind === 'exercise'&&planTaskId ? {taskId:planTaskId,topicIds:planTopicId ? [planTopicId] : []} : {}),
      }),
    }),
    onSuccess:data=>{
      setItem(data)
      setAnswers({})
      setMarked([])
      setCurrentIndex(0)
      setElapsedSeconds(0)
      setQuestionTimes({})
    },
  })
  const finish = useMutation({
    mutationFn:()=>api<Assessment>(c.finish(item!.id),{
      method:'POST',
      body:JSON.stringify({
        answers:Object.entries(answers).map(([questionId,optionId])=>({questionId:Number(questionId),optionId})),
        ...(kind === 'simulation' ? {timing:{totalSeconds:elapsedSeconds,questionSeconds:questionTimes}} : {}),
      }),
    }),
    onSuccess:data=>{
      setItem(data)
      void qc.invalidateQueries({queryKey:['plan']})
      void qc.invalidateQueries({queryKey:['routine']})
      void qc.invalidateQueries({queryKey:['dashboard']})
    },
  })

  const selectedNames = useMemo(() => {
    if (allSubjects) return 'todas as matérias e áreas'
    return (subjects.data || []).filter(subject => subjectIds.includes(subject.id)).map(subject => subject.name).join(', ')
  }, [allSubjects,kind,subjectIds,subjects.data])
  const availableQuestionCount = useMemo(() => (subjects.data || [])
    .filter(subject => allSubjects || subjectIds.includes(subject.id))
    .reduce((total,subject) => total + subject.approvedQuestionCount,0), [allSubjects,subjectIds,subjects.data])

  useEffect(() => {
    if (!availableQuestionCount || questionCount <= availableQuestionCount) return
    const fallback = [...c.counts].reverse().find(count => count <= availableQuestionCount)
    if (fallback) setQuestionCount(fallback)
  }, [availableQuestionCount,c.counts,questionCount])

  if (goal.isLoading || (goal.data && subjects.isLoading)) return <Loading />
  if (goal.error) return <ErrorState message={goal.error.message} retry={()=>goal.refetch()} />
  if (subjects.error) return <ErrorState message={subjects.error.message} retry={()=>subjects.refetch()} />
  if (!goal.data) return <EmptyState title="Defina sua prova primeiro" description="O Evolvo precisa do exame escolhido para selecionar questões compatíveis." action={<Link className="btn-primary" to="/app/objetivo">Configurar meu objetivo</Link>} />

  function toggleSubject(id:number) {
    setAllSubjects(false)
    setSubjectIds(current => current.includes(id) ? current.filter(item => item !== id) : [...current,id])
  }

  if (!item) {
    const invalidSelection = !allSubjects && subjectIds.length === 0
    const invalidCount = subjects.isSuccess && questionCount > availableQuestionCount
    return <>
      <PageHeader eyebrow={kind==='simulation'?'Exercícios · modo simulado ativado':c.eyebrow} title={kind==='simulation'?'Modo simulado':c.title} description={c.description} action={kind==='exercise'?<Link className="btn-primary" to="/app/exercicios?modo=simulado"><AlarmClock size={17}/> Ativar modo simulado</Link>:kind==='simulation'?<div className="flex flex-wrap gap-2"><Link className="btn-primary" to="/app/exercicios"><BookOpenCheck size={17}/> Desativar modo simulado</Link><Link className="btn-secondary" to="/app/simulados/historico"><BarChart3 size={17}/> Histórico</Link></div>:undefined} />
      {planTaskId&&<div className="mb-6 rounded-2xl border border-blue/20 bg-blue/5 p-5"><p className="font-bold text-navy">Atividade vinculada ao plano</p><p className="mt-1 text-sm text-slate-600">Esta sessão será marcada como concluída somente depois que você responder e finalizar todas as questões.</p></div>}
      <div className="grid gap-6 xl:grid-cols-[1fr_.48fr]">
        <section className="card p-6 sm:p-7">
          {kind==='exercise'&&<div className="mb-6 flex gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4"><BookOpenCheck className="shrink-0 text-emerald-700"/><div><h2 className="font-bold text-emerald-900">Prática livre, sem cronômetro</h2><p className="mt-1 text-sm leading-relaxed text-emerald-800">Treine no seu ritmo. As questões priorizam suas dificuldades e a correção detalhada aparece quando você finalizar.</p></div></div>}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-5">
            <div>
              <p className="text-sm font-semibold text-slate-500">Prova selecionada</p>
              <h2 className="mt-1 text-xl font-bold text-navy">{goal.data.exam.name}</h2>
            </div>
            <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-800">Suporte {goal.data.exam.supportStatus === 'full' ? 'completo' : 'limitado'}</span>
          </div>

          {kind === 'simulation'&&<label className="mt-6 block text-sm font-bold text-navy">Formato do simulado<select className="field mt-2" value={simulationBlueprint} onChange={event=>{
            const value=event.target.value as 'custom'|'day1'|'day2'|'full'
            setSimulationBlueprint(value)
            if(value==='day1'||value==='day2') setQuestionCount(90)
            if(value==='full') setQuestionCount(180)
          }}><option value="custom">Treino personalizado</option><option value="day1">Dia 1 objetivo — Linguagens e Humanas (90)</option><option value="day2">Dia 2 — Natureza e Matemática (90)</option><option value="full">Prova objetiva completa (180)</option></select><span className="mt-2 block text-xs font-normal leading-relaxed text-slate-500">O Dia 1 cobre somente a parte objetiva. A redação será realizada no módulo próprio.</span></label>}

          <fieldset className="mt-6">
            <legend className="font-bold text-navy">Quantas questões?</legend>
            <p className="mt-1 text-sm text-slate-500">Você poderá acompanhar o progresso durante a atividade.</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {c.counts.map(count => <button key={count} type="button" disabled={(subjects.isSuccess && count > availableQuestionCount)||(kind==='simulation'&&simulationBlueprint!=='custom')} onClick={()=>setQuestionCount(count)} className={`min-w-20 rounded-xl border px-4 py-3 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-35 ${questionCount===count?'border-blue bg-blue text-white':'border-slate-200 bg-white hover:border-blue/50'}`}>{count}</button>)}
            </div>
          </fieldset>

          {kind !== 'review' && (kind !== 'simulation' || simulationBlueprint === 'custom') && <fieldset className="mt-7">
            <legend className="font-bold text-navy">Quais matérias ou áreas?</legend>
            <div className="mt-1 flex flex-wrap items-center justify-between gap-2"><p className="text-sm text-slate-500">Escolha todas ou combine quantas quiser.</p>{!allSubjects&&<span className="rounded-full bg-mist px-3 py-1 text-xs font-bold text-blue">{subjectIds.length} selecionada{subjectIds.length===1?'':'s'}</span>}</div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              <button type="button" aria-pressed={allSubjects} onClick={()=>{setAllSubjects(true);setSubjectIds([])}} className={`flex min-h-12 items-center justify-between rounded-xl border px-3 py-2.5 text-left transition sm:col-span-2 lg:col-span-3 ${allSubjects?'border-blue bg-blue/10':'border-slate-200 bg-white hover:border-blue/50'}`}>
                <span><strong className="block text-sm">Todas as matérias</strong><span className="block text-[11px] text-slate-500">Mistura equilibrada das áreas disponíveis</span></span>
                {allSubjects&&<Check className="text-blue" size={18}/>} 
              </button>
              {subjects.data?.map(subject => {
                const active = !allSubjects && subjectIds.includes(subject.id)
                const unavailable = subject.approvedQuestionCount === 0
                return <button type="button" aria-pressed={active} key={subject.id} disabled={unavailable} onClick={()=>toggleSubject(subject.id)} title={`${subject.area} · ${subject.topics.length} assuntos`} className={`flex min-h-14 items-center justify-between gap-2 rounded-xl border px-3 py-2 text-left transition ${unavailable?'cursor-not-allowed border-slate-200 bg-slate-50 opacity-55':active?'border-blue bg-blue/10':'border-slate-200 bg-white hover:border-blue/50'}`}>
                  <span className="min-w-0"><strong className="block truncate text-sm">{subject.name}</strong><span className="mt-0.5 block truncate text-[11px] text-slate-500">{unavailable?'Em preparação':`${subject.approvedQuestionCount} questões`}</span></span>
                  {active&&<Check className="shrink-0 text-blue" size={17}/>} 
                </button>
              })}
            </div>
            {invalidSelection&&<p className="mt-3 text-sm font-medium text-danger">Escolha pelo menos uma matéria ou área, ou marque “Todas”.</p>}
            {invalidCount&&<p className="mt-3 text-sm font-medium text-danger">Esta seleção possui somente {availableQuestionCount} questões aprovadas. Escolha uma quantidade menor ou mais matérias.</p>}
          </fieldset>}

          {kind === 'simulation' && <><label className="mt-7 block text-sm font-bold text-navy">Dificuldade<select className="field mt-2" value={difficulty} onChange={event=>setDifficulty(event.target.value)}><option value="">Misturar dificuldades</option><option value="easy">Fácil</option><option value="medium">Média</option><option value="hard">Difícil</option></select></label><div className="mt-5 rounded-2xl border border-blue/20 bg-mist p-5"><div className="flex gap-3"><AlarmClock className="shrink-0 text-blue"/><div><h3 className="font-bold text-navy">Modo simulado</h3><p className="mt-1 text-sm leading-relaxed text-slate-600">Cronômetro visível, navegação entre questões e marcação para revisão. A correção aparece apenas depois da entrega.</p></div></div></div></>}

          {create.error&&<p className="mt-5 rounded-xl bg-red-50 p-3 text-sm text-red-700">{create.error.message}</p>}
          <BusyButton busy={create.isPending} disabled={invalidSelection||invalidCount} className="btn-primary mt-6" onClick={()=>create.mutate()}>Iniciar {kind === 'simulation' ? 'simulado' : 'atividade'} <ArrowRight size={18}/></BusyButton>
        </section>

        <aside className="card h-fit bg-navy p-6 text-white">
          {kind === 'diagnostic' ? <Target className="text-blue-200"/> : kind === 'exercise' ? <BookOpenCheck className="text-blue-200"/> : <ClipboardCheck className="text-blue-200"/>}
          <p className="mt-6 text-xs font-bold uppercase tracking-[.18em] text-blue-200">Resumo da atividade</p>
          <p className="mt-3 text-3xl font-bold">{questionCount} questões</p>
          <p className="mt-2 text-sm leading-relaxed text-blue-100">{selectedNames || 'Selecione uma matéria'} · cerca de {questionCount*c.estimate} minutos</p>
          <p className="mt-3 text-xs text-blue-200">{availableQuestionCount} questões aprovadas disponíveis neste recorte</p>
          <div className="mt-6 border-t border-white/15 pt-5 text-sm leading-relaxed text-blue-100">
            As questões são filtradas pelo exame <strong className="text-white">{goal.data.exam.name}</strong>. Conteúdos de outras provas não entram nesta seleção.
          </div>
        </aside>
      </div>
    </>
  }

  if (item.status === 'completed') {
    const resultLabel = item.score! >= 70 ? 'Bom desempenho' : item.score! >= 50 ? 'Em desenvolvimento' : 'Há pontos para reforçar'
    const timing = item.configuration?.timing
    const totalTime = timing?.totalSeconds ?? elapsedSeconds
    const persistedQuestionTimes = timing?.questionSeconds || Object.fromEntries(Object.entries(questionTimes).map(([id,seconds])=>[String(id),seconds]))
    const subjectTimes = item.questions.reduce<Record<string,{total:number;count:number}>>((result,question)=>{
      const entry = result[question.subject] ||= {total:0,count:0}
      entry.total += persistedQuestionTimes[String(question.id)] || 0
      entry.count += 1
      return result
    },{})
    return <>
      <PageHeader eyebrow={`${c.title} concluído`} title={`${item.score}% de acertos`} description={`${item.correctAnswers} respostas corretas em ${item.totalQuestions} questões.`} action={<button className="btn-secondary" onClick={()=>setItem(null)}><RotateCcw size={18}/> Nova atividade</button>} />
      <section className="mb-6 grid gap-4 sm:grid-cols-3">
        <div className="metric"><span className="text-sm text-slate-500">Resultado</span><strong className="text-2xl text-navy">{resultLabel}</strong></div>
        <div className="metric"><span className="text-sm text-slate-500">Acertos</span><strong className="text-4xl text-navy">{item.correctAnswers}/{item.totalQuestions}</strong></div>
        <div className="metric"><span className="text-sm text-slate-500">Cobertura</span><strong className="text-lg text-navy">{new Set(item.questions.map(question=>question.subject)).size} matérias</strong></div>
      </section>
      {kind === 'simulation'&&<section className="card mb-6" aria-labelledby="simulation-time-title"><div className="flex items-start gap-3"><BarChart3 className="mt-0.5 text-blue"/><div><h2 id="simulation-time-title" className="font-bold text-navy">Análise de tempo</h2><p className="mt-1 text-sm text-slate-500">Tempo total {formatTime(totalTime)} · média de {formatTime(Math.round(totalTime / Math.max(1,item.totalQuestions)))} por questão.</p></div></div><div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{Object.entries(subjectTimes).map(([subject,data])=><div key={subject} className="rounded-xl bg-mist p-4"><p className="text-sm font-bold text-navy">{subject}</p><p className="mt-1 text-xs text-slate-500">{data.count} questões · média {formatTime(Math.round(data.total / data.count))}</p></div>)}</div></section>}
      {kind === 'diagnostic'&&<div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl bg-navy p-6 text-white sm:flex-row sm:items-center"><div><h2 className="font-bold">Use o resultado no seu planejamento</h2><p className="mt-1 text-sm text-blue-100">O plano transforma as dificuldades encontradas em uma sequência de estudo.</p></div><Link className="btn shrink-0 bg-white text-navy" to="/app/plano">Ver plano de estudos <ChevronRight size={18}/></Link></div>}
      <div className="space-y-4">{item.questions.map((question,index)=><article className={`card border-l-4 ${question.isCorrect?'border-l-mint':'border-l-danger'}`} key={question.id}>
        <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-sm font-bold text-slate-500">Questão {index+1} · {question.subject} · {question.topic}{kind === 'simulation'&&` · ${formatTime(persistedQuestionTimes[String(question.id)] || 0)}`}</p><span className={`text-sm font-bold ${question.isCorrect?'text-mint':'text-danger'}`}>{question.isCorrect?'Correta':'Revisar'}</span></div>
        <p className="mt-3 whitespace-pre-line font-semibold leading-relaxed">{question.statement}</p><QuestionMedia media={question.media}/>
        <div className="mt-4 space-y-2">{question.options.map(option=>{
          const isCorrectOption = option.id === question.correctOptionId
          const wasSelected = option.id === question.selectedOptionId
          return <div key={option.id} className={`rounded-xl border p-3 text-sm ${isCorrectOption?'border-emerald-300 bg-emerald-50':wasSelected?'border-red-300 bg-red-50':'border-slate-200'}`}>
            <div className="flex flex-wrap items-start justify-between gap-2"><span><strong>{String.fromCharCode(64+option.position)}.</strong> {option.text}</span><span className="flex gap-2 text-xs font-bold">{wasSelected&&<span className={isCorrectOption?'text-emerald-800':'text-red-700'}>Sua resposta</span>}{isCorrectOption&&<span className="text-emerald-800">Gabarito</span>}</span></div><QuestionMedia media={question.media} position={option.position}/>
          </div>
        })}</div>
        <p className="mt-4 rounded-xl bg-mist p-4 text-sm leading-relaxed"><strong>Explicação:</strong> {question.explanation}</p>{preferences.showQuestionSource&&<p className="mt-3 text-xs text-slate-500">Origem: {question.source.label}</p>}
      </article>)}</div>
    </>
  }

  const question = item.questions[currentIndex]
  const answered = Object.keys(answers).length
  const progress = Math.round(100 * answered / item.totalQuestions)
  const isSimulation = kind === 'simulation'
  return <>
    <div className="mb-6 flex flex-col gap-4 rounded-2xl bg-navy p-5 text-white sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-xs font-bold uppercase tracking-[.18em] text-blue-200">{item.title} · {goal.data.exam.name}</p>
        <h1 className="mt-2 text-xl font-bold">Questão {currentIndex+1} de {item.totalQuestions}</h1>
      </div>
      <div className="flex items-center gap-4 text-sm">
        {isSimulation&&<span className="flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 font-mono"><AlarmClock size={17}/>{formatTime(elapsedSeconds)}</span>}
        <span>{answered}/{item.totalQuestions} respondidas</span>
      </div>
      <div className="absolute" />
    </div>
    <div className="mb-6 h-2 overflow-hidden rounded-full bg-slate-200"><div className="h-full rounded-full bg-blue transition-all" style={{width:`${progress}%`}}/></div>

    <div className={`grid gap-6 ${isSimulation?'lg:grid-cols-[1fr_260px]':''}`}>
      <section>
        <fieldset className="card p-6 sm:p-8" key={question.id}>
          <legend className="sr-only">Questão {currentIndex+1}</legend>
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-semibold text-slate-500"><span>{question.subject} · {question.topic} · {question.difficulty}</span>{isSimulation&&<button type="button" onClick={()=>setMarked(current=>current.includes(question.id)?current.filter(id=>id!==question.id):[...current,question.id])} className={`flex items-center gap-2 rounded-lg px-3 py-2 ${marked.includes(question.id)?'bg-amber-100 text-amber-800':'bg-slate-100'}`}><Flag size={15}/> {marked.includes(question.id)?'Marcada':'Marcar para revisar'}</button>}</div>
          <p className="mt-6 whitespace-pre-line text-lg font-semibold leading-relaxed">{question.statement}</p><QuestionMedia media={question.media}/>
          <div className="mt-6 space-y-3">{question.options.map(option=><label key={option.id} className={`flex cursor-pointer gap-3 rounded-xl border p-4 transition ${answers[question.id]===option.id?'border-blue bg-blue/5 ring-1 ring-blue':'border-slate-200 hover:bg-slate-50'}`}><input type="radio" name={`q-${question.id}`} value={option.id} checked={answers[question.id]===option.id} onChange={()=>setAnswers(current=>({...current,[question.id]:option.id}))}/><span className="min-w-0 flex-1 text-sm leading-relaxed"><strong>{String.fromCharCode(64+option.position)}.</strong> {option.text}<QuestionMedia media={question.media} position={option.position}/></span></label>)}</div>
        </fieldset>
        <div className="mt-4 flex items-center justify-between gap-3">
          <button className="btn-secondary" disabled={currentIndex===0} onClick={()=>setCurrentIndex(index=>index-1)}><ArrowLeft size={18}/> Anterior</button>
          {currentIndex < item.totalQuestions-1 ? <button className="btn-primary" onClick={()=>setCurrentIndex(index=>index+1)}>Próxima <ArrowRight size={18}/></button> : <BusyButton busy={finish.isPending} disabled={answered!==item.totalQuestions} className="btn-primary" onClick={()=>finish.mutate()}><CheckCircle2 size={18}/> {isSimulation?'Entregar simulado':'Finalizar e corrigir'}</BusyButton>}
        </div>
        {finish.error&&<p className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{finish.error.message}</p>}
      </section>

      {isSimulation&&<aside className="card h-fit lg:sticky lg:top-6"><div className="flex items-center justify-between"><h2 className="font-bold text-navy">Mapa da prova</h2><span className="text-xs text-slate-500">{marked.length} marcadas</span></div><div className="mt-4 grid grid-cols-5 gap-2">{item.questions.map((entry,index)=><button key={entry.id} onClick={()=>setCurrentIndex(index)} aria-label={`Ir para questão ${index+1}`} className={`grid aspect-square place-items-center rounded-lg text-xs font-bold ${currentIndex===index?'bg-navy text-white':answers[entry.id]?'bg-blue text-white':marked.includes(entry.id)?'bg-amber-100 text-amber-800':'bg-slate-100 text-slate-600'}`}>{index+1}</button>)}</div>{answered===item.totalQuestions&&<BusyButton busy={finish.isPending} className="btn-primary mt-5 w-full" onClick={()=>finish.mutate()}><CheckCircle2 size={18}/> Entregar simulado</BusyButton>}<p className="mt-4 text-xs leading-relaxed text-slate-500">A correção e as explicações ficam disponíveis somente após a entrega.</p></aside>}
    </div>
  </>
}
