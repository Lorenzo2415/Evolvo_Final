import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  BookOpenCheck,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  ListChecks,
  Play,
  RefreshCw,
  Sparkles,
  Target,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { BusyButton, EmptyState, ErrorState, Loading, PageHeader } from '../components/ui'
import { api } from '../services/api'
import type { Task } from '../types'

type Plan = {
  id:number
  version:number
  status:string
  rationale:Record<string,unknown>
  tasks:Task[]
}

const dateFormatter = new Intl.DateTimeFormat('pt-BR', {
  weekday:'long',
  day:'2-digit',
  month:'long',
})

function dateKey(date = new Date()) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2,'0')
  const day = String(date.getDate()).padStart(2,'0')
  return `${year}-${month}-${day}`
}

function parseDate(value:string) {
  return new Date(`${value}T12:00:00`)
}

function dateLabel(value:string) {
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  if (value === dateKey()) return 'Hoje'
  if (value === dateKey(tomorrow)) return 'Amanhã'
  const formatted = dateFormatter.format(parseDate(value))
  return formatted.charAt(0).toUpperCase() + formatted.slice(1)
}

function activityLabel(type:string) {
  const labels:Record<string,string> = {
    practice:'Prática',
    review:'Revisão',
    simulation:'Simulado',
    diagnostic:'Diagnóstico',
    theory:'Teoria',
  }
  return labels[type] || type.replace(/_/g,' ')
}

function statusLabel(status:string) {
  if (status === 'completed') return 'Concluída'
  if (status === 'in_progress') return 'Em andamento'
  return 'Pendente'
}

function ActivityBadge({task}:{task:Task}) {
  const isReview = task.activityType === 'review'
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${isReview ? 'bg-amber-50 text-amber-800' : 'bg-blue/10 text-blue'}`}>
    {isReview ? <RefreshCw size={13} aria-hidden="true" /> : <BookOpenCheck size={13} aria-hidden="true" />}
    <span className="capitalize">{activityLabel(task.activityType)}</span>
  </span>
}

function StatusBadge({status}:{status:string}) {
  const style = status === 'completed'
    ? 'bg-emerald-50 text-emerald-800'
    : status === 'in_progress'
      ? 'bg-blue/10 text-blue'
      : 'bg-slate-100 text-slate-600'
  return <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${style}`}>{statusLabel(status)}</span>
}

function taskHref(task:Task) {
  const params = new URLSearchParams({
    taskId:String(task.id),
    subjectId:String(task.subjectId),
    topicId:String(task.topicId),
    count:'15',
  })
  return `/app/exercicios?${params.toString()}`
}

function TaskAction({task}:{task:Task}) {
  if (task.status === 'completed') {
    return <span className="inline-flex items-center gap-2 text-sm font-bold text-mint"><CheckCircle2 size={18} aria-hidden="true" /> Concluída</span>
  }
  const isStarted = task.status === 'in_progress'
  return <Link className={isStarted ? 'btn-primary' : 'btn-secondary'} to={taskHref(task)} aria-label={`${isStarted ? 'Continuar' : 'Iniciar'} ${task.title}`}>
    <Play size={18} aria-hidden="true" />
    {isStarted ? 'Continuar atividade' : 'Iniciar atividade'}
  </Link>
}

export default function PlanPage({routine=false}:{routine?:boolean}) {
  const qc = useQueryClient()
  const [showFullPlan,setShowFullPlan] = useState(false)
  const q = useQuery({
    queryKey:[routine ? 'routine' : 'plan'],
    queryFn:()=>api<Plan|Task[]>(routine ? '/routine' : '/study-plans'),
  })
  const generate = useMutation({
    mutationFn:()=>api<Plan>('/study-plans/generate',{method:'POST'}),
    onSuccess:()=>qc.invalidateQueries(),
  })
  const replan = useMutation({
    mutationFn:()=>api<Plan>('/study-plans/replan',{method:'POST'}),
    onSuccess:()=>qc.invalidateQueries(),
  })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorState message={q.error.message} retry={()=>q.refetch()} />

  const plan = q.data && !Array.isArray(q.data) ? q.data : null
  const tasks = [...(Array.isArray(q.data) ? q.data : q.data?.tasks || [])]
    .sort((a,b)=>a.scheduledDate.localeCompare(b.scheduledDate) || b.priorityScore - a.priorityScore)
  const completed = tasks.filter(task=>task.status === 'completed').length
  const remaining = tasks.length - completed
  const totalMinutes = tasks.reduce((total,task)=>total + task.durationMinutes,0)
  const progress = tasks.length ? Math.round(completed / tasks.length * 100) : 0
  const nextTask = tasks.find(task=>task.status !== 'completed')
  if (routine) {
    return <>
      <PageHeader
        eyebrow="Seu dia"
        title="Rotina de hoje"
        description="Sua rotina usa seus erros, acertos, revisões pendentes e objetivo. Depois de cada atividade, as próximas sessões pendentes são recalculadas automaticamente."
      />
      {!tasks.length ? <EmptyState
        title="Nada programado para hoje"
        description="Seu dia está livre. Consulte o plano completo para antecipar uma sessão ou aproveite para descansar."
        action={<Link className="btn-secondary" to="/app/plano"><CalendarClock size={18} /> Ver plano completo</Link>}
      /> : <>
        <section className="card mb-6 overflow-hidden p-0">
          <div className="grid gap-5 p-5 sm:grid-cols-[1fr_auto] sm:items-center sm:p-6">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="eyebrow">Progresso de hoje</span>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">{completed}/{tasks.length} concluídas</span>
              </div>
              <p className="mt-3 text-2xl font-bold text-navy">{remaining ? `${remaining} ${remaining === 1 ? 'sessão pendente' : 'sessões pendentes'}` : 'Tudo concluído por hoje'}</p>
              <p className="mt-1 text-sm text-slate-500">{totalMinutes} minutos planejados para o dia</p>
            </div>
            <div className="grid h-20 w-20 place-items-center rounded-full border-8 border-blue/10 text-xl font-bold text-blue" aria-label={`${progress}% concluído`}>{progress}%</div>
          </div>
          <div className="h-2 bg-slate-100" role="progressbar" aria-label="Progresso da rotina" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}>
            <div className="h-full bg-blue transition-all" style={{width:`${progress}%`}} />
          </div>
        </section>

        <section aria-labelledby="today-checklist-title">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 id="today-checklist-title" className="flex items-center gap-2 text-lg font-bold text-navy"><ListChecks className="text-blue" aria-hidden="true" /> Checklist do dia</h2>
            <span className="text-sm text-slate-500">{dateLabel(dateKey())}</span>
          </div>
          <ol className="relative ml-3 space-y-4 border-l-2 border-slate-200 pl-7">
            {tasks.map((task,index)=><li key={task.id} className="relative">
              <span className={`absolute -left-[2.35rem] top-5 grid h-5 w-5 place-items-center rounded-full border-2 bg-white ${task.status === 'completed' ? 'border-mint text-mint' : task.status === 'in_progress' ? 'border-blue text-blue' : 'border-slate-300 text-slate-300'}`} aria-hidden="true">
                {task.status === 'completed' ? <Check size={12} strokeWidth={3} /> : <span className="h-1.5 w-1.5 rounded-full bg-current" />}
              </span>
              <article className={`card ${task.status === 'in_progress' ? 'border-blue/40 shadow-soft' : ''}`}>
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2"><span className="text-xs font-bold text-slate-400">{String(index + 1).padStart(2,'0')}</span><ActivityBadge task={task} /><StatusBadge status={task.status} /></div>
                    <h3 className={`mt-3 text-lg font-bold ${task.status === 'completed' ? 'text-slate-500 line-through' : 'text-navy'}`}>{task.title}</h3>
                    <p className="mt-1 text-sm text-slate-500">{task.subject} · {task.topic} · {task.durationMinutes} min</p>
                    <details className="group mt-3 text-sm">
                      <summary className="inline-flex cursor-pointer list-none items-center gap-1.5 font-semibold text-blue">Por que esta atividade?<ChevronDown className="transition group-open:rotate-180" size={16} aria-hidden="true" /></summary>
                      <p className="mt-2 max-w-2xl leading-relaxed text-slate-600">{task.reason}</p>
                    </details>
                  </div>
                  <TaskAction task={task} />
                </div>
              </article>
            </li>)}
          </ol>
        </section>
      </>}
    </>
  }

  if (!plan || !tasks.length) {
    return <>
      <PageHeader eyebrow="Planejamento" title="Plano de estudos" description="Organize as sessões até a prova e entenda por que cada assunto foi priorizado." />
      <EmptyState
        title={plan ? 'Seu plano não tem sessões' : 'Seu plano ainda não foi gerado'}
        description="Conclua o diagnóstico para que o Evolvo distribua matérias e revisões de acordo com suas necessidades."
        action={<BusyButton busy={generate.isPending} onClick={()=>generate.mutate()} className="btn-primary"><Sparkles size={18} /> Gerar plano personalizado</BusyButton>}
      />
      {generate.error&&<p role="alert" className="mt-5 rounded-xl bg-red-50 p-3 text-sm text-red-700">{generate.error.message}</p>}
    </>
  }

  const groups = tasks.reduce<Record<string,Task[]>>((result,task)=>{
    ;(result[task.scheduledDate] ||= []).push(task)
    return result
  },{})
  const groupEntries = Object.entries(groups)
  const visibleGroups = showFullPlan ? groupEntries : groupEntries.slice(0,7)

  return <>
    <PageHeader
      eyebrow="Planejamento"
      title="Plano de estudos"
      description="Este é o mapa completo até a prova. Inicie uma sessão para abrir os exercícios; ela só será concluída depois da entrega da atividade."
      action={<BusyButton busy={replan.isPending} onClick={()=>replan.mutate()} className="btn-secondary"><RefreshCw size={18} /> Replanejar</BusyButton>}
    />

    <section className="card mb-6 overflow-hidden p-0" aria-labelledby="plan-summary-title">
      <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[1.2fr_.8fr] lg:items-center">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h2 id="plan-summary-title" className="text-lg font-bold text-navy">Resumo do plano</h2>
            <span className="rounded-full bg-blue/10 px-3 py-1 text-xs font-bold text-blue">Versão {plan.version}</span>
          </div>
          <p className="mt-2 text-sm text-slate-500">{completed} de {tasks.length} sessões concluídas</p>
          <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-label="Progresso do plano" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}>
            <div className="h-full rounded-full bg-blue transition-all" style={{width:`${progress}%`}} />
          </div>
          <p className="mt-2 text-sm font-bold text-blue">{progress}% concluído</p>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-2">
          <div className="rounded-xl bg-mist p-4"><ListChecks className="text-blue" size={19} aria-hidden="true" /><p className="mt-3 text-2xl font-bold text-navy">{remaining}</p><p className="text-xs text-slate-500">sessões pendentes</p></div>
          <div className="rounded-xl bg-mist p-4"><Clock3 className="text-blue" size={19} aria-hidden="true" /><p className="mt-3 text-2xl font-bold text-navy">{totalMinutes}</p><p className="text-xs text-slate-500">minutos planejados</p></div>
        </div>
      </div>
    </section>

    {nextTask&&<section className="mb-8 overflow-hidden rounded-2xl bg-navy p-5 text-white shadow-soft sm:p-6" aria-labelledby="next-session-title">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 gap-4">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/10 text-blue-200"><Target aria-hidden="true" /></div>
          <div>
            <p className="text-xs font-bold uppercase tracking-[.18em] text-blue-200">Próxima sessão · {dateLabel(nextTask.scheduledDate)}</p>
            <h2 id="next-session-title" className="mt-2 text-xl font-bold">{nextTask.title}</h2>
            <p className="mt-1 text-sm text-blue-100">{nextTask.subject} · {nextTask.topic} · {nextTask.durationMinutes} min</p>
          </div>
        </div>
        <TaskAction task={nextTask} />
      </div>
    </section>}

    <section aria-labelledby="timeline-title">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><h2 id="timeline-title" className="text-xl font-bold text-navy">Linha do tempo</h2><p className="mt-1 text-sm text-slate-500">Sessões agrupadas por data, na ordem do seu plano.</p></div>
        <span className="text-sm font-semibold text-slate-500">{groupEntries.length} dias de estudo</span>
      </div>
      <div className="space-y-8">
        {visibleGroups.map(([day,dayTasks])=><section key={day} className="grid gap-4 md:grid-cols-[180px_1fr]">
          <header className="md:pt-1">
            <p className="flex items-center gap-2 font-bold text-navy"><CalendarClock className="text-blue" size={19} aria-hidden="true" /> {dateLabel(day)}</p>
            <time dateTime={day} className="mt-1 block pl-7 text-xs text-slate-500">{parseDate(day).toLocaleDateString('pt-BR')}</time>
          </header>
          <div className="relative space-y-3 border-l-2 border-slate-200 pl-6">
            {dayTasks.map(task=><article key={task.id} className={`card relative ${task === nextTask ? 'border-blue/40' : ''}`}>
              <span className={`absolute -left-[2.05rem] top-6 h-3.5 w-3.5 rounded-full border-2 bg-white ${task.status === 'completed' ? 'border-mint' : task.status === 'in_progress' ? 'border-blue' : 'border-slate-300'}`} aria-hidden="true" />
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2"><ActivityBadge task={task} /><StatusBadge status={task.status} /><span className="text-xs font-semibold text-slate-500">{task.durationMinutes} min</span></div>
                  <h3 className={`mt-3 font-bold ${task.status === 'completed' ? 'text-slate-500 line-through' : 'text-navy'}`}>{task.title}</h3>
                  <p className="mt-1 text-sm text-slate-500">{task.subject} · {task.topic}</p>
                  <details className="group mt-3 text-sm">
                    <summary className="inline-flex cursor-pointer list-none items-center gap-1.5 font-semibold text-blue">Por que foi priorizada?<ChevronDown className="transition group-open:rotate-180" size={16} aria-hidden="true" /></summary>
                    <p className="mt-2 max-w-2xl leading-relaxed text-slate-600">{task.reason}</p>
                  </details>
                </div>
                <TaskAction task={task} />
              </div>
            </article>)}
          </div>
        </section>)}
      </div>
      {groupEntries.length > 7&&<div className="mt-8 flex justify-center">
        <button type="button" className="btn-secondary" onClick={()=>setShowFullPlan(value=>!value)}>
          {showFullPlan ? 'Mostrar somente os próximos dias' : `Ver plano completo (${groupEntries.length} dias)`}
          <ChevronDown className={`transition ${showFullPlan ? 'rotate-180' : ''}`} size={18} aria-hidden="true" />
        </button>
      </div>}
    </section>

    {replan.error&&<p role="alert" className="mt-5 rounded-xl bg-red-50 p-3 text-sm text-red-700">{replan.error.message}</p>}
  </>
}
