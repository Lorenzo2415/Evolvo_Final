import { FormEvent, useState } from 'react'
import { Database, LogOut, UserRoundCheck } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { BusyButton } from '../components/ui'
import { useAuth } from '../contexts/AuthContext'
import { Logo } from '../layouts/AppLayout'

export default function Auth({ mode }: { mode: 'login' | 'register' }) {
  const { user, login, logout, register } = useAuth()
  const navigate = useNavigate()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setBusy(true)
    setError('')
    const form = new FormData(event.currentTarget)
    try {
      if (mode === 'login') {
        await login(String(form.get('email')), String(form.get('password')))
      } else {
        await register(String(form.get('name')), String(form.get('email')), String(form.get('password')))
      }
      navigate(mode === 'register' ? '/consentimento' : '/app')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro inesperado')
    } finally {
      setBusy(false)
    }
  }

  const isDemo = user?.email === 'demo@evolvo.local'

  return (
    <main className="grid min-h-screen bg-white dark:bg-[#0b1220] lg:grid-cols-2">
      <section className="hidden bg-navy p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <Logo />
        <div className="max-w-lg">
          <p className="text-sm uppercase tracking-[.2em] text-blue-200">Evolvo 2.0</p>
          <h1 className="display mt-5 text-5xl">Treine com mais direção entre uma aula e outra.</h1>
          <p className="mt-5 text-blue-100">O Evolvo complementa sua preparação ao identificar lacunas, direcionar a prática e acompanhar sua evolução.</p>
        </div>
        <p className="text-sm text-blue-200">Seu histórico é individual e nasce somente das atividades que você realiza.</p>
      </section>

      <section className="grid place-items-center p-5">
        <div className="w-full max-w-md">
          <div className="mb-10 lg:hidden"><Logo /></div>

          {user ? (
            <div className="card p-7">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-mist text-blue">
                <UserRoundCheck size={25} />
              </div>
              <p className="eyebrow mt-6">Sessão ativa</p>
              <h2 className="display mt-2 text-3xl text-navy dark:text-white">Você já está em uma conta</h2>
              <div className="mt-5 rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                <p className="font-bold text-navy dark:text-white">{user.name}</p>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-300">{user.email}</p>
                {isDemo && (
                  <p className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-sm font-medium text-amber-800 dark:bg-amber-950/40 dark:text-amber-200">
                    Esta é a conta demonstrativa, com dados fictícios pré-carregados.
                  </p>
                )}
              </div>
              <button className="btn-primary mt-6 w-full" onClick={() => navigate(user.onboardingComplete?'/app':'/consentimento')}>{user.onboardingComplete?'Continuar nesta conta':'Revisar e confirmar'}</button>
              <button className="btn-secondary mt-3 w-full" onClick={logout}>
                <LogOut size={17} /> {mode === 'register' ? 'Criar outra conta' : 'Entrar com outra conta'}
              </button>
            </div>
          ) : (
            <>
              <p className="eyebrow">{mode === 'login' ? 'Bem-vindo de volta' : 'Comece sua jornada'}</p>
              <h2 className="display mt-2 text-4xl text-navy dark:text-white">{mode === 'login' ? 'Entre na sua conta' : 'Crie sua conta'}</h2>
              {mode === 'register' && <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">Sua conta começa vazia. Nenhum resultado ou plano será inventado.</p>}

              <form className="mt-8 space-y-4" onSubmit={submit}>
                {mode === 'register' && <label className="block text-sm font-semibold">Nome<input className="field mt-2" name="name" required minLength={2} /></label>}
                <label className="block text-sm font-semibold">E-mail<input className="field mt-2" type="email" name="email" required /></label>
                <label className="block text-sm font-semibold">Senha<input className="field mt-2" type="password" name="password" required minLength={8} /></label>
                {mode === 'register' && <p className="rounded-xl bg-mist p-3 text-xs leading-relaxed text-slate-600">Depois de criar a conta, você verá os Termos de Uso, o Aviso de Privacidade e cada confirmação necessária antes de entrar.</p>}
                {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
                <BusyButton busy={busy} className="btn-primary w-full" type="submit">{mode === 'login' ? 'Entrar' : 'Criar conta'}</BusyButton>
              </form>

              <p className="mt-6 text-center text-sm text-slate-600 dark:text-slate-300">
                {mode === 'login' ? 'Ainda não tem conta?' : 'Já tem conta?'}{' '}
                <Link className="font-semibold text-blue" to={mode === 'login' ? '/cadastro' : '/entrar'}>{mode === 'login' ? 'Cadastre-se' : 'Entre'}</Link>
              </p>

              {mode === 'login' && (
                <div className="mt-6 rounded-xl bg-mist p-4 text-sm text-slate-600">
                  <strong>Conta demonstrativa opcional</strong>
                  <p className="mt-1">demo@evolvo.local / Demo123!</p>
                  <p className="mt-2 text-xs">Ela contém dados fictícios pré-carregados e não se mistura com uma conta criada por você.</p>
                </div>
              )}

              <div className="mt-5 flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-300">
                <Database size={15} /> Contas e progresso persistidos em banco SQL SQLite.
              </div>
            </>
          )}
        </div>
      </section>
    </main>
  )
}
