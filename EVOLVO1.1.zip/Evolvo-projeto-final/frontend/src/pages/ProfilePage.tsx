import { FormEvent, useEffect, useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { Check, Save, UserRound } from 'lucide-react'
import { BusyButton, ErrorState, Loading, PageHeader } from '../components/ui'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../services/api'

type Preference={subjectId:number;name:string;area:string;selected:boolean;priority:number|null}

export default function ProfilePage({embedded=false,section='all'}:{embedded?:boolean;section?:'all'|'profile'|'priorities'}){
  const {user,retrySession}=useAuth()
  const [name,setName]=useState(user?.name||'')
  const [email,setEmail]=useState(user?.email||'')
  const [selected,setSelected]=useState<Record<number,number>>({})
  const [message,setMessage]=useState('')
  const preferences=useQuery({queryKey:['subject-preferences'],queryFn:()=>api<Preference[]>('/preferences/subjects')})
  useEffect(()=>{if(preferences.data)setSelected(Object.fromEntries(preferences.data.filter(i=>i.selected).map(i=>[i.subjectId,i.priority||1])))},[preferences.data])
  const saveProfile=useMutation({mutationFn:()=>api('/auth/me',{method:'PUT',body:JSON.stringify({name,email})}),onSuccess:async()=>{await retrySession();setMessage('Perfil atualizado.')}})
  const savePreferences=useMutation({mutationFn:()=>api('/preferences/subjects',{method:'PUT',body:JSON.stringify({subjects:Object.entries(selected).map(([subjectId,priority])=>({subjectId:Number(subjectId),priority}))})}),onSuccess:()=>setMessage('Matérias prioritárias salvas.')})
  if(preferences.isLoading)return <Loading/>
  if(preferences.error)return <ErrorState message={preferences.error.message} retry={()=>preferences.refetch()}/>
  function submit(e:FormEvent){e.preventDefault();saveProfile.mutate()}
  function toggle(id:number){setSelected(current=>{const next={...current};if(next[id]!=null)delete next[id];else next[id]=1;return next})}
  const selectedItems=preferences.data?.filter(item=>selected[item.subjectId]!=null)||[]
  return <>
    {!embedded&&<PageHeader eyebrow="Personalização" title="Meu perfil" description="Atualize seus dados e escolha as matérias que devem receber mais atenção nas recomendações."/>}
    {message&&<p role="status" className="mb-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-800">{message}</p>}
    {section!=='priorities'&&<section className="card p-5 sm:p-6">
      <form className="grid items-end gap-3 lg:grid-cols-[auto_1fr_1fr_auto]" onSubmit={submit}>
        <div className="flex items-center gap-3 lg:pb-1"><span className="section-icon !h-10 !w-10"><UserRound size={20}/></span><div><h2 className="font-bold text-navy">Dados pessoais</h2><p className="text-xs text-slate-500">Sua conta</p></div></div>
        <label className="block text-xs font-semibold">Nome<input className="field mt-1.5 !py-2.5" value={name} onChange={e=>setName(e.target.value)} required minLength={2}/></label>
        <label className="block text-xs font-semibold">E-mail<input className="field mt-1.5 !py-2.5" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label>
        <BusyButton busy={saveProfile.isPending} className="btn-primary !py-2.5" type="submit"><Save size={16}/>Salvar</BusyButton>
      </form>
      {saveProfile.error&&<p className="mt-3 text-sm text-danger">{saveProfile.error.message}</p>}
    </section>}

    {section!=='profile'&&<section className="card p-5 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3"><div><h2 className="font-bold text-navy">Matérias prioritárias</h2><p className="mt-1 text-xs text-slate-500">Marque somente as que precisam de atenção extra.</p></div><span className="rounded-full bg-mist px-3 py-1 text-xs font-bold text-blue">{selectedItems.length} selecionadas</span></div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{preferences.data?.map(item=>{const active=selected[item.subjectId]!=null;return <button type="button" key={item.subjectId} aria-pressed={active} onClick={()=>toggle(item.subjectId)} className={`group flex min-h-20 items-center gap-3 rounded-xl border px-4 py-3 text-left transition ${active?'border-blue bg-blue/10':'border-slate-200 hover:border-blue/50 hover:bg-mist'}`}><span className={`grid h-6 w-6 shrink-0 place-items-center rounded-md border ${active?'border-blue bg-blue text-white':'border-slate-300 text-transparent group-hover:border-blue'}`}><Check size={14}/></span><span className="min-w-0"><strong className={`block text-sm ${active?'text-blue':'text-navy'}`}>{item.name}</strong><span className="mt-1 block text-xs text-slate-500">{item.area}</span></span></button>})}</div>

      {selectedItems.length>0&&<div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl bg-mist p-3"><span className="mr-1 text-xs font-semibold text-slate-500">Nível de atenção:</span>{selectedItems.map(item=><label key={item.subjectId} className="inline-flex items-center gap-2 rounded-lg bg-white px-2.5 py-1.5 text-xs font-semibold"><span>{item.name}</span><select aria-label={`Prioridade de ${item.name}`} className="bg-transparent text-xs text-blue" value={selected[item.subjectId]} onChange={event=>setSelected(current=>({...current,[item.subjectId]:Number(event.target.value)}))}><option value={1}>Normal</option><option value={2}>Alta</option><option value={3}>Máxima</option></select></label>)}</div>}
      {savePreferences.error&&<p className="mt-3 text-sm text-danger">{savePreferences.error.message}</p>}
      <BusyButton busy={savePreferences.isPending} className="btn-primary mt-4 !py-2.5" onClick={()=>savePreferences.mutate()}><Save size={16}/>Salvar prioridades</BusyButton>
    </section>}
  </>
}
