import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from './contexts/AuthContext'
import { PreferencesProvider } from './contexts/PreferencesContext'
import App from './App'
import './styles/index.css'
const client=new QueryClient({defaultOptions:{queries:{staleTime:30_000,retry:1}}})
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><PreferencesProvider><QueryClientProvider client={client}><BrowserRouter><AuthProvider><App/></AuthProvider></BrowserRouter></QueryClientProvider></PreferencesProvider></React.StrictMode>)

