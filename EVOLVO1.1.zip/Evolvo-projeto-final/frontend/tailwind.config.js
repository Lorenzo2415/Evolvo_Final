/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: {
    colors: { ink: '#132033', navy: '#113A67', blue: '#1769E0', mist: '#EEF5FB', mint: '#25A77B', amber: '#E49A32', danger: '#D64F54' },
    fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui'] },
    boxShadow: { soft: '0 14px 40px rgba(17,58,103,.10)' }
  }},
  plugins: []
}

