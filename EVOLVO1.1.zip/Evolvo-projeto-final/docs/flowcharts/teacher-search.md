# Fluxograma de recuperação — pesquisa de professores

```mermaid
flowchart TD
  A[Usuário escolhe nome, matéria, modalidade e ordenação] --> B[TeachersPage envia GET /api/teachers]
  B --> C[TeacherController.search recebe query params]
  C --> D[SearchTeachersService valida nome, matéria, modalidade e ordenação]
  D --> E[TeacherRepository monta consulta parametrizada]
  E --> F[(SQLite executa filtro, média e ordenação)]
  F --> G[Repository recupera Models Teacher e Subject]
  G --> H[Controller serializa JSON]
  H --> I[Frontend apresenta cards ou estado vazio]
```

Arquivos principais: `frontend/src/pages/TeachersPage.tsx`, `backend/app/controllers/api_controllers.py`, `backend/app/services/teacher_services.py` e `backend/app/repositories/teacher_repository.py`.
