# Fluxograma de entrada — avaliação de professor

```mermaid
flowchart TD
  A[Estudante informa nota e comentário] --> B[TeachersPage envia POST /api/teachers/:id/reviews com JWT]
  B --> C[JWT valida a sessão]
  C --> D[TeacherController.review recebe os dados]
  D --> E[ReviewTeacherService valida professor, nota e comentário]
  E --> F{Já existe avaliação deste usuário?}
  F -->|Sim| G[Atualiza TeacherReview existente]
  F -->|Não| H[Cria TeacherReview]
  G --> I[(SQLite confirma transação)]
  H --> I
  I --> J[TeacherRepository recalcula média e quantidade]
  J --> K[Controller retorna JSON]
  K --> L[Frontend atualiza perfil e cards]
```

A restrição única `(teacher_id, user_id)` reforça no banco a regra de uma avaliação editável por estudante e professor.
