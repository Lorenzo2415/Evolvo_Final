# Diagrama de classes do domínio

Este diagrama foi conferido em 22/10/2026 contra as Models reais de `backend/app/models/entities.py`. Os atributos exibidos são os mais relevantes para o domínio; chaves estrangeiras aparecem nos relacionamentos.

```mermaid
classDiagram
  class TimestampMixin { +datetime created_at +datetime updated_at }
  class User { +int id +string name +string email +string password_hash +string role +bool is_active +set_password() +check_password() }
  class UserConsent { +int id +string consent_type +string version +bool accepted +datetime decided_at }
  class Exam { +int id +string slug +string name +string exam_type +string support_status }
  class ExamProfile { +int id +json syllabus +json structure +int question_count +int duration_minutes }
  class UserGoal { +int id +date exam_date +int daily_minutes +json study_days +bool active }
  class Subject { +int id +string name +string area +float weight }
  class SubjectPreference { +int id +int priority }
  class Topic { +int id +string name +float importance }
  class Question { +int id +text statement +string difficulty +string status +string author_type +json media +text explanation }
  class QuestionOption { +int id +int position +text text +bool is_correct }
  class Assessment { +int id +string kind +string status +json configuration +float score +int total_questions }
  class AssessmentQuestion { +int id +int position +bool is_correct +datetime answered_at }
  class EssayPrompt { +int id +string title +text theme +json support_texts +string status }
  class EssaySubmission { +int id +text draft_text +string status +int word_count +json analysis }
  class EssayCorrection { +int id +string kind +string status +json feedback +datetime completed_at }
  class StudyPlan { +int id +int version +string status +json rationale }
  class StudyTask { +int id +date scheduled_date +string activity_type +float priority_score +string status }
  class Performance { +int id +int attempts +int correct +float mastery }
  class ReviewSchedule { +int id +datetime next_review_at +int interval_days +float last_score }
  class AIInteraction { +int id +string purpose +string provider +string model +string status }
  class Teacher { +int id +int user_id +string name +text biography +float hourly_price +string modality +string city +bool active }
  class TeacherReview { +int id +int rating +string comment }
  class TeacherContactRequest { +int id +int teacher_id +int student_id +int subject_id +string message +string status }
  class TeacherPartnerApplication { +int id +text biography +float hourly_price +string modality +string city +string contact +json subject_ids +string status +datetime reviewed_at }

  TimestampMixin <|-- User
  TimestampMixin <|-- UserConsent
  TimestampMixin <|-- Exam
  TimestampMixin <|-- ExamProfile
  TimestampMixin <|-- Subject
  TimestampMixin <|-- SubjectPreference
  TimestampMixin <|-- Topic
  TimestampMixin <|-- Question
  TimestampMixin <|-- UserGoal
  TimestampMixin <|-- Assessment
  TimestampMixin <|-- EssayPrompt
  TimestampMixin <|-- EssaySubmission
  TimestampMixin <|-- EssayCorrection
  TimestampMixin <|-- StudyPlan
  TimestampMixin <|-- StudyTask
  TimestampMixin <|-- Performance
  TimestampMixin <|-- ReviewSchedule
  TimestampMixin <|-- AIInteraction
  TimestampMixin <|-- Teacher
  TimestampMixin <|-- TeacherReview
  TimestampMixin <|-- TeacherContactRequest
  TimestampMixin <|-- TeacherPartnerApplication

  User "1" *-- "0..*" UserConsent
  User "1" *-- "0..*" UserGoal
  User "1" *-- "0..*" SubjectPreference
  Subject "1" o-- "0..*" SubjectPreference
  Exam "1" *-- "0..1" ExamProfile
  Exam "1" o-- "0..*" Subject
  Subject "1" *-- "0..*" Topic
  Exam "1" o-- "0..*" Question
  Subject "1" o-- "0..*" Question
  Topic "1" o-- "0..*" Question
  Question "1" *-- "2..*" QuestionOption
  User "1" *-- "0..*" Assessment
  Exam "1" o-- "0..*" Assessment
  Assessment "1" *-- "1..*" AssessmentQuestion
  Question "1" o-- "0..*" AssessmentQuestion
  QuestionOption "0..1" o-- "0..*" AssessmentQuestion
  Exam "1" o-- "0..*" EssayPrompt
  EssayPrompt "1" o-- "0..*" EssaySubmission
  User "1" *-- "0..*" EssaySubmission
  EssaySubmission "1" *-- "0..2" EssayCorrection
  User "0..1" o-- "0..*" EssayCorrection : reviewer
  User "1" o-- "0..*" StudyPlan
  UserGoal "1" o-- "0..*" StudyPlan
  StudyPlan "1" *-- "0..*" StudyTask
  Topic "1" o-- "0..*" StudyTask
  User "1" *-- "0..*" Performance
  Exam "1" o-- "0..*" Performance
  Topic "1" o-- "0..*" Performance
  User "1" *-- "0..*" ReviewSchedule
  Topic "1" o-- "0..*" ReviewSchedule
  User "1" *-- "0..*" AIInteraction
  Teacher "0..*" o-- "0..*" Subject : teacher_subjects
  Teacher "1" *-- "0..*" TeacherReview
  User "1" o-- "0..*" TeacherReview
  User "0..1" o-- "0..1" Teacher : professional_profile
  Teacher "1" *-- "0..*" TeacherContactRequest
  User "1" o-- "0..*" TeacherContactRequest : student
  Subject "0..1" o-- "0..*" TeacherContactRequest
  User "1" *-- "0..1" TeacherPartnerApplication : applicant
  User "0..1" o-- "0..*" TeacherPartnerApplication : reviewer
```

`Assessment.kind` diferencia diagnóstico, exercício, revisão e simulado sem duplicar tabelas. A associação `teacher_subjects` implementa o muitos-para-muitos entre professores e matérias. As restrições únicas garantem uma preferência por matéria, um desempenho por usuário/prova/assunto, uma avaliação por aluno/professor, uma candidatura docente por usuário e uma correção de cada tipo por redação.
