"""Inicializador local do Evolvo para Windows e VS Code.

Abra este arquivo e clique em "Run Python File". O script prepara o ambiente
quando necessário, inicia a API Flask e o frontend Vite e abre o navegador.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
VENV = BACKEND / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"


def run(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True)


def prepare_backend() -> None:
    if not VENV_PYTHON.exists():
        print("[1/4] Criando o ambiente Python...")
        run([sys.executable, "-m", "venv", str(VENV)], BACKEND)

    dependency_check = subprocess.run(
        [str(VENV_PYTHON), "-c", "import flask, flask_cors, flask_sqlalchemy"],
        cwd=BACKEND,
        capture_output=True,
    )
    if dependency_check.returncode != 0:
        print("[1/4] Instalando as dependências do backend...")
        run([str(VENV_PYTHON), "-m", "pip", "install", "-r", "requirements.txt"], BACKEND)
    else:
        print("[1/4] Backend preparado.")

    env_file = BACKEND / ".env"
    if not env_file.exists():
        shutil.copy2(BACKEND / ".env.example", env_file)

    print("[2/4] Conferindo o banco SQLite...")
    run([str(VENV_PYTHON), "-m", "flask", "--app", "run.py", "db", "upgrade"], BACKEND)


def prepare_frontend() -> str:
    npm = shutil.which("npm.cmd") or shutil.which("npm")
    if npm is None:
        raise RuntimeError(
            "Node.js não foi encontrado. Instale o Node.js LTS em https://nodejs.org/ e tente novamente."
        )

    if not (FRONTEND / "node_modules").exists():
        print("[3/4] Instalando as dependências do frontend (somente na primeira execução)...")
        run([npm, "install"], FRONTEND)
    else:
        print("[3/4] Frontend preparado.")
    return npm


def wait_for_page(url: str, timeout: int = 90) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2):
                return True
        except Exception:
            time.sleep(1)
    return False


def stop_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        process.terminate()


def main() -> int:
    if not BACKEND.is_dir() or not FRONTEND.is_dir():
        print("ERRO: mantenha iniciar_evolvo.py ao lado das pastas backend e frontend.")
        return 1

    backend_process: subprocess.Popen[bytes] | None = None
    frontend_process: subprocess.Popen[bytes] | None = None
    try:
        prepare_backend()
        npm = prepare_frontend()

        print("[4/4] Iniciando o Evolvo...")
        backend_environment = os.environ.copy()
        backend_environment["FLASK_DEBUG"] = "0"
        backend_process = subprocess.Popen(
            [str(VENV_PYTHON), "run.py"], cwd=BACKEND, env=backend_environment
        )
        frontend_process = subprocess.Popen([npm, "run", "dev"], cwd=FRONTEND)

        if wait_for_page("http://127.0.0.1:5173"):
            print("\nEvolvo aberto em http://localhost:5173")
            print("Mantenha esta execução aberta. Pressione Ctrl+C para encerrar.\n")
            webbrowser.open("http://localhost:5173")
        else:
            print("O frontend demorou para responder. Verifique as mensagens acima.")

        while backend_process.poll() is None and frontend_process.poll() is None:
            time.sleep(1)
        return backend_process.returncode or frontend_process.returncode or 0
    except KeyboardInterrupt:
        print("\nEncerrando o Evolvo...")
        return 0
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"\nNão foi possível iniciar o Evolvo: {error}")
        input("Pressione Enter para fechar...")
        return 1
    finally:
        if frontend_process is not None:
            stop_process(frontend_process)
        if backend_process is not None:
            stop_process(backend_process)


if __name__ == "__main__":
    raise SystemExit(main())
